package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.audio.AcousticTriggerDetector
import com.example.audio.SoundPlayer
import com.example.data.repository.SoundRepository
import com.example.hardware.AlertEffectController
import com.example.hardware.DeviceMotionController
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class VoiceDetectionService : Service() {
    private val TAG = "VoiceDetectionService"
    private var wakeLock: PowerManager.WakeLock? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var acousticDetector: AcousticTriggerDetector? = null
    private var soundPlayer: SoundPlayer? = null
    private var alertEffects: AlertEffectController? = null
    private var motionController: DeviceMotionController? = null
    private var audioManager: AudioManager? = null
    private lateinit var repository: SoundRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var isDestroyed = false
    private var isCurrentlyRecognizing = false
    private var isResponding = false
    private var isBeepMuted = false
    private var alertPlayJob: Job? = null
    private var recognitionWatchdogRunnable: Runnable? = null

    // Detección de doble pulsación del botón de encendido / pantalla apagada
    private var powerButtonReceiver: BroadcastReceiver? = null
    private var powerPressCount = 0
    private var lastPowerPressTimeMs = 0L

    // Receptor y Callback de desconexión de auriculares Bluetooth
    private var bluetoothReceiver: BroadcastReceiver? = null
    private var audioDeviceCallback: android.media.AudioDeviceCallback? = null

    // Control de volumen progresivo (50% -> 75% -> 100% si se llama en < 30 segundos)
    private var lastCallTimestampMs: Long = 0L
    private var consecutiveCallLevel: Int = 0 // 1: 50%, 2: 75%, 3+: 100%

    // Monitoreo de reproducción de medios (YouTube, videos, música) para evitar bajadas bruscas de volumen (ducking)
    private var playbackCallback: AudioManager.AudioPlaybackCallback? = null
    @Volatile private var isMediaPlaybackActiveState = false

    // Silenciado temporal (Snooze 30 min) desde la notificación persistente o la app
    private var snoozeUntilTimestampMs = 0L

    private fun isSnoozed(): Boolean {
        val now = System.currentTimeMillis()
        if (snoozeUntilTimestampMs > 0L) {
            if (now < snoozeUntilTimestampMs) {
                return true
            } else {
                snoozeUntilTimestampMs = 0L
                _snoozeUntil.value = 0L
                updateNotificationForCurrentState()
            }
        }
        return false
    }

    private fun snooze30Minutes() {
        snoozeUntilTimestampMs = System.currentTimeMillis() + 30 * 60 * 1000L
        _snoozeUntil.value = snoozeUntilTimestampMs
        updateNotificationForCurrentState()
        handler.postDelayed({
            if (isSnoozed()) {
                snoozeUntilTimestampMs = 0L
                _snoozeUntil.value = 0L
                updateNotificationForCurrentState()
            }
        }, 30 * 60 * 1000L)
    }

    private fun resumeFromSnooze() {
        snoozeUntilTimestampMs = 0L
        _snoozeUntil.value = 0L
        updateNotificationForCurrentState()
    }

    private fun updateNotificationForCurrentState() {
        if (isResponding) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = if (isSnoozed()) {
            val remainingMin = ((snoozeUntilTimestampMs - System.currentTimeMillis()) / (60 * 1000L)).coerceAtLeast(1L)
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = snoozeUntilTimestampMs }
            val timeStr = String.format(java.util.Locale.ROOT, "%02d:%02d", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE))
            buildNotification(
                title = "Detección silenciada (${remainingMin} min)",
                text = "En pausa hasta las $timeStr. Toca para reanudar.",
                isSnoozeState = true
            )
        } else {
            val triggerMode = repository.triggerMode.value
            val customWord = repository.customTriggerPhrase.value
            val (notifTitle, notifText) = when (triggerMode) {
                TriggerMode.VOICE_MODE -> Pair("Escuchando: Modo voz", "Di \"$customWord\" para localizar el móvil")
                TriggerMode.CLAP_TWICE -> Pair("Escuchando: 2 Palmadas", "Da dos palmadas seguidas para localizar el móvil")
                TriggerMode.WHISTLE -> Pair("Escuchando: Silbido", "Silba para localizar el móvil")
            }
            buildNotification(
                title = notifTitle,
                text = notifText,
                isSnoozeState = false
            )
        }
        nm.notify(NOTIFICATION_ID, notif)
    }

    private fun isMediaPlaybackActive(): Boolean {
        val am = audioManager ?: return false
        return am.isMusicActive || isMediaPlaybackActiveState
    }

    private fun registerPlaybackCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val am = audioManager ?: return
                playbackCallback = object : AudioManager.AudioPlaybackCallback() {
                    override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
                        super.onPlaybackConfigChanged(configs)
                        if (isResponding) return
                        val isPlaying = configs?.any { config ->
                            val usage = config.audioAttributes.usage
                            usage == AudioAttributes.USAGE_MEDIA ||
                            usage == AudioAttributes.USAGE_GAME ||
                            usage == AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE
                        } == true || am.isMusicActive

                        if (isPlaying) {
                            if (!isMediaPlaybackActiveState) {
                                isMediaPlaybackActiveState = true
                                Log.d(TAG, "Reproducción de video/música detectada. Pausando reconocedor para no alterar volumen del video.")
                                if (repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                                    destroySpeechRecognizer()
                                    scheduleRestart(3000L)
                                }
                            }
                        } else {
                            if (isMediaPlaybackActiveState) {
                                isMediaPlaybackActiveState = false
                                Log.d(TAG, "Reproducción de video/música finalizada. Reanudando detección continua.")
                                if (_isServiceActive.value && !isDestroyed && !isResponding) {
                                    startListeningLoop()
                                }
                            }
                        }
                    }
                }
                am.registerAudioPlaybackCallback(playbackCallback!!, handler)
            } catch (e: Exception) {
                Log.w(TAG, "Error registering playback callback: ${e.message}", e)
            }
        }
    }

    private fun unregisterPlaybackCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && playbackCallback != null) {
            try {
                audioManager?.unregisterAudioPlaybackCallback(playbackCallback!!)
            } catch (_: Exception) {}
            playbackCallback = null
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = SoundRepository.getInstance(applicationContext)
        soundPlayer = SoundPlayer(applicationContext)
        alertEffects = AlertEffectController(applicationContext)
        motionController = DeviceMotionController(applicationContext)
        motionController?.startMonitoring()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        registerPlaybackCallback()

        // Inicializar detector acústico para 2 palmadas y silbidos con supresión si el móvil está en movimiento o reproduciendo video
        acousticDetector = AcousticTriggerDetector(
            context = applicationContext,
            onTriggerDetected = { reason ->
                triggerSoundResponse(reason)
            },
            onRmsUpdated = { rms ->
                _audioRms.value = rms
            },
            isMotionSuppressed = {
                motionController?.isPhoneInActiveMotion() == true || isMediaPlaybackActive()
            },
            getSensitivity = {
                repository.sensitivity.value
            }
        )

        // WakeLock para escucha continua con pantalla apagada
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MovilDetector::ContinuousVoiceWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(24 * 60 * 60 * 1000L) // 24 horas max
        }

        createNotificationChannel()
        _isServiceActive.value = true
        repository.setIsListening(true)
        com.example.widget.DetectorWidgetProvider.updateAllWidgets(this, true)

        // Observar cambios de modo en tiempo real para reconfigurar el motor de escucha al instante
        serviceScope.launch {
            repository.triggerMode.collect { mode ->
                if (_isServiceActive.value && !isDestroyed && !isResponding) {
                    Log.d(TAG, "Modo de detección cambiado dinámicamente a: $mode")
                    startListeningLoop()
                    updateNotificationForMode(mode)
                }
            }
        }

        // Observar cambios de frase/palabra personalizada en tiempo real
        serviceScope.launch {
            repository.customTriggerPhrase.collect { phrase ->
                if (_isServiceActive.value && !isDestroyed && !isResponding) {
                    Log.d(TAG, "Palabra de llamada actualizada a: $phrase")
                    updateNotificationForMode(repository.triggerMode.value)
                }
            }
        }

        // Observar y registrar monitoreo de desconexión de Bluetooth si está habilitado
        serviceScope.launch {
            repository.bluetoothAlertEnabled.collect { enabled ->
                if (enabled && _isServiceActive.value) {
                    registerBluetoothReceiver()
                } else {
                    unregisterBluetoothReceiver()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_STOP) {
            stopForegroundService()
            return START_NOT_STICKY
        }

        if (action == ACTION_STOP_ALERT) {
            finishAlertResponse()
            return START_STICKY
        }

        if (action == ACTION_TRIGGER_ALARM_PREVIEW) {
            triggerSoundResponse("Comprobación de alarma")
            return START_STICKY
        }

        if (action == ACTION_SNOOZE_30_MIN) {
            snooze30Minutes()
            return START_STICKY
        }

        if (action == ACTION_RESUME) {
            resumeFromSnooze()
            return START_STICKY
        }

        try {
            startAsForeground()
            startListeningLoop()
            if (repository.bluetoothAlertEnabled.value) {
                registerBluetoothReceiver()
            }
            return START_STICKY
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar el servicio en primer plano (restricción Android 14+ o permiso ausente): ${e.message}", e)
            _isServiceActive.value = false
            repository.setIsListening(false)
            stopSelf()
            return START_NOT_STICKY
        }
    }

    private fun startAsForeground() {
        val triggerMode = repository.triggerMode.value
        val customWord = repository.customTriggerPhrase.value
        val (notifTitle, notifText) = when (triggerMode) {
            TriggerMode.VOICE_MODE -> Pair("Escuchando: Modo voz", "Di \"$customWord\" para localizar el móvil")
            TriggerMode.CLAP_TWICE -> Pair("Escuchando: 2 Palmadas", "Da dos palmadas seguidas para localizar el móvil")
            TriggerMode.WHISTLE -> Pair("Escuchando: Silbido", "Silba para localizar el móvil")
        }

        val notification = buildNotification(
            title = notifTitle,
            text = notifText
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Validación estricta de permisos para Android 14+
                val hasRecordAudio = androidx.core.content.ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                if (!hasRecordAudio) {
                    Log.w(TAG, "Permiso RECORD_AUDIO no concedido para Foreground Service Microphone")
                    throw SecurityException("Permiso RECORD_AUDIO requerido para iniciar servicio de escucha")
                }

                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en startForeground (Android 14+ background restriction): ${e.message}", e)
            throw e
        }
    }

    private fun updateNotificationForMode(mode: TriggerMode) {
        updateNotificationForCurrentState()
    }

    private fun muteSpeechBeeps() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
            } else {
                @Suppress("DEPRECATION")
                am.setStreamMute(AudioManager.STREAM_SYSTEM, true)
                @Suppress("DEPRECATION")
                am.setStreamMute(AudioManager.STREAM_NOTIFICATION, true)
            }
            isBeepMuted = true
        } catch (e: Exception) {
            Log.w(TAG, "Error muting speech beeps", e)
        }
    }

    private fun unmuteSpeechBeeps() {
        if (!isBeepMuted) return
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            } else {
                @Suppress("DEPRECATION")
                am.setStreamMute(AudioManager.STREAM_SYSTEM, false)
                @Suppress("DEPRECATION")
                am.setStreamMute(AudioManager.STREAM_NOTIFICATION, false)
            }
            isBeepMuted = false
        } catch (e: Exception) {
            Log.w(TAG, "Error unmuting speech beeps", e)
        }
    }

    private fun startListeningLoop() {
        if (isDestroyed || isResponding) return

        val triggerMode = repository.triggerMode.value
        Log.d(TAG, "Iniciando bucle de escucha exclusivo para modo: $triggerMode")

        when (triggerMode) {
            TriggerMode.VOICE_MODE -> {
                acousticDetector?.stopListening()
                if (isMediaPlaybackActive()) {
                    Log.d(TAG, "Video/música en reproducción activa: posponiendo SpeechRecognizer para no alterar volumen del video.")
                    scheduleRestart(2500L)
                } else {
                    startSpeechRecognitionLoop()
                }
            }
            TriggerMode.CLAP_TWICE -> {
                destroySpeechRecognizer()
                acousticDetector?.startListening(modeIsClap = true)
            }
            TriggerMode.WHISTLE -> {
                destroySpeechRecognizer()
                acousticDetector?.startListening(modeIsClap = false)
            }
        }
    }

    private fun startWatchdog() {
        cancelWatchdog()
        recognitionWatchdogRunnable = Runnable {
            if (!isDestroyed && !isResponding && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                Log.w(TAG, "Watchdog de voz activado: el motor no respondió tras 9s. Reiniciando para mantener escucha continua...")
                destroySpeechRecognizer()
                scheduleRestart(250)
            }
        }
        handler.postDelayed(recognitionWatchdogRunnable!!, 9000L)
    }

    private fun cancelWatchdog() {
        recognitionWatchdogRunnable?.let { handler.removeCallbacks(it) }
        recognitionWatchdogRunnable = null
    }

    private fun destroySpeechRecognizer() {
        cancelWatchdog()
        handler.removeCallbacksAndMessages(null)
        unmuteSpeechBeeps()
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        isCurrentlyRecognizing = false
    }

    private fun stopSpeechRecognizerSafely() {
        destroySpeechRecognizer()
    }

    private fun startSpeechRecognitionLoop() {
        if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
            destroySpeechRecognizer()
            return
        }

        handler.post {
            if (isDestroyed || isResponding || repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
                return@post
            }

            // Si el usuario está viendo un video o escuchando música, posponer para no bajar el volumen del video (evita ducking)
            if (isMediaPlaybackActive()) {
                Log.d(TAG, "Video/música reproduciéndose en el dispositivo: posponiendo SpeechRecognizer para no alterar el volumen del video.")
                scheduleRestart(2500L)
                return@post
            }

            try {
                if (speechRecognizer == null) {
                    if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                        Log.w(TAG, "SpeechRecognizer not available on this device")
                        return@post
                    }
                    val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer.setRecognitionListener(createRecognitionListener())
                    speechRecognizer = recognizer
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
                }

                muteSpeechBeeps()
                isCurrentlyRecognizing = true
                speechRecognizer?.startListening(intent)
                startWatchdog()
            } catch (e: Exception) {
                Log.e(TAG, "Error starting speech recognition", e)
                destroySpeechRecognizer()
                if (repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                    scheduleRestart(1000L)
                }
            }
        }
    }

    private fun createRecognitionListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
                return
            }
            isCurrentlyRecognizing = true
            startWatchdog()
            handler.postDelayed({
                unmuteSpeechBeeps()
            }, 300)
        }

        override fun onBeginningOfSpeech() {
            if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
            } else {
                startWatchdog()
            }
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                _audioRms.value = rmsdB
            }
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            cancelWatchdog()
            isCurrentlyRecognizing = false
            unmuteSpeechBeeps()
        }

        override fun onError(error: Int) {
            cancelWatchdog()
            Log.d(TAG, "SpeechRecognizer onError code: $error")
            isCurrentlyRecognizing = false
            unmuteSpeechBeeps()

            if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
                return
            }

            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    // Silencio normal esperando que el usuario hable: reiniciar de inmediato
                    if (!isResponding && !isDestroyed && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                        scheduleRestart(200)
                    }
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT,
                SpeechRecognizer.ERROR_AUDIO,
                SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> {
                    // Error de estado o binder del reconocedor: recrear de cero para no quedar bloqueado
                    destroySpeechRecognizer()
                    if (!isResponding && !isDestroyed && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                        scheduleRestart(600)
                    }
                }
                else -> {
                    destroySpeechRecognizer()
                    if (!isResponding && !isDestroyed && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                        scheduleRestart(800)
                    }
                }
            }
        }

        override fun onResults(results: Bundle?) {
            cancelWatchdog()
            isCurrentlyRecognizing = false
            unmuteSpeechBeeps()
            if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
                return
            }
            val triggered = processRecognizedTexts(results)
            if (!triggered && !isResponding && !isDestroyed && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                scheduleRestart(250)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
                destroySpeechRecognizer()
                return
            }
            val triggered = processRecognizedTexts(partialResults)
            if (triggered) {
                cancelWatchdog()
                destroySpeechRecognizer()
            } else {
                startWatchdog()
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun processRecognizedTexts(bundle: Bundle?): Boolean {
        if (isResponding) return false
        // FILTRO DE MODO EXCLUSIVO: Si no está en modo voz, destruir reconocedor y descartar
        if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
            Log.d(TAG, "Voz ignorada: el modo actual es ${repository.triggerMode.value}")
            destroySpeechRecognizer()
            return false
        }
        if (motionController?.isPhoneInActiveMotion() == true) {
            Log.d(TAG, "Voz ignorada: el usuario tiene el teléfono en la mano o en movimiento activo")
            return false
        }
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        for (match in matches) {
            val lower = match.lowercase(Locale.ROOT)
            _lastHeardText.value = match
            if (isTriggerWord(lower)) {
                triggerSoundResponse("Oído: $match")
                return true
            }
        }
        return false
    }

    /**
     * Detección para la frase o palabra configurada por el usuario (por defecto "Hey Móvil" o cualquier palabra personalizada).
     * Normaliza tildes y caracteres para maximizar la sensibilidad y tolerancia al hablar.
     * Si el usuario configuró una palabra personalizada, SOLO responderá a esa palabra personalizada.
     * Si está con el valor por defecto ("Hey Móvil"), detecta variantes en español y también interpretaciones
     * en inglés que a menudo produce Google SpeechRecognizer (como "hey mobile", "ok mobile", "a mobile").
     */
    /**
     * Detección para la frase o palabra configurada por el usuario (por defecto "Hey Móvil" o cualquier palabra personalizada).
     * Normaliza tildes y caracteres.
     * Si el usuario configuró una palabra personalizada, SOLO responderá a esa palabra personalizada.
     * Si está con el valor por defecto ("Hey Móvil"), exige coincidencia exacta o estricta fonética
     * de "hey móvil" / "oye móvil" / "hola móvil" para evitar que ruidos ambientales o palabras
     * aisladas ("móvil", "el móvil", "aquí", etc.) provoquen falsos positivos.
     */
    private fun isTriggerWord(text: String): Boolean {
        val clean = normalizeText(text)
        if (clean.isBlank()) return false
        val customPhrase = normalizeText(repository.customTriggerPhrase.value)

        val isDefault = customPhrase.isBlank() ||
                customPhrase == "hey movil" ||
                customPhrase == "hey mobile" ||
                customPhrase == "modo voz"

        if (!isDefault) {
            // El usuario configuró una palabra personalizada específica (ej: "hola", "buscar", "donde estas"):
            // 1. Coincidencia directa por frase completa o subfrase
            if (clean.contains(customPhrase)) {
                return true
            }

            // 2. Si la frase personalizada consta de múltiples palabras (ej: "mi telefono"), exigir TODAS las palabras
            val wordsInTrigger = customPhrase.split(" ").filter { it.length >= 2 }
            if (wordsInTrigger.size >= 2 && wordsInTrigger.all { clean.contains(it) }) {
                return true
            }

            // 3. Tolerancia difusa estricta solo para la frase completa
            if (isStrictFuzzyMatch(clean, customPhrase)) {
                return true
            }

            return false
        }

        // Modo por defecto ("Hey Móvil"):
        // Frases intencionales completas de invocación. NUNCA palabras sueltas como "móvil" o "aquí".
        val defaultExactPhrases = listOf(
            "hey movil", "ey movil", "oye movil", "hola movil", "hay movil", "hei movil",
            "hey mobil", "ey mobil", "oye mobil", "hola mobil",
            "hey mobile", "ey mobile", "hi mobile", "ok mobile", "ay mobile"
        )

        // 1. Coincidencia exacta o contenida de la frase intencional
        if (defaultExactPhrases.any { clean.contains(it) }) {
            return true
        }

        // 2. Coincidencia difusa estricta con "hey movil" o "hey mobile"
        // Exige que la longitud y distancia fonética coincidan estrechamente para no dispararse con ruido de fondo
        if (isStrictFuzzyMatch(clean, "hey movil") || isStrictFuzzyMatch(clean, "hey mobile")) {
            return true
        }

        return false
    }

    /**
     * Coincidencia difusa estricta: evita falsos positivos por palabras aisladas.
     * Solo valida si la frase hablada o un bigrama de palabras contiguas tiene alta similitud con el objetivo.
     */
    private fun isStrictFuzzyMatch(spoken: String, target: String): Boolean {
        if (spoken.isBlank() || target.isBlank()) return false
        val spokenTrimmed = spoken.trim()
        val targetTrimmed = target.trim()

        // 1. Coincidencia global con distancia de edición muy estricta (mínimo 80% de similitud)
        if (kotlin.math.abs(spokenTrimmed.length - targetTrimmed.length) <= 3) {
            val dist = levenshteinDistance(spokenTrimmed, targetTrimmed)
            val maxLen = kotlin.math.max(spokenTrimmed.length, targetTrimmed.length)
            if (maxLen > 0 && (1.0 - dist.toDouble() / maxLen) >= 0.80) {
                return true
            }
        }

        // 2. Si el texto hablado tiene varias palabras ("decir hey movil por favor"),
        // buscar bigramas contiguos que coincidan con la frase de 2 palabras (ej: "hey movil")
        val spokenTokens = spokenTrimmed.split(" ").filter { it.isNotBlank() }
        val targetTokens = targetTrimmed.split(" ").filter { it.isNotBlank() }

        if (targetTokens.size == 2 && spokenTokens.size >= 2) {
            for (i in 0 until spokenTokens.size - 1) {
                val bigram = "${spokenTokens[i]} ${spokenTokens[i + 1]}"
                val dist = levenshteinDistance(bigram, targetTrimmed)
                val maxLen = kotlin.math.max(bigram.length, targetTrimmed.length)
                if (maxLen > 0 && (1.0 - dist.toDouble() / maxLen) >= 0.82) {
                    return true
                }
            }
        }

        return false
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val m = s1.length
        val n = s2.length
        val dp = Array(m + 1) { IntArray(n + 1) }
        for (i in 0..m) dp[i][0] = i
        for (j in 0..n) dp[0][j] = j
        for (i in 1..m) {
            for (j in 1..n) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[m][n]
    }

    private fun normalizeText(text: String): String {
        return text.lowercase(Locale.ROOT).trim()
            .replace("á", "a")
            .replace("é", "e")
            .replace("í", "i")
            .replace("ó", "o")
            .replace("ú", "u")
            .replace("ü", "u")
            .replace("ñ", "n")
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
    }

    /**
     * Calcula la progresión de volumen (50% -> 75% -> 100% en menos de 30 segundos).
     */
    private fun calculateNextVolumeRatio(): Float {
        val now = System.currentTimeMillis()
        val elapsedSec = (now - lastCallTimestampMs) / 1000L

        if (lastCallTimestampMs == 0L || elapsedSec >= 30) {
            // Pasaron más de 30 segundos: reiniciar al 50%
            consecutiveCallLevel = 1
        } else {
            // Llamada reiterada en menos de 30 segundos: escalar
            consecutiveCallLevel = (consecutiveCallLevel + 1).coerceAtMost(3)
        }

        lastCallTimestampMs = now

        return when (consecutiveCallLevel) {
            1 -> 0.50f
            2 -> 0.75f
            else -> 1.00f
        }
    }

    fun triggerSoundResponse(triggerReason: String) {
        if (isResponding) return

        // Validación de modo exclusivo: Cada modo solo responde a su propio tipo de detección
        val currentMode = repository.triggerMode.value
        val isManualTest = triggerReason == "Prueba manual"
        when (currentMode) {
            TriggerMode.VOICE_MODE -> {
                if (!triggerReason.startsWith("Oído:") && !isManualTest) {
                    Log.d(TAG, "Trigger '$triggerReason' ignorado: el modo activo es exclusivamente 'Modo voz'")
                    return
                }
            }
            TriggerMode.CLAP_TWICE -> {
                if (!triggerReason.contains("palmada", ignoreCase = true) && !isManualTest) {
                    Log.d(TAG, "Trigger '$triggerReason' ignorado: el modo activo es exclusivamente '2 Palmadas'")
                    return
                }
            }
            TriggerMode.WHISTLE -> {
                if (!triggerReason.contains("silbido", ignoreCase = true) && !isManualTest) {
                    Log.d(TAG, "Trigger '$triggerReason' ignorado: el modo activo es exclusivamente 'Silbido'")
                    return
                }
            }
        }

        // Si el detector está silenciado temporalmente (Snooze 30 min), ignorar activación
        if (isSnoozed() && !isManualTest) {
            Log.d(TAG, "Trigger '$triggerReason' ignorado: detector silenciado temporalmente (Snooze 30 min)")
            return
        }

        // Si el usuario tiene configuradas Horas No Molestar y la hora local actual coincide, no sonar alarma
        if (repository.isCurrentlyInQuietHours() && !isManualTest) {
            Log.d(TAG, "Trigger '$triggerReason' ignorado: Horas No Molestar activas en el dispositivo")
            return
        }

        // Si el usuario tiene el teléfono en la mano o se está moviendo activamente, silenciar o pausar la alarma
        if (motionController?.isPhoneInActiveMotion() == true) {
            Log.d(TAG, "Trigger '$triggerReason' ignorado: el teléfono está en la mano o en movimiento activo")
            return
        }

        isResponding = true
        _isAlertActive.value = true
        _lastDetectionTime.value = System.currentTimeMillis()
        _lastHeardText.value = triggerReason

        // Detener micrófonos para que no escuchen el propio altavoz
        unmuteSpeechBeeps()
        handler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        acousticDetector?.stopListening()
        isCurrentlyRecognizing = false

        // Iniciar detector de recogida del teléfono (Pick-up gesture con acelerómetro)
        motionController?.startPickupDetection {
            Log.d(TAG, "Alarma silenciada automáticamente al levantar el teléfono")
            finishAlertResponse()
        }

        // Registrar receptor para apagar con el botón de encendido (pantalla apagada o doble pulsación)
        registerPowerButtonReceiver()

        // Calcular volumen progresivo (50% -> 75% -> 100%)
        val volumeRatio = calculateNextVolumeRatio()
        val volumePercentText = "${(volumeRatio * 100).toInt()}%"

        // ACTIVAR EFECTOS DE HARDWARE:
        // 1. Linterna con patrón configurado (estroboscópico, sos, fijo)
        // 2. Vibración según ajuste del usuario (baja, media, alta)
        val vibrationIntensity = repository.vibrationIntensity.value
        val flashPattern = repository.flashPattern.value
        alertEffects?.startEffects(vibrationIntensity, flashPattern)

        // 3. Abrir pantalla visual de emergencia animada a pantalla completa ("¡Aquí estoy!")
        try {
            val alertIntent = Intent(this, com.example.ui.components.FullScreenAlertActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(com.example.ui.components.FullScreenAlertActivity.EXTRA_TRIGGER_REASON, triggerReason)
            }
            startActivity(alertIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error launching FullScreenAlertActivity", e)
        }

        // Actualizar notificación
        val alertNotification = buildNotification(
            title = "¡Móvil detectado! 🔊 (Volumen $volumePercentText)",
            text = "$triggerReason - Linterna y vibración activadas"
        )
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, alertNotification)

        alertPlayJob?.cancel()
        alertPlayJob = serviceScope.launch {
            // Criterio de duración: si la grabación dura menos de 10s (o el sonido es corto),
            // se garantiza un mínimo de 10s en bucle. Si dura más, se reproduce hasta el tiempo de la
            // grabación con un límite absoluto e infranqueable de 60 segundos (o 60 segundos por defecto).
            val selectedSound = repository.getSelectedSound()
            val recordingDurationSec = selectedSound?.durationSeconds ?: 0
            val targetSeconds = if (recordingDurationSec > 0) {
                // Mínimo 10 segundos, máximo 60 segundos, o la duración del audio si está entre 10s y 60s
                recordingDurationSec.coerceIn(10, 60)
            } else {
                // Por defecto para sonidos del sistema o síntesis de voz: 60 segundos máximo
                60
            }
            val maxDurationMs = targetSeconds * 1000L
            val dndBypass = repository.dndBypass.value

            if (selectedSound != null) {
                val cycleDeferred = CompletableDeferred<Unit>()
                soundPlayer?.playAlarmCycle(
                    sound = selectedSound,
                    volumeRatio = volumeRatio,
                    maxDurationMs = maxDurationMs,
                    dndBypass = dndBypass
                ) {
                    cycleDeferred.complete(Unit)
                }
                cycleDeferred.await()
            } else {
                delay(maxDurationMs)
            }

            if (isResponding) {
                finishAlertResponse()
            }
        }
    }

    private fun finishAlertResponse() {
        alertPlayJob?.cancel()
        alertPlayJob = null

        motionController?.stopPickupDetection()
        unregisterPowerButtonReceiver()

        alertEffects?.stopEffects()
        soundPlayer?.stopSound()
        _isAlertActive.value = false

        // Restaurar notificación según estado actual (silenciado o escuchando)
        updateNotificationForCurrentState()

        // Esperar cooldown y reiniciar escucha
        handler.postDelayed({
            isResponding = false
            if (!isDestroyed && _isServiceActive.value) {
                startListeningLoop()
            }
        }, 1200)
    }

    private fun registerPowerButtonReceiver() {
        if (powerButtonReceiver != null) return
        powerButtonReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action ?: return
                val now = System.currentTimeMillis()

                if (action == Intent.ACTION_SCREEN_OFF) {
                    Log.d(TAG, "Botón de encendido presionado (pantalla apagada) -> Deteniendo alarma")
                    finishAlertResponse()
                } else if (action == Intent.ACTION_SCREEN_ON) {
                    if (now - lastPowerPressTimeMs < 1600L) {
                        powerPressCount++
                    } else {
                        powerPressCount = 1
                    }
                    lastPowerPressTimeMs = now

                    if (powerPressCount >= 2) {
                        Log.d(TAG, "Doble pulsación de encendido detectada -> Deteniendo alarma")
                        finishAlertResponse()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        try {
            ContextCompat.registerReceiver(
                this,
                powerButtonReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error registering power button receiver", e)
        }
    }

    private fun unregisterPowerButtonReceiver() {
        powerButtonReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (_: Exception) {}
        }
        powerButtonReceiver = null
        powerPressCount = 0
    }

    private fun registerBluetoothReceiver() {
        if (bluetoothReceiver == null) {
            bluetoothReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    val action = intent?.action ?: return
                    if (action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                        triggerBluetoothDisconnectAlert()
                    }
                }
            }
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            try {
                ContextCompat.registerReceiver(
                    this,
                    bluetoothReceiver,
                    filter,
                    ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (e: Exception) {
                Log.w(TAG, "Error registering audio noisy receiver", e)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback == null) {
            audioDeviceCallback = object : android.media.AudioDeviceCallback() {
                override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) {
                    super.onAudioDevicesRemoved(removedDevices)
                    val hadBt = removedDevices?.any { dev ->
                        dev.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                        dev.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && dev.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET)
                    } ?: false
                    if (hadBt) {
                        triggerBluetoothDisconnectAlert()
                    }
                }
            }
            try {
                audioManager?.registerAudioDeviceCallback(audioDeviceCallback, handler)
            } catch (e: Exception) {
                Log.w(TAG, "Error registering audio device callback", e)
            }
        }
    }

    private fun triggerBluetoothDisconnectAlert() {
        if (repository.bluetoothAlertEnabled.value && _isServiceActive.value && !isResponding) {
            Log.d(TAG, "Auriculares Bluetooth desconectados detectado")
            soundPlayer?.playShortNotificationBeep()
            alertEffects?.vibrateShortNotification()

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notif = buildNotification(
                title = "Auriculares desconectados",
                text = "Se ha perdido la conexión Bluetooth mientras el detector está activo"
            )
            notificationManager.notify(NOTIFICATION_ID, notif)
        }
    }

    private fun unregisterBluetoothReceiver() {
        bluetoothReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (_: Exception) {}
        }
        bluetoothReceiver = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback != null) {
            try {
                audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback)
            } catch (_: Exception) {}
            audioDeviceCallback = null
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || isResponding) return
        if (repository.triggerMode.value != TriggerMode.VOICE_MODE) {
            destroySpeechRecognizer()
            return
        }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!isDestroyed && !isResponding && _isServiceActive.value && repository.triggerMode.value == TriggerMode.VOICE_MODE) {
                if (isMediaPlaybackActive()) {
                    Log.d(TAG, "Video/música aún en reproducción; posponiendo bucle para no alterar el volumen del video.")
                    scheduleRestart(2500L)
                } else {
                    startSpeechRecognitionLoop()
                }
            }
        }, delayMs)
    }

    private fun buildNotification(title: String, text: String, isSnoozeState: Boolean = false): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceDetectionService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (isSnoozeState) {
            val resumeIntent = Intent(this, VoiceDetectionService::class.java).apply {
                action = ACTION_RESUME
            }
            val resumePendingIntent = PendingIntent.getService(
                this,
                2,
                resumeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_media_play, "Reanudar", resumePendingIntent)
        } else {
            val snoozeIntent = Intent(this, VoiceDetectionService::class.java).apply {
                action = ACTION_SNOOZE_30_MIN
            }
            val snoozePendingIntent = PendingIntent.getService(
                this,
                3,
                snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_lock_idle_alarm, "Silenciar 30 min", snoozePendingIntent)
        }

        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPendingIntent)
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Detección y localización del móvil",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificación persistente para búsqueda del teléfono"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundService() {
        if (isDestroyed) return
        isDestroyed = true
        isResponding = false
        cancelWatchdog()
        handler.removeCallbacksAndMessages(null)
        unmuteSpeechBeeps()
        _isServiceActive.value = false
        _isAlertActive.value = false
        repository.setIsListening(false)
        com.example.widget.DetectorWidgetProvider.updateAllWidgets(this, false)

        alertPlayJob?.cancel()
        alertPlayJob = null

        motionController?.stopMonitoring()
        motionController = null

        unregisterPowerButtonReceiver()
        unregisterBluetoothReceiver()
        unregisterPlaybackCallback()

        alertEffects?.stopEffects()
        alertEffects = null

        acousticDetector?.stopListening()
        acousticDetector = null

        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {}

        soundPlayer?.release()
        soundPlayer = null

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}

        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopForegroundService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "movil_detection_service_channel"
        const val NOTIFICATION_ID = 4040

        const val ACTION_START = "com.example.action.START_DETECTION"
        const val ACTION_STOP = "com.example.action.STOP_DETECTION"
        const val ACTION_STOP_ALERT = "com.example.action.STOP_ALERT"
        const val ACTION_TRIGGER_ALARM_PREVIEW = "com.example.action.TRIGGER_ALARM_PREVIEW"
        const val ACTION_SNOOZE_30_MIN = "com.example.action.SNOOZE_30_MIN"
        const val ACTION_RESUME = "com.example.action.RESUME"

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        private val _isAlertActive = MutableStateFlow(false)
        val isAlertActive: StateFlow<Boolean> = _isAlertActive.asStateFlow()

        private val _lastDetectionTime = MutableStateFlow(0L)
        val lastDetectionTime: StateFlow<Long> = _lastDetectionTime.asStateFlow()

        private val _lastHeardText = MutableStateFlow("")
        val lastHeardText: StateFlow<String> = _lastHeardText.asStateFlow()

        private val _audioRms = MutableStateFlow(0f)
        val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

        private val _snoozeUntil = MutableStateFlow(0L)
        val snoozeUntil: StateFlow<Long> = _snoozeUntil.asStateFlow()

        fun snooze30Min(context: Context) {
            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_SNOOZE_30_MIN
            }
            context.startService(intent)
        }

        fun resume(context: Context) {
            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_RESUME
            }
            context.startService(intent)
        }

        fun start(context: Context) {
            val hasRecordAudio = androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

            if (!hasRecordAudio) {
                Log.w("VoiceDetectionService", "No se puede iniciar el servicio: falta permiso RECORD_AUDIO")
                _isServiceActive.value = false
                SoundRepository.getInstance(context).setIsListening(false)
                return
            }

            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_START
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e("VoiceDetectionService", "Error al iniciar el servicio (Android 14+ background restriction): ${e.message}", e)
                _isServiceActive.value = false
                SoundRepository.getInstance(context).setIsListening(false)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun stopAlertResponse(context: Context) {
            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_STOP_ALERT
            }
            context.startService(intent)
        }

        fun triggerAlarmPreview(context: Context) {
            val intent = Intent(context, VoiceDetectionService::class.java).apply {
                action = ACTION_TRIGGER_ALARM_PREVIEW
            }
            context.startService(intent)
        }
    }
}

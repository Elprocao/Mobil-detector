package com.example

import com.example.data.model.AcousticSensitivity
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun acousticSensitivity_thresholdHierarchy() {
    // High sensitivity should have a lower threshold (more sensitive to quiet sounds)
    assertTrue(AcousticSensitivity.HIGH.thresholdFactor < AcousticSensitivity.MEDIUM.thresholdFactor)
    assertTrue(AcousticSensitivity.MEDIUM.thresholdFactor < AcousticSensitivity.LOW.thresholdFactor)
    assertEquals(0.50f, AcousticSensitivity.MEDIUM.thresholdFactor, 0.001f)
  }
}

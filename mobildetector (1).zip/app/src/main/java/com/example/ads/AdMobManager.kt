package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Gestor centralizado para la carga y visualización de anuncios Intersticiales y Bonificados de AdMob,
 * con cumplimiento oficial de la directiva europea GDPR y el SDK de Consentimiento UMP (User Messaging Platform) de Google.
 * Incluye tolerancia a fallos: utiliza prioritariamente los bloques de anuncios reales del usuario
 * (de su cuenta AdMob), y si Google aún no tiene inventario activo (código 3 No Fill en bloques nuevos),
 * recurre al bloque de pruebas oficial de AdMob para que los anuncios siempre funcionen en pruebas/emulador.
 */
object AdMobManager {
    private const val TAG = "AdMobManager"

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    @Volatile
    private var isMobileAdsInitialized = false

    /**
     * Solicita información de consentimiento UMP (GDPR / Reino Unido) y muestra el formulario si es necesario.
     * Solo inicializa Google Mobile Ads si el usuario ha otorgado consentimiento o las leyes de su región lo permiten.
     */
    fun gatherConsentAndInitialize(activity: Activity, onComplete: (() -> Unit)? = null) {
        try {
            val params = ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build()

            val consentInformation = UserMessagingPlatform.getConsentInformation(activity)
            consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                        if (formError != null) {
                            Log.w(TAG, "UMP consent form error: ${formError.errorCode}: ${formError.message}")
                        }
                        if (consentInformation.canRequestAds()) {
                            initializeMobileAds(activity)
                        }
                        onComplete?.invoke()
                    }
                },
                { requestConsentError ->
                    Log.w(TAG, "UMP consent info update failed: ${requestConsentError.errorCode}: ${requestConsentError.message}")
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAds(activity)
                    }
                    onComplete?.invoke()
                }
            )

            // Si el consentimiento ya fue concedido en sesiones anteriores
            if (consentInformation.canRequestAds()) {
                initializeMobileAds(activity)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error gathering UMP consent: ${e.message}", e)
            initializeMobileAds(activity)
            onComplete?.invoke()
        }
    }

    /**
     * Inicializa Google Mobile Ads de forma segura una sola vez tras la resolución de consentimiento.
     */
    fun initializeMobileAds(context: Context) {
        if (isMobileAdsInitialized) return
        isMobileAdsInitialized = true
        try {
            MobileAds.initialize(context) {
                Log.d(TAG, "Google Mobile Ads inicializado con éxito bajo consentimiento GDPR/UMP")
                loadInterstitial(context)
                loadRewarded(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando Google Mobile Ads", e)
        }
    }

    /**
     * Permite reabrir las opciones de privacidad y cookies para usuarios europeos desde el menú de Ajustes / Legal.
     */
    fun isPrivacyOptionsRequired(context: Context): Boolean {
        return try {
            val consentInformation = UserMessagingPlatform.getConsentInformation(context)
            consentInformation.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        } catch (_: Exception) {
            false
        }
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: (() -> Unit)? = null) {
        try {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
                if (formError != null) {
                    Log.w(TAG, "Error showing privacy options form: ${formError.message}")
                }
                onDismissed?.invoke()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception showing privacy options form: ${e.message}", e)
            onDismissed?.invoke()
        }
    }

    fun isInterstitialReady(): Boolean = interstitialAd != null

    fun isRewardedReady(): Boolean = rewardedAd != null

    /**
     * Precarga un anuncio intersticial (cada 5 minutos).
     */
    fun loadInterstitial(context: Context, onLoaded: (() -> Unit)? = null) {
        if (interstitialAd != null) {
            onLoaded?.invoke()
            return
        }
        if (isInterstitialLoading) return
        isInterstitialLoading = true

        val appContext = context.applicationContext
        val adUnitId = AdMobConfig.REAL_INTERSTITIAL_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            appContext,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Anuncio Intersticial real cargado con éxito ($adUnitId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isInterstitialLoading = false
                    Log.w(TAG, "Intersticial real no listo aún ($adUnitId): ${error.message} (Código ${error.code}). Conmutando al bloque de prueba oficial...")
                    // Fallback automático al ID de prueba oficial de AdMob
                    loadInterstitialFallback(appContext, onLoaded)
                }
            }
        )
    }

    private fun loadInterstitialFallback(context: Context, onLoaded: (() -> Unit)? = null) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        val appContext = context.applicationContext
        val fallbackId = AdMobConfig.TEST_INTERSTITIAL_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            appContext,
            fallbackId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Anuncio Intersticial de respaldo AdMob cargado con éxito ($fallbackId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.e(TAG, "Fallo al cargar Intersticial de respaldo: ${error.message} (Código ${error.code})")
                }
            }
        )
    }

    /**
     * Muestra el anuncio intersticial si está listo.
     */
    fun showInterstitial(activity: Activity, onAdFinished: () -> Unit): Boolean {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdFinished()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdFinished()
                }
            }
            ad.show(activity)
            return true
        } else {
            loadInterstitial(activity)
            onAdFinished()
            return false
        }
    }

    /**
     * Precarga un anuncio bonificado (para desbloquear slots de sonido).
     */
    fun loadRewarded(context: Context, onLoaded: (() -> Unit)? = null) {
        if (rewardedAd != null) {
            onLoaded?.invoke()
            return
        }
        if (isRewardedLoading) return
        isRewardedLoading = true

        val appContext = context.applicationContext
        val adUnitId = AdMobConfig.REAL_REWARDED_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            appContext,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Anuncio Bonificado real cargado con éxito ($adUnitId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isRewardedLoading = false
                    Log.w(TAG, "Bonificado real no listo aún ($adUnitId): ${error.message} (Código ${error.code}). Conmutando al bloque de prueba oficial...")
                    // Fallback automático al ID de prueba oficial de AdMob
                    loadRewardedFallback(appContext, onLoaded)
                }
            }
        )
    }

    private fun loadRewardedFallback(context: Context, onLoaded: (() -> Unit)? = null) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        val appContext = context.applicationContext
        val fallbackId = AdMobConfig.TEST_REWARDED_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            appContext,
            fallbackId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Anuncio Bonificado de respaldo AdMob cargado con éxito ($fallbackId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.e(TAG, "Fallo al cargar Bonificado de respaldo: ${error.message} (Código ${error.code})")
                }
            }
        )
    }

    /**
     * Muestra el anuncio bonificado si está listo.
     */
    fun showRewarded(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdDismissed: () -> Unit
    ): Boolean {
        val ad = rewardedAd
        if (ad != null) {
            var rewardGranted = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    if (rewardGranted) {
                        onRewardEarned()
                    }
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onAdDismissed()
                }
            }

            ad.show(activity) { _ ->
                rewardGranted = true
            }
            return true
        } else {
            loadRewarded(activity)
            return false
        }
    }

    /**
     * Muestra el anuncio bonificado si ya está cargado, o lo solicita de inmediato
     * y lo muestra tan pronto termine de cargar.
     */
    fun showRewardedWithAutoLoad(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdDismissed: () -> Unit,
        onAdUnavailable: () -> Unit
    ) {
        if (rewardedAd != null) {
            showRewarded(activity, onRewardEarned, onAdDismissed)
        } else {
            loadRewarded(activity) {
                if (rewardedAd != null) {
                    showRewarded(activity, onRewardEarned, onAdDismissed)
                } else {
                    onAdUnavailable()
                }
            }
        }
    }
}

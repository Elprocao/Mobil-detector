package com.example.data.model

/**
 * Nivel de sensibilidad para la detección acústica (palmadas y silbidos).
 * - LOW: Entornos ruidosos (salón con TV encendida, música o charlas). Exige mayor energía y claridad.
 * - MEDIUM: Entorno estándar equilibrado (habitaciones normales u oficinas). Por defecto.
 * - HIGH: Entornos silenciosos o cuando el teléfono está lejos / bajo mantas.
 */
enum class AcousticSensitivity(
    val id: Int,
    val titleKey: String,
    val clapAmpThreshold: Int,
    val clapRmsThreshold: Double,
    val whistleRmsThreshold: Double
) {
    LOW(
        id = 0,
        titleKey = "Baja",
        clapAmpThreshold = 13500,
        clapRmsThreshold = 850.0,
        whistleRmsThreshold = 115.0
    ),
    MEDIUM(
        id = 1,
        titleKey = "Media",
        clapAmpThreshold = 9500,
        clapRmsThreshold = 600.0,
        whistleRmsThreshold = 75.0
    ),
    HIGH(
        id = 2,
        titleKey = "Alta",
        clapAmpThreshold = 6500,
        clapRmsThreshold = 420.0,
        whistleRmsThreshold = 48.0
    );

    companion object {
        fun fromId(id: Int): AcousticSensitivity {
            return entries.firstOrNull { it.id == id } ?: MEDIUM
        }
    }
}

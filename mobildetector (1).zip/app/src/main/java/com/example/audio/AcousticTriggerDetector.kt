package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.example.data.model.AcousticSensitivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detector de sonido acústico en tiempo real de alta precisión:
 * - 2 Palmadas: Detección estricta de pulsos impulsivos mecánicos con análisis de concentración
 *   sub-bloque (<15ms), factor de cresta elevado, y rechazo explícito de la voz humana mediante
 *   detección de periodicidad tonal/formantes ("hey móvil", habla, risas).
 * - Silbido: Detección matemática precisa por consistencia de cruces por cero (700 Hz - 2600 Hz),
 *   regularidad de semiperiodos sinusoidales y algoritmo Goertzel de pureza espectral.
 */
class AcousticTriggerDetector(
    private val context: Context,
    private val onTriggerDetected: (reason: String) -> Unit,
    private val onRmsUpdated: ((Float) -> Unit)? = null,
    private val isMotionSuppressed: (() -> Boolean)? = null,
    private val getSensitivity: (() -> AcousticSensitivity)? = null
) {
    private val TAG = "AcousticTriggerDetector"
    private val scope = CoroutineScope(Dispatchers.Default)
    private var listeningJob: Job? = null
    @Volatile
    private var audioRecord: AudioRecord? = null
    @Volatile
    private var isAudioRunning = false

    // Estados para 2 palmadas
    private var lastClapTimeMs = 0L
    private var clapCandidateTimeMs = 0L
    private var waitingForClapDecay = false
    private var candidateClapAmp = 0
    private var candidateClapRms = 0.0
    private var continuousSpeechCounter = 0
    private var lastClapTriggerTimeMs = 0L

    // Estados para silbidos (análisis espectral Goertzel + regularidad)
    private var whistleConfidence = 0
    private var lastWhistleTriggerTimeMs = 0L

    @SuppressLint("MissingPermission")
    fun startListening(modeIsClap: Boolean) {
        stopListening()

        val sampleRates = intArrayOf(16000, 44100, 22050)
        var selectedRate = 16000
        var record: AudioRecord? = null

        for (rate in sampleRates) {
            val minBuf = AudioRecord.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf > 0) {
                try {
                    val candidate = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        rate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        max(minBuf, 4096)
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        record = candidate
                        selectedRate = rate
                        break
                    } else {
                        candidate.release()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Sample rate $rate not supported: ${e.message}")
                }
            }
        }

        if (record == null) {
            Log.e(TAG, "No suitable AudioRecord found")
            return
        }

        try {
            record.startRecording()
            audioRecord = record
            isAudioRunning = true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting AudioRecord", e)
            try { record.release() } catch (_: Exception) {}
            return
        }

        lastClapTimeMs = 0L
        clapCandidateTimeMs = 0L
        waitingForClapDecay = false
        continuousSpeechCounter = 0
        whistleConfidence = 0

        listeningJob = scope.launch {
            val shortBuffer = ShortArray(1024)
            while (isActive && isAudioRunning) {
                val currentRecord = audioRecord ?: break
                if (currentRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) break

                val readCount = try {
                    currentRecord.read(shortBuffer, 0, shortBuffer.size)
                } catch (e: Exception) {
                    Log.w(TAG, "AudioRecord read interrumpido: ${e.message}")
                    -1
                }
                if (readCount <= 0 || !isAudioRunning) continue

                // Si el usuario tiene el móvil en la mano o se está moviendo activamente, suprimir detección
                if (isMotionSuppressed?.invoke() == true) {
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    continuousSpeechCounter = 0
                    whistleConfidence = 0
                    continue
                }

                // 1. Remoción de DC offset (sesgo de continua común en micrófonos)
                var sum = 0.0
                for (i in 0 until readCount) {
                    sum += shortBuffer[i].toInt()
                }
                val mean = sum / readCount

                var sumSquare = 0.0
                var maxAmp = 0
                var zeroCrossings = 0
                var prevSample = 0.0

                for (i in 0 until readCount) {
                    val sample = shortBuffer[i].toInt() - mean
                    sumSquare += sample * sample
                    val absSample = abs(sample).toInt()
                    if (absSample > maxAmp) maxAmp = absSample

                    if (i > 0 && ((sample >= 0 && prevSample < 0) || (sample < 0 && prevSample >= 0))) {
                        zeroCrossings++
                    }
                    prevSample = sample
                }

                val rms = sqrt(sumSquare / readCount)
                val rmsDb = (20 * kotlin.math.log10(rms.coerceAtLeast(1.0))).toFloat()
                onRmsUpdated?.invoke(rmsDb)

                val now = System.currentTimeMillis()

                if (modeIsClap) {
                    processClapDetection(
                        now = now,
                        buffer = shortBuffer,
                        readCount = readCount,
                        sampleRate = selectedRate,
                        maxAmp = maxAmp,
                        rms = rms,
                        zeroCrossings = zeroCrossings,
                        mean = mean
                    )
                } else {
                    processWhistleDetection(
                        buffer = shortBuffer,
                        readCount = readCount,
                        sampleRate = selectedRate,
                        rawRms = rms,
                        mean = mean
                    )
                }
            }
        }
    }

    /**
     * Detección de 2 Palmadas inteligente y completamente blindada contra la voz humana ("hey móvil"):
     * 1. Una palmada es un choque mecánico acústico concentrado en menos de 10-15 ms.
     *    Al dividir el bloque en sub-bloques de 256 muestras, >58% de toda la energía está concentrada en uno solo.
     * 2. La voz humana ("hey...", "móvil...", vocales) está sustentada a lo largo del tiempo (energía dispersa <45%).
     * 3. La voz humana posee vibración periódica de las cuerdas vocales (pitch en 80-350 Hz). Se calcula la
     *    autocorrelación normalizada en esta banda fundamental; si existe periodicidad vocal (>0.36), se DESCARTA de raíz.
     * 4. Requiere 2 palmadas con ritmo natural (intervalo de 200ms a 1200ms) y decaimiento rápido posterior.
     */
    private fun processClapDetection(
        now: Long,
        buffer: ShortArray,
        readCount: Int,
        sampleRate: Int,
        maxAmp: Int,
        rms: Double,
        zeroCrossings: Int,
        mean: Double
    ) {
        // Enfriamiento tras disparar una detección
        if (now - lastClapTriggerTimeMs < 2500L) {
            lastClapTimeMs = 0L
            clapCandidateTimeMs = 0L
            waitingForClapDecay = false
            return
        }

        val crestFactor = if (rms > 0.0) maxAmp / rms else 0.0

        // 1. Verificación de decaimiento del cuadro posterior al impacto candidato
        if (waitingForClapDecay) {
            // En una palmada real, tras el golpe transitorio el nivel de audio se desploma inmediatamente
            val decayedFast = rms < candidateClapRms * 0.45 && maxAmp < candidateClapAmp * 0.50
            val reachedQuiet = rms < 900.0

            if (decayedFast || reachedQuiet) {
                // Confirmado como pulso impulsivo real (no es voz sostenida)
                val timeSinceFirstClap = clapCandidateTimeMs - lastClapTimeMs

                if (lastClapTimeMs > 0L && timeSinceFirstClap in 200..1200) {
                    // ¡Segunda palmada en la ventana de ritmo natural confirmada!
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    continuousSpeechCounter = 0
                    lastClapTriggerTimeMs = now
                    onTriggerDetected("¡2 Palmadas detectadas!")
                    return
                } else {
                    // Primera palmada registrada
                    lastClapTimeMs = clapCandidateTimeMs
                    continuousSpeechCounter = 0
                }
            }
            waitingForClapDecay = false
            clapCandidateTimeMs = 0L
        }

        // 2. Control de silencio entre palmadas y expiración
        if (lastClapTimeMs > 0L) {
            // Si pasó más de 1.2 segundos sin la segunda palmada, reiniciar
            if (now - lastClapTimeMs > 1200L) {
                lastClapTimeMs = 0L
                continuousSpeechCounter = 0
            } else {
                // Si durante el intervalo de espera entre palmadas hay voz o ruido sostenido continuo,
                // invalidamos la primera palmada (no fue un patrón silencioso de aplausos, sino conversación)
                if (rms > 1400.0) {
                    continuousSpeechCounter++
                    if (continuousSpeechCounter >= 3) {
                        lastClapTimeMs = 0L
                        continuousSpeechCounter = 0
                    }
                }
            }
        }

        // 3. Criterios acústicos de discriminación contra voz humana ("hey móvil"):
        // A) Umbral de amplitud de impacto según sensibilidad (Baja / Media / Alta)
        // B) Crest Factor alto (>3.8): relación pico a promedio de impacto
        // C) Conteo de cruces por cero transitorio elevado (>=48 normalizado a 16kHz)
        val sensitivity = getSensitivity?.invoke() ?: AcousticSensitivity.MEDIUM
        val minAmp = sensitivity.clapAmpThreshold
        val minRms = sensitivity.clapRmsThreshold
        val minZeroCrossings = (48.0 * readCount / 1024.0).toInt()

        if (maxAmp < minAmp || rms < minRms || crestFactor < 3.8 || zeroCrossings < minZeroCrossings) {
            return
        }

        // D) Concentración de energía sub-bloque: en una palmada (<15ms), la mayor parte de la energía
        // del bloque de 64ms se concentra en un solo sub-bloque de 256 muestras. En voz, se distribuye.
        val impulseConcentration = calculateImpulseConcentration(buffer, readCount, mean)
        if (impulseConcentration < 0.56) {
            return
        }

        // E) Rechazo explícito de voz por periodicidad armónica / pitch (80 Hz a 350 Hz):
        // La voz humana ("Hey", "Móvil", etc.) contiene periodicidad de cuerdas vocales con alta correlación.
        // Una palmada mecánica carece de periodicidad vocal (correlación típicamente <0.22).
        val voicePitchCorrelation = calculateVoicePitchCorrelation(buffer, readCount, sampleRate, mean)
        if (voicePitchCorrelation >= 0.36) {
            // Es voz humana, descartar inmediatamente
            return
        }

        // Si supera todos los filtros, es un impacto transitorio candidato
        clapCandidateTimeMs = now
        candidateClapAmp = maxAmp
        candidateClapRms = rms
        waitingForClapDecay = true
    }

    /**
     * Calcula la concentración de energía en sub-bloques de 256 muestras.
     * Retorna el porcentaje de energía total contenido en el sub-bloque más intenso.
     */
    private fun calculateImpulseConcentration(
        buffer: ShortArray,
        readCount: Int,
        mean: Double
    ): Double {
        val subBlockSize = 256
        val numBlocks = readCount / subBlockSize
        if (numBlocks < 2) return 1.0

        var maxBlockEnergy = 0.0
        var totalEnergy = 0.0

        for (b in 0 until numBlocks) {
            var blockEnergy = 0.0
            val offset = b * subBlockSize
            for (i in 0 until subBlockSize) {
                val s = buffer[offset + i].toDouble() - mean
                blockEnergy += s * s
            }
            if (blockEnergy > maxBlockEnergy) {
                maxBlockEnergy = blockEnergy
            }
            totalEnergy += blockEnergy
        }

        return if (totalEnergy > 1e-4) maxBlockEnergy / totalEnergy else 0.0
    }

    /**
     * Calcula la correlación de pitch en la banda fundamental de la voz humana (80 Hz a 350 Hz).
     * Una voz humana articulada ("Hey Móvil", vocales, sílabas) presenta picos de autocorrelación
     * superiores a 0.40 - 0.85. Un aplauso mecánico arroja valores cercanos a cero.
     */
    private fun calculateVoicePitchCorrelation(
        buffer: ShortArray,
        readCount: Int,
        sampleRate: Int,
        mean: Double
    ): Double {
        val minTau = (sampleRate / 350.0).toInt().coerceAtLeast(10)
        val maxTau = (sampleRate / 80.0).toInt().coerceAtMost(readCount / 2)
        if (minTau >= maxTau) return 0.0

        val windowSize = readCount - maxTau
        if (windowSize <= 0) return 0.0

        var baseEnergy = 0.0
        for (i in 0 until windowSize) {
            val s = buffer[i].toDouble() - mean
            baseEnergy += s * s
        }
        if (baseEnergy < 1000.0) return 0.0

        var maxCorr = 0.0
        // Muestreo con paso 2 para máxima eficiencia de CPU
        for (tau in minTau..maxTau step 2) {
            var dot = 0.0
            var delayedEnergy = 0.0
            for (i in 0 until windowSize) {
                val s1 = buffer[i].toDouble() - mean
                val s2 = buffer[i + tau].toDouble() - mean
                dot += s1 * s2
                delayedEnergy += s2 * s2
            }
            val denom = sqrt(baseEnergy * delayedEnergy)
            if (denom > 1e-4) {
                val r = dot / denom
                if (r > maxCorr) maxCorr = r
            }
        }
        return maxCorr
    }

    /**
     * Detección de Silbidos por análisis armónico Goertzel y regularidad sinusoidal:
     * - Rango de frecuencia del silbido humano: 700 Hz a 2600 Hz.
     * - Un silbido es una onda sinusoidal pura: la distancia entre cruces por cero sucesivos es
     *   extremadamente regular (coeficiente de variación CV < 0.22).
     * - Se evalúa la pureza espectral mediante el algoritmo Goertzel a la frecuencia detectada.
     *   Un silbido concentra más del 45% de toda la energía de audio en esa única frecuencia fundamental.
     * - Requiere que el tono se mantenga de forma continua durante ~150-200ms para evitar falsos positivos.
     */
    private fun processWhistleDetection(
        buffer: ShortArray,
        readCount: Int,
        sampleRate: Int,
        rawRms: Double,
        mean: Double
    ) {
        val now = System.currentTimeMillis()
        if (now - lastWhistleTriggerTimeMs < 2500L) {
            whistleConfidence = 0
            return
        }

        // Umbral de sensibilidad para detectar silbidos según ajuste (Baja / Media / Alta)
        val sensitivity = getSensitivity?.invoke() ?: AcousticSensitivity.MEDIUM
        val minWhistleRms = sensitivity.whistleRmsThreshold
        if (rawRms < minWhistleRms) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        // 1. Recolección de cruces por cero e intervalos entre ellos
        val crossingPositions = ArrayList<Double>(readCount / 4)
        var prevVal = buffer[0].toDouble() - mean

        for (i in 1 until readCount) {
            val currVal = buffer[i].toDouble() - mean
            if ((prevVal <= 0.0 && currVal > 0.0) || (prevVal >= 0.0 && currVal < 0.0)) {
                // Interpolación lineal precisa del punto exacto de cruce
                val delta = currVal - prevVal
                val frac = if (abs(delta) > 1e-4) -prevVal / delta else 0.5
                crossingPositions.add((i - 1) + frac.coerceIn(0.0, 1.0))
            }
            prevVal = currVal
        }

        val zeroCrossingCount = crossingPositions.size
        if (zeroCrossingCount < 8) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        // Frecuencia estimada a partir del ritmo de cruces por cero
        val estimatedFreq = (zeroCrossingCount / 2.0) * (sampleRate.toDouble() / readCount)

        // Rango de silbido humano típico (700 Hz a 2600 Hz)
        if (estimatedFreq !in 700.0..2600.0) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        // 2. Regularidad de los periodos: en una sinusoide pura, todos los semiperiodos tienen casi la misma longitud
        var intervalSum = 0.0
        val intervals = DoubleArray(zeroCrossingCount - 1)
        for (k in 0 until zeroCrossingCount - 1) {
            val interval = crossingPositions[k + 1] - crossingPositions[k]
            intervals[k] = interval
            intervalSum += interval
        }

        val meanInterval = intervalSum / intervals.size
        var varianceSum = 0.0
        for (interval in intervals) {
            val diff = interval - meanInterval
            varianceSum += diff * diff
        }
        val stdDev = sqrt(varianceSum / intervals.size)
        val cv = if (meanInterval > 1e-4) stdDev / meanInterval else 1.0

        // Un silbido real posee un CV < 0.22 (la voz o el soplido de aire superan 0.50)
        if (cv > 0.22) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        // 3. Algoritmo Goertzel para medir la concentración espectral en estimatedFreq
        val omega = 2.0 * Math.PI * (estimatedFreq / sampleRate)
        val coeff = 2.0 * cos(omega)

        var sPrev = 0.0
        var sPrev2 = 0.0
        var totalEnergy = 0.0

        for (i in 0 until readCount) {
            val x = buffer[i].toDouble() - mean
            totalEnergy += x * x
            val s = x + coeff * sPrev - sPrev2
            sPrev2 = sPrev
            sPrev = s
        }

        val power = sPrev * sPrev + sPrev2 * sPrev2 - coeff * sPrev * sPrev2
        val goertzelEnergy = (2.0 * power) / readCount
        val purityRatio = if (totalEnergy > 1e-4) (goertzelEnergy / totalEnergy).coerceIn(0.0, 1.0) else 0.0

        // Un silbido puro tiene más del 42% de su energía total en la frecuencia fundamental
        val isWhistleTone = purityRatio >= 0.42

        if (isWhistleTone) {
            whistleConfidence = min(6, whistleConfidence + 2)
            // Necesitamos aproximadamente 150-200ms de silbido confirmado para disparar
            val targetConfidence = max(3, (sampleRate * 0.15 / readCount).toInt())

            if (whistleConfidence >= targetConfidence) {
                whistleConfidence = 0
                lastWhistleTriggerTimeMs = now
                onTriggerDetected("¡Silbido detectado!")
            }
        } else {
            // Decaimiento gradual si hay pequeñas fluctuaciones al silbar
            whistleConfidence = max(0, whistleConfidence - 1)
        }
    }

    fun stopListening() {
        isAudioRunning = false
        val job = listeningJob
        listeningJob = null
        val record = audioRecord
        audioRecord = null

        job?.cancel()
        try {
            if (record != null) {
                if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                }
                record.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Excepción segura ignorada al detener/liberar AudioRecord: ${e.message}")
        }
    }
}


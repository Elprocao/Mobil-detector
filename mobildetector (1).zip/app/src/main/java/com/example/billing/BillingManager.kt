package com.example.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Gestor oficial de compras integradas (Google Play Billing Library v7).
 * Producto: "remove_ads_pro" (In-App Product de pago único para la Play Store).
 */
class BillingManager(
    private val context: Context,
    private val onPurchaseSuccess: () -> Unit
) : PurchasesUpdatedListener {

    companion object {
        private const val TAG = "BillingManager"
        const val PRODUCT_REMOVE_ADS = "remove_ads_pro"
        const val PRODUCT_REMOVE_ADS_ALT = "remove_ads"
    }

    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isBillingReady = MutableStateFlow(false)
    val isBillingReady: StateFlow<Boolean> = _isBillingReady.asStateFlow()

    private val _productPriceFormatted = MutableStateFlow("1,99 €")
    val productPriceFormatted: StateFlow<String> = _productPriceFormatted.asStateFlow()

    private var productDetails: ProductDetails? = null

    private val pendingPurchasesParams = PendingPurchasesParams.newBuilder()
        .enableOneTimeProducts()
        .build()

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(pendingPurchasesParams)
        .build()

    init {
        startConnection()
    }

    fun startConnection() {
        if (billingClient.isReady) {
            _isBillingReady.value = true
            queryProductDetails()
            queryPurchases()
            return
        }

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    Log.d(TAG, "Google Play Billing conectado correctamente.")
                    _isBillingReady.value = true
                    queryProductDetails()
                    queryPurchases()
                } else {
                    Log.w(TAG, "Conexión a Billing no exitosa: ${billingResult.debugMessage} (código ${billingResult.responseCode})")
                }
            }

            override fun onBillingServiceDisconnected() {
                Log.w(TAG, "Servicio de Billing desconectado.")
                _isBillingReady.value = false
            }
        })
    }

    fun queryProductDetails() {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRODUCT_REMOVE_ADS)
                .setProductType(BillingClient.ProductType.INAPP)
                .build(),
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRODUCT_REMOVE_ADS_ALT)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsResult ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val details = productDetailsResult.productDetailsList.firstOrNull {
                    it.productId == PRODUCT_REMOVE_ADS || it.productId == PRODUCT_REMOVE_ADS_ALT
                }
                if (details != null) {
                    productDetails = details
                    val price = details.oneTimePurchaseOfferDetails?.formattedPrice
                    if (!price.isNullOrBlank()) {
                        _productPriceFormatted.value = price
                        Log.d(TAG, "Precio de ${details.productId} obtenido de Play Store: $price")
                    }
                } else {
                    Log.d(TAG, "Producto no encontrado aún en catálogo local de Play Store.")
                }
            } else {
                Log.w(TAG, "Fallo al consultar producto: ${billingResult.debugMessage}")
            }
        }
    }

    fun queryPurchases(onResult: ((Boolean) -> Unit)? = null) {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()

        billingClient.queryPurchasesAsync(params) { billingResult, purchases ->
            var found = false
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                for (purchase in purchases) {
                    val hasProduct = purchase.products.contains(PRODUCT_REMOVE_ADS) ||
                        purchase.products.contains(PRODUCT_REMOVE_ADS_ALT)
                    if (hasProduct && purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        found = true
                        Log.d(TAG, "Compra previa activa encontrada: ${purchase.products}")
                        handlePurchase(purchase)
                    }
                }
            }
            scope.launch(Dispatchers.Main) {
                onResult?.invoke(found)
            }
        }
    }

    /**
     * Inicia el flujo oficial de compra de Google Play.
     */
    fun launchPurchase(activity: Activity, onError: (String) -> Unit) {
        val details = productDetails
        if (details != null && _isBillingReady.value) {
            val productDetailsParamsList = listOf(
                BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(details)
                    .build()
            )

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productDetailsParamsList)
                .build()

            val result = billingClient.launchBillingFlow(activity, flowParams)
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                Log.w(TAG, "Error iniciando pasarela Play: ${result.debugMessage}")
                onError(result.debugMessage.ifBlank { "No se pudo iniciar la compra con Google Play." })
            }
        } else {
            // Reintentar conexión con Play Store
            startConnection()
            onError("Conectando con Google Play Store... Por favor, comprueba tu conexión y vuelve a intentarlo en unos instantes.")
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.d(TAG, "Compra cancelada por el usuario en Google Play.")
        } else {
            Log.w(TAG, "Error en onPurchasesUpdated: ${billingResult.debugMessage} (código ${billingResult.responseCode})")
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            scope.launch {
                if (!purchase.isAcknowledged) {
                    val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()

                    billingClient.acknowledgePurchase(acknowledgePurchaseParams) { ackResult ->
                        if (ackResult.responseCode == BillingClient.BillingResponseCode.OK) {
                            Log.d(TAG, "Compra confirmada y reconocida en Google Play.")
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    onPurchaseSuccess()
                }
            }
        }
    }

    fun endConnection() {
        try {
            billingClient.endConnection()
        } catch (_: Exception) {}
    }
}

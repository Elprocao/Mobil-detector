# Guía Legal y Declaraciones para Publicar en Google Play Store
**Aplicación:** Móvil Detector (Android)  
**Fecha:** Septiembre 2026  

---

## 1. Documentos Legales Generados y su Alojamiento Público Gratuito

Google Play **rechaza cualquier aplicación** que no cuente con una URL web pública (HTTPS) de su Política de Privacidad en la ficha de Play Store.

Hemos creado los dos documentos HTML listos para ser publicados:
- `docs/privacy_policy.html` (Política de Privacidad adaptada a RGPD, LOPDGDD, CCPA y Google Play)
- `docs/terms_of_service.html` (Términos y Condiciones de Uso, limitaciones de responsabilidad y compras integradas)

### ¿Cómo activar tus URLs públicas gratis en 1 minuto con tu GitHub?
Dado que tu repositorio está en GitHub (`https://github.com/Elprocao/Mobil-detector`):
1. Entra en tu repositorio en GitHub y ve a **Settings** (Configuración) > **Pages**.
2. En **Build and deployment** > **Source**, elige **Deploy from a branch**.
3. En **Branch**, selecciona tu rama principal (ej. `main`) y la carpeta `/docs`.
4. Haz clic en **Save**.
5. ¡Listo! En unos segundos tendrás tus enlaces web públicos oficiales:
   - **Política de Privacidad:** `https://elprocao.github.io/Mobil-detector/privacy_policy.html`
   - **Términos de Servicio:** `https://elprocao.github.io/Mobil-detector/terms_of_service.html`

*(Estas URLs ya están enlazadas en los botones "Ver online" dentro de la aplicación).*

---

## 2. Respuestas para el Formulario de "Seguridad de los Datos" (Data Safety) en Google Play Console

Al rellenar la ficha en Google Play Console, te preguntará sobre qué datos recopila tu app. Debes contestar con la máxima precisión para evitar suspensiones:

### ¿Tu aplicación recopila o comparte alguno de los tipos de datos de usuario obligatorios?
- **Respuesta:** **Sí** (Debido al SDK de publicidad de Google AdMob).

### ¿Todos los datos de usuario recopilados por tu aplicación se cifran en tránsito?
- **Respuesta:** **Sí** (Todas las conexiones de AdMob y Google Play van por HTTPS).

### Audio / Voz (Micrófono):
- **¿Se recopila o comparte audio?** -> **NO**.
  - *Explicación técnica:* El micrófono procesa el sonido únicamente en la memoria RAM local del terminal para detectar palmadas/silbidos (On-Device Processing). No se almacena, no se graba de forma oculta y no sale del dispositivo.

### Datos recopilados por Google AdMob:
1. **Ubicación aproximada:**
   - ¿Recopilada? Sí.
   - ¿Compartida? Sí.
   - Finalidad: Publicidad y prevención del fraude.
2. **Identificadores del dispositivo (Advertising ID / GAID):**
   - ¿Recopilada? Sí.
   - ¿Compartida? Sí.
   - Finalidad: Publicidad y análisis de rendimiento de anuncios.
3. **Diagnósticos y rendimiento de la app (Crash logs):**
   - ¿Recopilada? Sí.
   - Finalidad: Análisis y optimización.

---

## 3. Justificación del Servicio en Primer Plano (`FOREGROUND_SERVICE_MICROPHONE`)

En Android 14+ (API 34), Google Play exige rellenar un formulario declarando por qué la app necesita escuchar en primer plano con la pantalla apagada.

**Texto sugerido para pegar en Google Play Console:**
> *"Móvil Detector es una utilidad diseñada para ayudar a los usuarios a encontrar su teléfono extraviado en una habitación u oficina mediante sonidos (palmadas, silbidos o comandos de voz). Para poder responder cuando el teléfono tiene la pantalla apagada o está en modo reposo, la aplicación requiere mantener activo el servicio en primer plano de tipo micrófono. El análisis acústico se procesa de forma exclusivamente efímera en la memoria local del dispositivo sin grabar ni transmitir datos de audio a servidores externos. El servicio muestra de forma permanente una notificación no descartable con controles directos para que el usuario siempre tenga control y visibilidad sobre el estado de la detección."*

---

## 4. Clasificación de Contenido y Menores (IARC / COPPA)
- **¿La app está dirigida principalmente a niños?** -> **No** (Seleccionar público general / mayores de 13 años o 16 años en la UE).
- **¿Contiene anuncios?** -> **Sí** (Marcado oficial: Contiene anuncios de Google AdMob).

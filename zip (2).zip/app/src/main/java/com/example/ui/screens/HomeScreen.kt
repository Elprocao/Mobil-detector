package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.app.Activity
import androidx.core.content.ContextCompat
import com.example.ads.AdMobManager
import com.example.data.model.SoundEntity
import com.example.ui.DetectionViewModel
import com.example.ui.components.AdBannerView
import com.example.ui.components.DeleteSoundDialog
import com.example.ui.components.EditSoundDialog
import com.example.ui.components.HeroStatusCard
import com.example.ui.components.LegalConsentGate
import com.example.ui.components.RecordSoundSheet
import com.example.ui.components.RemoveAdsDialog
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.components.SlotsInfoCard
import com.example.ui.components.SoundItemCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DetectionViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val sounds by viewModel.sounds.collectAsState()
    val selectedSoundId by viewModel.selectedSoundId.collectAsState()
    val unlockedSlots by viewModel.unlockedSlots.collectAsState()
    val adsRemoved by viewModel.adsRemoved.collectAsState()
    val productPriceFormatted by viewModel.productPriceFormatted.collectAsState()
    val purchaseMessage by viewModel.purchaseMessage.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val hasAcceptedLegalTerms by viewModel.hasAcceptedLegalTerms.collectAsState()

    var previousAdsRemoved by remember { mutableStateOf(adsRemoved) }
    LaunchedEffect(adsRemoved) {
        if (!previousAdsRemoved && adsRemoved) {
            snackbarHostState.showSnackbar("¡Versión PRO activada! Sin anuncios, hasta 60s por sonido y todos los espacios desbloqueados. 🚀")
        }
        previousAdsRemoved = adsRemoved
    }

    LaunchedEffect(purchaseMessage) {
        purchaseMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearPurchaseMessage()
        }
    }

    val vibrationIntensity by viewModel.vibrationIntensity.collectAsState()
    val triggerMode by viewModel.triggerMode.collectAsState()
    val customTriggerPhrase by viewModel.customTriggerPhrase.collectAsState()
    val checkMicPrivacy by viewModel.checkMicPrivacy.collectAsState()
    val flashPattern by viewModel.flashPattern.collectAsState()
    val dndBypass by viewModel.dndBypass.collectAsState()
    val bluetoothAlertEnabled by viewModel.bluetoothAlertEnabled.collectAsState()

    val isListening by viewModel.isServiceActive.collectAsState()
    val lastHeardText by viewModel.lastHeardText.collectAsState()
    val audioRms by viewModel.audioRms.collectAsState()
    val previewingSoundId by viewModel.previewingSoundId.collectAsState()

    // Ads states
    val showPeriodicAd by viewModel.showPeriodicAd.collectAsState()
    val showSlotRewardedAd by viewModel.showSlotRewardedAd.collectAsState()

    // Recording states
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingSeconds by viewModel.recordingSeconds.collectAsState()
    val recordingAmplitude by viewModel.recordingAmplitude.collectAsState()
    val recordedTempPath by viewModel.recordedTempPath.collectAsState()
    val isRecordedPreviewPlaying by viewModel.isRecordedPreviewPlaying.collectAsState()

    var showRecordSheet by remember { mutableStateOf(false) }
    var showCatalogSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var soundToEdit by remember { mutableStateOf<SoundEntity?>(null) }
    var soundToDelete by remember { mutableStateOf<SoundEntity?>(null) }

    var showPermissionAlert by remember { mutableStateOf(false) }
    var showRemoveAdsDialog by remember { mutableStateOf(false) }
    var showSlotLimitReachedDialog by remember { mutableStateOf(false) }

    val recordSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val catalogSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val settingsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Permission launcher for Mic and Notifications
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        if (micGranted) {
            viewModel.toggleListening()
        } else {
            showPermissionAlert = true
        }
    }

    val requestPermissionsAndToggle = {
        val micPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val notificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true

        if (micPermission && notificationPermission) {
            viewModel.toggleListening()
        } else {
            val permissionsToRequest = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    if (!hasAcceptedLegalTerms) {
        LegalConsentGate(
            appLanguage = appLanguage,
            onLanguageChange = { newLang ->
                viewModel.setAppLanguage(newLang)
            },
            onAcceptLegal = {
                viewModel.acceptLegalTerms()
            }
        )
        return
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.navigationBars,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Móvil Detector",
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Encuentra tu teléfono al instante",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    Surface(
                        onClick = { showRemoveAdsDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        color = if (adsRemoved) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                        else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (adsRemoved) Icons.Default.CheckCircle else Icons.Default.Star,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (adsRemoved) "PRO" else "PRO",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Botón de 3 rallitas (Menú de Ajustes) arriba a la derecha
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menú de ajustes",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            AnimatedVisibility(
                visible = !adsRemoved,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                AdBannerView(
                    priceFormatted = productPriceFormatted,
                    onRemoveAdsClick = { showRemoveAdsDialog = true }
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (sounds.size >= unlockedSlots) {
                        if (unlockedSlots < 15) {
                            showSlotLimitReachedDialog = true
                        } else {
                            scope.launch {
                                snackbarHostState.showSnackbar("Has alcanzado el límite máximo de 15 sonidos.")
                            }
                        }
                        return@ExtendedFloatingActionButton
                    }

                    showRecordSheet = true
                },
                modifier = Modifier.testTag("add_sound_fab"),
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Nuevo sonido (${sounds.size}/$unlockedSlots)",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Hero Status & Activación Central
                item {
                    HeroStatusCard(
                        isListening = isListening,
                        audioRms = audioRms,
                        lastHeardText = lastHeardText,
                        triggerMode = triggerMode,
                        customTriggerPhrase = customTriggerPhrase,
                        onToggleListening = requestPermissionsAndToggle
                    )
                }

                // 1.1 Alerta de Micrófono Silenciado por el Sistema (si está activada la comprobación)
                if (checkMicPrivacy && isListening && viewModel.isMicrophoneMutedBySystem()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().testTag("mic_privacy_system_warning_card")
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MicOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Micrófono bloqueado en Android",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                    Text(
                                        text = "El acceso al micrófono está desactivado en la barra de ajustes rápidos del sistema. Actívalo para que la app pueda escuchar.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Espacios de Sonidos (En la pantalla principal como fue solicitado)
                item {
                    SlotsInfoCard(
                        currentSoundsCount = sounds.size,
                        unlockedSlots = unlockedSlots,
                        isAdsRemoved = adsRemoved,
                        onWatchAdToUnlock = {
                            viewModel.requestUnlockSlot()
                        },
                        onOpenCatalog = {
                            showCatalogSheet = true
                        }
                    )
                }

                // 3. Encabezado de Sección: Sonidos de respuesta
                item {
                    Column(modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
                        Text(
                            text = "Sonidos de respuesta",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Toca para elegir cómo contestará el móvil. Puedes editar el nombre o eliminarlos.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 4. Lista de Sonidos de respuesta (con editar nombre y eliminar)
                items(sounds, key = { it.id }) { sound ->
                    SoundItemCard(
                        sound = sound,
                        isSelected = sound.id == selectedSoundId,
                        isPreviewPlaying = previewingSoundId == sound.id,
                        onSelect = {
                            viewModel.selectSound(sound.id)
                            scope.launch {
                                snackbarHostState.showSnackbar("Sonido seleccionado: ${sound.name}")
                            }
                        },
                        onTogglePreview = {
                            viewModel.playSoundPreview(sound)
                        },
                        onRename = {
                            soundToEdit = sound
                        },
                        onDelete = {
                            soundToDelete = sound
                        }
                    )
                }

                // Spacer al final para no tapar con el botón flotante
                item {
                    Spacer(modifier = Modifier.height(84.dp))
                }
            }
        }
    }

    // Modal Bottom Sheet del Menú de Ajustes (3 rallitas)
    if (showSettingsSheet) {
        SettingsBottomSheet(
            sheetState = settingsSheetState,
            triggerMode = triggerMode,
            vibrationIntensity = vibrationIntensity,
            isDarkMode = isDarkMode,
            isAdsRemoved = adsRemoved,
            appLanguage = appLanguage,
            customTriggerPhrase = customTriggerPhrase,
            checkMicPrivacy = checkMicPrivacy,
            flashPattern = flashPattern,
            dndBypass = dndBypass,
            bluetoothAlertEnabled = bluetoothAlertEnabled,
            onTriggerModeChange = { mode ->
                viewModel.setTriggerMode(mode)
                scope.launch {
                    snackbarHostState.showSnackbar("Disparador configurado a: ${mode.title}")
                }
            },
            onCustomTriggerPhraseChange = { phrase ->
                viewModel.setCustomTriggerPhrase(phrase)
                scope.launch {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    snackbarHostState.showSnackbar("Palabra de llamada guardada: \"$phrase\"")
                }
            },
            onVibrationIntensityChange = { intensity ->
                viewModel.setVibrationIntensity(intensity)
                scope.launch {
                    snackbarHostState.showSnackbar("Vibración ajustada a: ${intensity.label}")
                }
            },
            onFlashPatternChange = { pattern ->
                viewModel.setFlashPattern(pattern)
                scope.launch {
                    snackbarHostState.showSnackbar("Patrón de linterna: ${pattern.label}")
                }
            },
            onToggleDndBypass = { enabled ->
                viewModel.setDndBypass(enabled)
                scope.launch {
                    snackbarHostState.showSnackbar(
                        if (enabled) "Modo Silencio / No Molestar permitido" else "Modo Silencio / No Molestar desactivado"
                    )
                }
            },
            onToggleBluetoothAlert = { enabled ->
                viewModel.setBluetoothAlertEnabled(enabled)
                scope.launch {
                    snackbarHostState.showSnackbar(
                        if (enabled) "Aviso de Bluetooth desconectado activado" else "Aviso de Bluetooth desactivado"
                    )
                }
            },
            onToggleDarkMode = {
                viewModel.toggleDarkMode()
                scope.launch {
                    snackbarHostState.showSnackbar(
                        if (!isDarkMode) "Tema oscuro activado" else "Tema claro activado"
                    )
                }
            },
            onToggleCheckMicPrivacy = { enabled ->
                viewModel.setCheckMicPrivacy(enabled)
                scope.launch {
                    snackbarHostState.showSnackbar(
                        if (enabled) "Aviso de micrófono silenciado activado" else "Aviso de micrófono silenciado desactivado"
                    )
                }
            },
            onResetDefaultSounds = {
                viewModel.resetDefaultSounds()
                scope.launch {
                    snackbarHostState.showSnackbar("Sonidos originales restablecidos (\"Dos pitidos\" y \"¡Hola! Aquí estoy\")")
                }
            },
            onAppLanguageChange = { newLang ->
                viewModel.setAppLanguage(newLang)
                scope.launch {
                    snackbarHostState.showSnackbar("Idioma seleccionado: ${newLang.nativeName}")
                }
            },
            onOpenRemoveAds = {
                showSettingsSheet = false
                showRemoveAdsDialog = true
            },
            onTestDetection = {
                viewModel.testDetection()
                scope.launch {
                    snackbarHostState.showSnackbar("Probando linterna, vibración y sonido...")
                }
            },
            onDismissRequest = {
                showSettingsSheet = false
            }
        )
    }

    // Diálogo para Editar Nombre del Sonido
    soundToEdit?.let { sound ->
        EditSoundDialog(
            sound = sound,
            onConfirm = { newName ->
                viewModel.renameSound(sound, newName)
                soundToEdit = null
                scope.launch {
                    snackbarHostState.showSnackbar("Nombre actualizado a \"$newName\"")
                }
            },
            onDismissRequest = {
                soundToEdit = null
            }
        )
    }

    // Diálogo para Confirmar Eliminación del Sonido
    soundToDelete?.let { sound ->
        DeleteSoundDialog(
            sound = sound,
            onConfirmDelete = {
                viewModel.deleteSound(sound)
                soundToDelete = null
                scope.launch {
                    snackbarHostState.showSnackbar("Sonido \"${sound.name}\" eliminado")
                }
            },
            onDismissRequest = {
                soundToDelete = null
            }
        )
    }

    // Modal Bottom Sheet para añadir o grabar nuevo sonido (con recorte de audio en tiempo real)
    if (showRecordSheet) {
        val maxDuration = viewModel.getMaxSoundDurationSeconds()
        RecordSoundSheet(
            sheetState = recordSheetState,
            isRecording = isRecording,
            recordingSeconds = recordingSeconds,
            recordingAmplitude = recordingAmplitude,
            recordedTempPath = recordedTempPath,
            isPreviewPlaying = isRecordedPreviewPlaying,
            maxDurationSeconds = maxDuration,
            isPremiumUser = adsRemoved,
            onStartRecording = { viewModel.startRecording() },
            onStopRecording = { viewModel.stopRecording() },
            onPlayPreview = { viewModel.playRecordedPreview() },
            onPlayTrimmedPreview = { path, startSec, endSec ->
                viewModel.playTrimmedPreview(path, startSec, endSec)
            },
            onStopPreview = { viewModel.stopPreview() },
            onCancel = {
                viewModel.cancelRecording()
                showRecordSheet = false
            },
            onSaveSound = { name ->
                viewModel.saveCustomSound(name) {
                    showRecordSheet = false
                    scope.launch {
                        snackbarHostState.showSnackbar("¡Sonido guardado y seleccionado!")
                    }
                }
            },
            onSaveTrimmedSound = { name, path, startSec, endSec ->
                viewModel.saveTrimmedCustomSound(name, path, startSec, endSec) {
                    showRecordSheet = false
                    scope.launch {
                        snackbarHostState.showSnackbar("¡Sonido recortado y guardado!")
                    }
                }
            },
            onSaveImportedSound = { name, path, duration ->
                viewModel.saveImportedSound(name, path, duration) {
                    showRecordSheet = false
                    scope.launch {
                        snackbarHostState.showSnackbar("¡Archivo de audio guardado y seleccionado!")
                    }
                }
            },
            onSaveTrimmedImportedSound = { name, path, startSec, endSec, totalDur ->
                viewModel.saveTrimmedImportedSound(name, path, startSec, endSec, totalDur) {
                    showRecordSheet = false
                    scope.launch {
                        snackbarHostState.showSnackbar("¡Audio recortado y guardado!")
                    }
                }
            },
            onOpenPremiumDialog = {
                showRecordSheet = false
                showRemoveAdsDialog = true
            },
            onDismissRequest = {
                viewModel.cancelRecording()
                showRecordSheet = false
            }
        )
    }

    // Modal Bottom Sheet para el Catálogo de Efectos Preinstalados (sirena de policía, alarma nuclear, timbre, maullido)
    if (showCatalogSheet) {
        com.example.ui.components.CatalogSoundSheet(
            sheetState = catalogSheetState,
            currentSoundsCount = sounds.size,
            unlockedSlots = unlockedSlots,
            existingSoundNames = sounds.map { it.name }.toSet(),
            onAddPresetSound = { name, filePath, duration ->
                viewModel.saveImportedSound(name, filePath, duration) {
                    showCatalogSheet = false
                    scope.launch {
                        snackbarHostState.showSnackbar("¡Efecto \"$name\" añadido y seleccionado!")
                    }
                }
            },
            onNeedMoreSlots = {
                showCatalogSheet = false
                if (unlockedSlots < 15) {
                    showSlotLimitReachedDialog = true
                } else {
                    scope.launch {
                        snackbarHostState.showSnackbar("Has alcanzado el límite máximo de 15 sonidos.")
                    }
                }
            },
            onDismissRequest = {
                showCatalogSheet = false
            }
        )
    }

    // Periodic Ad Dialog (interstitial triggered for free tier)
    if (showPeriodicAd) {
        val activity = context as? Activity
        androidx.compose.runtime.LaunchedEffect(Unit) {
            if (activity != null && AdMobManager.isInterstitialReady()) {
                AdMobManager.showInterstitial(activity) {
                    viewModel.dismissPeriodicAd()
                }
            } else {
                viewModel.dismissPeriodicAd()
            }
        }
    }

    // Rewarded Slot Ad Dialog
    showSlotRewardedAd?.let { targetSlot ->
        val activity = context as? Activity
        androidx.compose.runtime.LaunchedEffect(Unit) {
            if (activity != null && AdMobManager.isRewardedReady()) {
                val shown = AdMobManager.showRewarded(
                    activity = activity,
                    onRewardEarned = {
                        viewModel.completeSlotRewardedAd()
                        scope.launch {
                            snackbarHostState.showSnackbar("¡Espacio $targetSlot desbloqueado con éxito! 🎉")
                        }
                    },
                    onAdDismissed = {
                        viewModel.dismissSlotRewardedAd()
                    }
                )
                if (!shown) {
                    viewModel.dismissSlotRewardedAd()
                    scope.launch {
                        snackbarHostState.showSnackbar("El anuncio no está disponible en este momento. Inténtalo más tarde.")
                    }
                }
            } else {
                viewModel.dismissSlotRewardedAd()
                scope.launch {
                    snackbarHostState.showSnackbar("El anuncio no está disponible en este momento. Inténtalo más tarde.")
                }
            }
        }
    }

    // Remove Ads Pro Dialog
    if (showRemoveAdsDialog) {
        val currentActivity = context as? Activity
        RemoveAdsDialog(
            isAdsAlreadyRemoved = adsRemoved,
            priceFormatted = productPriceFormatted,
            onConfirmPurchase = {
                viewModel.launchPurchaseFlow(currentActivity)
            },
            onRestorePurchases = {
                viewModel.restorePurchases { found ->
                    scope.launch {
                        if (found) {
                            snackbarHostState.showSnackbar("¡Compras restauradas con éxito!")
                        } else {
                            snackbarHostState.showSnackbar("No se encontraron compras previas en tu cuenta de Google Play.")
                        }
                    }
                }
            },
            onDismissRequest = { showRemoveAdsDialog = false }
        )
    }

    // Slot Limit Reached Dialog
    if (showSlotLimitReachedDialog) {
        AlertDialog(
            onDismissRequest = { showSlotLimitReachedDialog = false },
            title = {
                Text("Espacios de sonido llenos", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("Actualmente tienes $unlockedSlots espacios ocupados. Puedes desbloquear el espacio #${unlockedSlots + 1} viendo un anuncio breve o adquiriendo la versión Sin Anuncios.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSlotLimitReachedDialog = false
                        viewModel.requestUnlockSlot()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Desbloquear con anuncio")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSlotLimitReachedDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Permission Alert Dialog
    if (showPermissionAlert) {
        AlertDialog(
            onDismissRequest = { showPermissionAlert = false },
            title = {
                Text(text = "Permiso de micrófono requerido", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("Para detectar 'Hey Móvil', palmadas o silbidos cuando esté perdido, la aplicación necesita acceso al micrófono.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionAlert = false
                        val permissionsToRequest = mutableListOf(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        permissionLauncher.launch(permissionsToRequest.toTypedArray())
                    }
                ) {
                    Text("Conceder permiso")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionAlert = false }) {
                    Text("Entendido")
                }
            }
        )
    }
}

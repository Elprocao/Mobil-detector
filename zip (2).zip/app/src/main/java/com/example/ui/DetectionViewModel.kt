package com.example.ui

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioFileImporter
import com.example.audio.SoundPlayer
import com.example.audio.SoundRecorder
import com.example.billing.BillingManager
import com.example.data.model.AppLanguage
import com.example.data.model.SoundEntity
import com.example.data.model.SoundType
import com.example.data.repository.SoundRepository
import com.example.hardware.VibrationIntensity
import com.example.service.TriggerMode
import com.example.service.VoiceDetectionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetectionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SoundRepository = SoundRepository.getInstance(application)
    private val soundRecorder: SoundRecorder = SoundRecorder(application)
    private val soundPlayer: SoundPlayer = SoundPlayer(application)

    val sounds: StateFlow<List<SoundEntity>> = repository.allSounds
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val selectedSoundId: StateFlow<Long> = repository.selectedSoundId
    val unlockedSlots: StateFlow<Int> = repository.unlockedSlots
    val adsRemoved: StateFlow<Boolean> = repository.adsRemoved

    private val billingManager: BillingManager = BillingManager(application) {
        // Callback oficial al confirmar compra o suscripción desde Google Play
        purchaseRemoveAds()
    }
    val productPriceFormatted: StateFlow<String> = billingManager.productPriceFormatted

    private val _purchaseMessage = MutableStateFlow<String?>(null)
    val purchaseMessage: StateFlow<String?> = _purchaseMessage.asStateFlow()

    fun clearPurchaseMessage() {
        _purchaseMessage.value = null
    }

    // Configuración de tema claro / oscuro (por defecto claro)
    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode

    // Idioma de la aplicación (Automático por defecto, Español, Valenciano, Inglés, etc.)
    val appLanguage: StateFlow<AppLanguage> = repository.appLanguage

    fun setAppLanguage(language: AppLanguage) {
        repository.setAppLanguage(language)
    }

    // Ajuste de aviso de privacidad de micrófono Android (por defecto false)
    val checkMicPrivacy: StateFlow<Boolean> = repository.checkMicPrivacy

    // Aceptación obligatoria de términos legales y política de privacidad
    val hasAcceptedLegalTerms: StateFlow<Boolean> = repository.hasAcceptedLegalTerms

    fun acceptLegalTerms() {
        repository.acceptLegalTerms()
    }

    // Configuración de vibración (Baja, Media, Alta) y modo de disparador (Hey Móvil, 2 Palmadas, Silbido)
    val vibrationIntensity: StateFlow<VibrationIntensity> = repository.vibrationIntensity
    val triggerMode: StateFlow<TriggerMode> = repository.triggerMode
    val customTriggerPhrase: StateFlow<String> = repository.customTriggerPhrase
    val flashPattern: StateFlow<com.example.hardware.FlashPattern> = repository.flashPattern
    val dndBypass: StateFlow<Boolean> = repository.dndBypass
    val bluetoothAlertEnabled: StateFlow<Boolean> = repository.bluetoothAlertEnabled

    val isServiceActive: StateFlow<Boolean> = VoiceDetectionService.isServiceActive
    val lastDetectionTime: StateFlow<Long> = VoiceDetectionService.lastDetectionTime
    val lastHeardText: StateFlow<String> = VoiceDetectionService.lastHeardText
    val audioRms: StateFlow<Float> = VoiceDetectionService.audioRms

    private val _previewingSoundId = MutableStateFlow<Long?>(null)
    val previewingSoundId: StateFlow<Long?> = _previewingSoundId.asStateFlow()

    // Recording custom sound states
    val isRecording: StateFlow<Boolean> = soundRecorder.isRecording
    val recordingSeconds: StateFlow<Float> = soundRecorder.elapsedSeconds
    val recordingAmplitude: StateFlow<Float> = soundRecorder.amplitude

    private val _recordedTempPath = MutableStateFlow<String?>(null)
    val recordedTempPath: StateFlow<String?> = _recordedTempPath.asStateFlow()

    private val _isRecordedPreviewPlaying = MutableStateFlow(false)
    val isRecordedPreviewPlaying: StateFlow<Boolean> = _isRecordedPreviewPlaying.asStateFlow()

    // Ads state management
    private val _showPeriodicAd = MutableStateFlow(false)
    val showPeriodicAd: StateFlow<Boolean> = _showPeriodicAd.asStateFlow()

    private val _showSlotRewardedAd = MutableStateFlow<Int?>(null)
    val showSlotRewardedAd: StateFlow<Int?> = _showSlotRewardedAd.asStateFlow()

    private var periodicAdJob: Job? = null

    init {
        soundRecorder.onMaxDurationReached = {
            stopRecording()
        }
        startPeriodicAdTimer()
        viewModelScope.launch(Dispatchers.IO) {
            cleanOrphanAudioFiles()
        }
    }

    fun setCheckMicPrivacy(enabled: Boolean) {
        repository.setCheckMicPrivacy(enabled)
    }

    fun resetDefaultSounds() {
        viewModelScope.launch {
            repository.resetDefaultSounds()
        }
    }

    /**
     * Comprueba si el micrófono está silenciado a nivel global por el sistema (Android 12+ SensorPrivacyManager o AudioManager).
     */
    fun isMicrophoneMutedBySystem(): Boolean {
        try {
            val context = getApplication<Application>()
            // 1. Android 12+ (API 31+): Comprobación del bloqueo global del micrófono en los Ajustes Rápidos de Privacidad
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val sensorPrivacyManager = context.getSystemService("sensor_privacy")
                if (sensorPrivacyManager != null) {
                    try {
                        val method = sensorPrivacyManager.javaClass.getMethod("isSensorPrivacyEnabled", Int::class.javaPrimitiveType)
                        val isEnabled = method.invoke(sensorPrivacyManager, 1) as? Boolean
                        if (isEnabled == true) return true
                    } catch (_: Exception) {}
                }
            }

            // 2. Comprobación a nivel de AudioManager
            val audioManager = context.getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
            if (audioManager?.isMicrophoneMute == true) {
                return true
            }
        } catch (_: Exception) {}
        return false
    }

    private suspend fun cleanOrphanAudioFiles() = withContext(Dispatchers.IO) {
        try {
            val soundsDir = java.io.File(getApplication<Application>().filesDir, "custom_sounds")
            if (!soundsDir.exists()) return@withContext
            val registeredSounds = repository.allSounds.firstOrNull() ?: emptyList()
            val registeredPaths = registeredSounds.mapNotNull { it.filePath }.toSet()

            soundsDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("imported_") || file.name.startsWith("temp_")) {
                    if (!registeredPaths.contains(file.absolutePath)) {
                        val tenMinutesAgo = System.currentTimeMillis() - 600_000L
                        if (file.lastModified() < tenMinutesAgo) {
                            file.delete()
                        }
                    }
                }
            }
        } catch (_: Exception) {}
    }

    fun toggleDarkMode() {
        repository.toggleDarkMode()
    }

    fun setDarkMode(enabled: Boolean) {
        repository.setDarkMode(enabled)
    }

    fun setVibrationIntensity(intensity: VibrationIntensity) {
        repository.setVibrationIntensity(intensity)
    }

    fun setTriggerMode(mode: TriggerMode) {
        repository.setTriggerMode(mode)
        // Si el servicio está activo, notificarlo para asegurar la sincronización inmediata
        val currentContext = getApplication<Application>()
        if (isServiceActive.value) {
            VoiceDetectionService.start(currentContext)
        }
    }

    fun setCustomTriggerPhrase(phrase: String) {
        repository.setCustomTriggerPhrase(phrase)
        val currentContext = getApplication<Application>()
        if (isServiceActive.value) {
            VoiceDetectionService.start(currentContext)
        }
    }

    /**
     * Duración máxima permitida para grabar o subir sonidos (25s para usuarios estándar, 60s para usuarios Premium/Sin Anuncios).
     */
    fun getMaxSoundDurationSeconds(): Int {
        return if (adsRemoved.value) 60 else 25
    }

    private fun startPeriodicAdTimer() {
        periodicAdJob?.cancel()
        periodicAdJob = viewModelScope.launch {
            while (isActive) {
                // Cada 5 minutos (300.000 ms)
                delay(300_000L)
                if (!adsRemoved.value) {
                    _showPeriodicAd.value = true
                }
            }
        }
    }

    fun dismissPeriodicAd() {
        _showPeriodicAd.value = false
    }

    fun dismissSlotRewardedAd() {
        _showSlotRewardedAd.value = null
    }

    fun requestUnlockSlot() {
        val currentSlots = unlockedSlots.value
        if (currentSlots < 15) {
            if (adsRemoved.value) {
                repository.unlockNextSlot()
            } else {
                _showSlotRewardedAd.value = currentSlots + 1
            }
        }
    }

    fun completeSlotRewardedAd() {
        repository.unlockNextSlot()
        _showSlotRewardedAd.value = null
    }

    fun purchaseRemoveAds() {
        repository.setAdsRemoved(true)
        periodicAdJob?.cancel()
        _showPeriodicAd.value = false
        _showSlotRewardedAd.value = null
    }

    /**
     * Inicia el flujo de compra oficial con Google Play Billing.
     */
    fun launchPurchaseFlow(activity: Activity?) {
        if (activity == null) {
            _purchaseMessage.value = "No se pudo iniciar la compra. Por favor, reinicia la app."
            return
        }
        billingManager.launchPurchase(activity) { errorMessage ->
            _purchaseMessage.value = errorMessage
        }
    }

    /**
     * Restaura compras realizadas previamente vinculadas a la cuenta de Google Play.
     */
    fun restorePurchases(onResult: (Boolean) -> Unit) {
        billingManager.queryPurchases { found ->
            if (found) {
                purchaseRemoveAds()
            }
            onResult(found)
        }
    }

    fun hasSlotAvailable(): Boolean {
        return sounds.value.size < unlockedSlots.value
    }

    fun toggleListening() {
        val currentContext = getApplication<Application>()
        try {
            com.example.hardware.AlertEffectController(currentContext).vibrateToggleFeedback()
        } catch (_: Exception) {}
        if (isServiceActive.value) {
            VoiceDetectionService.stop(currentContext)
        } else {
            VoiceDetectionService.start(currentContext)
        }
    }

    fun setFlashPattern(pattern: com.example.hardware.FlashPattern) {
        repository.setFlashPattern(pattern)
    }

    fun setDndBypass(enabled: Boolean) {
        repository.setDndBypass(enabled)
    }

    fun setBluetoothAlertEnabled(enabled: Boolean) {
        repository.setBluetoothAlertEnabled(enabled)
    }

    fun selectSound(soundId: Long) {
        repository.setSelectedSoundId(soundId)
    }

    fun playSoundPreview(sound: SoundEntity) {
        if (_previewingSoundId.value == sound.id) {
            stopPreview()
            return
        }
        _previewingSoundId.value = sound.id
        soundPlayer.playSound(sound, volumeRatio = 1.0f) {
            _previewingSoundId.value = null
        }
    }

    fun stopPreview() {
        soundPlayer.stopSound()
        _previewingSoundId.value = null
        _isRecordedPreviewPlaying.value = false
    }

    fun startRecording() {
        stopPreview()
        _recordedTempPath.value = null
        val maxDuration = getMaxSoundDurationSeconds()
        soundRecorder.startRecording(maxDurationSeconds = maxDuration)
    }

    fun stopRecording() {
        val path = soundRecorder.stopRecording()
        _recordedTempPath.value = path
    }

    fun cancelRecording() {
        stopPreview()
        soundRecorder.cancelRecording()
        _recordedTempPath.value?.let { path ->
            try {
                val f = java.io.File(path)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
        _recordedTempPath.value = null
    }

    fun setTempPreviewPath(path: String) {
        stopPreview()
        _recordedTempPath.value = path
    }

    fun playRecordedPreview() {
        val path = _recordedTempPath.value ?: return
        if (_isRecordedPreviewPlaying.value) {
            stopPreview()
            return
        }
        _isRecordedPreviewPlaying.value = true
        val tempSound = SoundEntity(
            name = "Temp",
            type = SoundType.CUSTOM_RECORDING,
            filePath = path
        )
        soundPlayer.playSound(tempSound, volumeRatio = 1.0f) {
            _isRecordedPreviewPlaying.value = false
        }
    }

    fun playTrimmedPreview(filePath: String, startSec: Float, endSec: Float) {
        stopPreview()
        _isRecordedPreviewPlaying.value = true
        soundPlayer.playCustomFileRange(filePath, startSec, endSec, volumeRatio = 1.0f) {
            _isRecordedPreviewPlaying.value = false
        }
    }

    fun saveCustomSound(name: String, onSaved: () -> Unit) {
        val path = _recordedTempPath.value ?: return
        val duration = recordingSeconds.value.toInt().coerceAtLeast(1)

        viewModelScope.launch {
            repository.addCustomSound(name, path, duration)
            _recordedTempPath.value = null
            onSaved()
        }
    }

    fun saveTrimmedCustomSound(
        name: String,
        originalFilePath: String,
        startSec: Float,
        endSec: Float,
        onSaved: () -> Unit
    ) {
        stopPreview()
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val trimmedPath = if (startSec > 0.05f || endSec < (recordingSeconds.value - 0.05f)) {
                com.example.audio.AudioTrimmer.trimAudio(context, originalFilePath, startSec, endSec) ?: originalFilePath
            } else {
                originalFilePath
            }
            val finalDuration = (endSec - startSec).toInt().coerceAtLeast(1)
            repository.addCustomSound(name, trimmedPath, finalDuration)
            _recordedTempPath.value = null
            withContext(Dispatchers.Main) {
                onSaved()
            }
        }
    }

    fun saveImportedSound(name: String, filePath: String, durationSeconds: Int, onSaved: () -> Unit) {
        viewModelScope.launch {
            repository.addCustomSound(name, filePath, durationSeconds)
            _recordedTempPath.value = null
            onSaved()
        }
    }

    fun saveTrimmedImportedSound(
        name: String,
        filePath: String,
        startSec: Float,
        endSec: Float,
        totalDurationSec: Float,
        onSaved: () -> Unit
    ) {
        stopPreview()
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val trimmedPath = if (startSec > 0.05f || endSec < (totalDurationSec - 0.05f)) {
                com.example.audio.AudioTrimmer.trimAudio(context, filePath, startSec, endSec) ?: filePath
            } else {
                filePath
            }
            val finalDuration = (endSec - startSec).toInt().coerceAtLeast(1)
            repository.addCustomSound(name, trimmedPath, finalDuration)
            _recordedTempPath.value = null
            withContext(Dispatchers.Main) {
                onSaved()
            }
        }
    }

    fun renameSound(sound: SoundEntity, newName: String) {
        viewModelScope.launch {
            repository.renameSound(sound, newName)
        }
    }

    fun deleteSound(sound: SoundEntity) {
        viewModelScope.launch {
            if (_previewingSoundId.value == sound.id) {
                stopPreview()
            }
            repository.deleteSound(sound)
        }
    }

    fun testDetection() {
        val currentContext = getApplication<Application>()
        if (isServiceActive.value) {
            VoiceDetectionService.triggerAlarmPreview(currentContext)
        } else {
            viewModelScope.launch {
                val sound = repository.getSelectedSound()
                if (sound != null) {
                    playSoundPreview(sound)
                }
            }
        }
    }

    override fun onCleared() {
        soundPlayer.release()
        soundRecorder.cancelRecording()
        billingManager.endConnection()
        super.onCleared()
    }
}

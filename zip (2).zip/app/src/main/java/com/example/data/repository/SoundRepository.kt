package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.audio.PresetSoundCatalog
import com.example.data.db.AppDatabase
import com.example.data.model.AppLanguage
import com.example.data.model.SoundEntity
import com.example.data.model.SoundType
import com.example.hardware.FlashPattern
import com.example.hardware.VibrationIntensity
import com.example.service.TriggerMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class SoundRepository private constructor(private val context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val soundDao = database.soundDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("movil_detector_prefs", Context.MODE_PRIVATE)

    // Idioma de la app (Por defecto automático según el dispositivo)
    private val _appLanguage = MutableStateFlow(
        AppLanguage.fromCode(prefs.getString(KEY_APP_LANGUAGE, AppLanguage.SYSTEM_DEFAULT.code))
    )
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    init {
        // Migración de nomenclatura: asegurar compatibilidad si el usuario tenía "hey_movil" o "voice"
        val rawMode = prefs.getString(KEY_TRIGGER_MODE, null)
        if (rawMode == "hey_movil" || rawMode == "voice" || rawMode == "VOICE_HEY_MOVIL") {
            prefs.edit().putString(KEY_TRIGGER_MODE, TriggerMode.VOICE_MODE.id).apply()
        }

        // Aplicar configuración de idioma activa
        AppLanguage.applyLanguage(context, _appLanguage.value)
    }

    private val _selectedSoundId = MutableStateFlow(
        prefs.getLong(KEY_SELECTED_SOUND_ID, 1L)
    )
    val selectedSoundId: StateFlow<Long> = _selectedSoundId.asStateFlow()

    private val _isListening = MutableStateFlow(
        prefs.getBoolean(KEY_IS_LISTENING, false)
    )
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _unlockedSlots = MutableStateFlow(
        prefs.getInt(KEY_UNLOCKED_SLOTS, 3).coerceIn(3, 15)
    )
    val unlockedSlots: StateFlow<Int> = _unlockedSlots.asStateFlow()

    private val _adsRemoved = MutableStateFlow(
        prefs.getBoolean(KEY_ADS_REMOVED, false)
    )
    val adsRemoved: StateFlow<Boolean> = _adsRemoved.asStateFlow()

    // Configuración de Vibración: Baja (0), Media (1), Alta (2). Por defecto Media (1).
    private val _vibrationIntensity = MutableStateFlow(
        VibrationIntensity.fromId(prefs.getInt(KEY_VIBRATION_INTENSITY, VibrationIntensity.MEDIUM.id))
    )
    val vibrationIntensity: StateFlow<VibrationIntensity> = _vibrationIntensity.asStateFlow()

    // Patrón de parpadeo de la linterna: Estroboscópico rápido (0), S.O.S. (1), Fijo continuo (2)
    private val _flashPattern = MutableStateFlow(
        FlashPattern.fromId(prefs.getInt(KEY_FLASH_PATTERN, FlashPattern.FAST_STROBE.id))
    )
    val flashPattern: StateFlow<FlashPattern> = _flashPattern.asStateFlow()

    // Modo No Molestar (DND Bypass): Si está activo (true), suena con USAGE_ALARM aunque esté en silencio
    private val _dndBypass = MutableStateFlow(
        prefs.getBoolean(KEY_DND_BYPASS, true)
    )
    val dndBypass: StateFlow<Boolean> = _dndBypass.asStateFlow()

    // Alerta por desconexión de Bluetooth: aviso corto si se desconectan auriculares
    private val _bluetoothAlertEnabled = MutableStateFlow(
        prefs.getBoolean(KEY_BLUETOOTH_ALERT, false)
    )
    val bluetoothAlertEnabled: StateFlow<Boolean> = _bluetoothAlertEnabled.asStateFlow()

    // Modo de disparo: Modo voz (por defecto), 2 Palmadas, Silbido.
    private val _triggerMode = MutableStateFlow(
        TriggerMode.fromId(prefs.getString(KEY_TRIGGER_MODE, TriggerMode.VOICE_MODE.id))
    )
    val triggerMode: StateFlow<TriggerMode> = _triggerMode.asStateFlow()

    // Frase o palabra personalizada para activar por voz (por defecto "Hey Móvil")
    private val _customTriggerPhrase = MutableStateFlow(
        prefs.getString(KEY_CUSTOM_TRIGGER_PHRASE, "Hey Móvil") ?: "Hey Móvil"
    )
    val customTriggerPhrase: StateFlow<String> = _customTriggerPhrase.asStateFlow()

    // Modo oscuro: por defecto false (Claro / Light Mode)
    private val _isDarkMode = MutableStateFlow(
        prefs.getBoolean(KEY_IS_DARK_MODE, false)
    )
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Ajuste para avisar si el micrófono global de Android está silenciado (por defecto false)
    private val _checkMicPrivacy = MutableStateFlow(
        prefs.getBoolean(KEY_CHECK_MIC_PRIVACY, false)
    )
    val checkMicPrivacy: StateFlow<Boolean> = _checkMicPrivacy.asStateFlow()

    // Aceptación obligatoria de Términos y Política de Privacidad
    private val _hasAcceptedLegalTerms = MutableStateFlow(
        prefs.getBoolean(KEY_LEGAL_TERMS_ACCEPTED, false)
    )
    val hasAcceptedLegalTerms: StateFlow<Boolean> = _hasAcceptedLegalTerms.asStateFlow()

    fun acceptLegalTerms() {
        prefs.edit().putBoolean(KEY_LEGAL_TERMS_ACCEPTED, true).apply()
        _hasAcceptedLegalTerms.value = true
    }

    val allSounds: Flow<List<SoundEntity>> = soundDao.getAllSounds()

    suspend fun checkAndSeedDefaults() = withContext(Dispatchers.IO) {
        // Garantizar que el sonido de "Saludo" esté generado con la versión limpia sin corrupción
        PresetSoundCatalog.getOrGenerateSaludoFile(context)

        val sound1 = soundDao.getSoundById(1L)
        if (sound1 == null) {
            soundDao.insertSound(
                SoundEntity(
                    id = 1,
                    name = "Dos pitidos",
                    type = SoundType.DEFAULT_BEEPS,
                    durationSeconds = 2,
                    isDefault = true
                )
            )
        } else if (sound1.name != "Dos pitidos" || !sound1.isDefault) {
            soundDao.insertSound(sound1.copy(name = "Dos pitidos", isDefault = true))
        }

        val sound2 = soundDao.getSoundById(2L)
        if (sound2 == null) {
            soundDao.insertSound(
                SoundEntity(
                    id = 2,
                    name = "¡Hola! Aquí estoy",
                    type = SoundType.DEFAULT_FUNNY_VOICE,
                    durationSeconds = 4,
                    isDefault = true
                )
            )
        } else if (sound2.name != "¡Hola! Aquí estoy" || !sound2.isDefault) {
            soundDao.insertSound(sound2.copy(name = "¡Hola! Aquí estoy", isDefault = true, durationSeconds = 4))
        }

        // Migrar cualquier sonido restante que conserve el nombre anterior "Saludo" o "Hola gracioso"
        val allSoundsList = soundDao.getAllSoundsList()
        for (s in allSoundsList) {
            if (s.name.equals("Hola gracioso", ignoreCase = true) || s.name.equals("Saludo", ignoreCase = true)) {
                soundDao.insertSound(s.copy(name = "¡Hola! Aquí estoy", isDefault = true, durationSeconds = 4))
            }
        }

        // Si el sonido seleccionado no existe o fue eliminado, restaurar el primero por defecto
        val currentSelected = soundDao.getSoundById(_selectedSoundId.value)
        if (currentSelected == null) {
            setSelectedSoundId(1L)
        }
    }

    suspend fun resetDefaultSounds() = withContext(Dispatchers.IO) {
        // Forzar recreación inmediata del nuevo audio de saludo alegre
        PresetSoundCatalog.getOrGenerateSaludoFile(context, forceRecreate = true)

        soundDao.insertSound(
            SoundEntity(
                id = 1,
                name = "Dos pitidos",
                type = SoundType.DEFAULT_BEEPS,
                durationSeconds = 2,
                isDefault = true
            )
        )
        soundDao.insertSound(
            SoundEntity(
                id = 2,
                name = "¡Hola! Aquí estoy",
                type = SoundType.DEFAULT_FUNNY_VOICE,
                durationSeconds = 4,
                isDefault = true
            )
        )
        setSelectedSoundId(1L)
    }

    suspend fun getSoundById(id: Long): SoundEntity? = withContext(Dispatchers.IO) {
        soundDao.getSoundById(id)
    }

    suspend fun getSelectedSound(): SoundEntity? = withContext(Dispatchers.IO) {
        soundDao.getSoundById(_selectedSoundId.value) ?: soundDao.getSoundById(1L)
    }

    fun setSelectedSoundId(id: Long) {
        prefs.edit().putLong(KEY_SELECTED_SOUND_ID, id).apply()
        _selectedSoundId.value = id
    }

    fun setIsListening(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_IS_LISTENING, enabled).apply()
        _isListening.value = enabled
        try {
            com.example.widget.DetectorWidgetProvider.updateAllWidgets(context, enabled)
        } catch (_: Exception) {}
    }

    fun setVibrationIntensity(intensity: VibrationIntensity) {
        prefs.edit().putInt(KEY_VIBRATION_INTENSITY, intensity.id).apply()
        _vibrationIntensity.value = intensity
    }

    fun setFlashPattern(pattern: FlashPattern) {
        prefs.edit().putInt(KEY_FLASH_PATTERN, pattern.id).apply()
        _flashPattern.value = pattern
    }

    fun setDndBypass(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DND_BYPASS, enabled).apply()
        _dndBypass.value = enabled
    }

    fun setBluetoothAlertEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BLUETOOTH_ALERT, enabled).apply()
        _bluetoothAlertEnabled.value = enabled
    }

    fun setTriggerMode(mode: TriggerMode) {
        prefs.edit().putString(KEY_TRIGGER_MODE, mode.id).apply()
        _triggerMode.value = mode
    }

    fun setCustomTriggerPhrase(phrase: String) {
        val trimmed = phrase.trim().ifBlank { "Hey Móvil" }
        prefs.edit().putString(KEY_CUSTOM_TRIGGER_PHRASE, trimmed).apply()
        _customTriggerPhrase.value = trimmed
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_IS_DARK_MODE, enabled).apply()
        _isDarkMode.value = enabled
    }

    fun toggleDarkMode() {
        val next = !_isDarkMode.value
        setDarkMode(next)
    }

    suspend fun addCustomSound(name: String, filePath: String, durationSeconds: Int): Long =
        withContext(Dispatchers.IO) {
            val entity = SoundEntity(
                name = name.ifBlank { "Sonido grabado" },
                type = SoundType.CUSTOM_RECORDING,
                filePath = filePath,
                durationSeconds = durationSeconds.coerceIn(1, 60),
                isDefault = false
            )
            val insertedId = soundDao.insertSound(entity)
            // Auto select newly created sound
            setSelectedSoundId(insertedId)
            insertedId
        }

    suspend fun renameSound(sound: SoundEntity, newName: String) = withContext(Dispatchers.IO) {
        val trimmed = newName.trim()
        if (trimmed.isNotBlank()) {
            val updated = sound.copy(name = trimmed)
            soundDao.insertSound(updated)
        }
    }

    suspend fun deleteSound(sound: SoundEntity) = withContext(Dispatchers.IO) {
        // Los sonidos por defecto del sistema ("Dos pitidos" y "Saludo") están protegidos permanentemente y nunca pueden borrarse
        if (sound.isPermanentDefault) {
            return@withContext
        }

        // Delete audio file if it exists
        sound.filePath?.let { path ->
            try {
                val file = File(path)
                if (file.exists()) file.delete()
            } catch (_: Exception) {}
        }
        soundDao.deleteSound(sound)

        // If the deleted sound was currently selected, pick another sound or default
        if (_selectedSoundId.value == sound.id) {
            val allRemaining = soundDao.getAllSoundsList()
            if (allRemaining.isNotEmpty()) {
                setSelectedSoundId(allRemaining.first().id)
            } else {
                setSelectedSoundId(1L)
            }
        }
    }

    fun setCheckMicPrivacy(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CHECK_MIC_PRIVACY, enabled).apply()
        _checkMicPrivacy.value = enabled
    }

    fun setAppLanguage(language: AppLanguage) {
        prefs.edit().putString(KEY_APP_LANGUAGE, language.code).apply()
        _appLanguage.value = language
        AppLanguage.applyLanguage(context, language)
    }

    fun unlockNextSlot(): Int {
        val current = _unlockedSlots.value
        val next = (current + 1).coerceAtMost(15)
        prefs.edit().putInt(KEY_UNLOCKED_SLOTS, next).apply()
        _unlockedSlots.value = next
        return next
    }

    fun unlockAllSlots() {
        prefs.edit().putInt(KEY_UNLOCKED_SLOTS, 15).apply()
        _unlockedSlots.value = 15
    }

    fun setAdsRemoved(removed: Boolean) {
        prefs.edit().putBoolean(KEY_ADS_REMOVED, removed).apply()
        _adsRemoved.value = removed
        if (removed) {
            unlockAllSlots()
        }
    }

    companion object {
        private const val KEY_SELECTED_SOUND_ID = "selected_sound_id"
        private const val KEY_IS_LISTENING = "is_listening"
        private const val KEY_UNLOCKED_SLOTS = "unlocked_sound_slots"
        private const val KEY_ADS_REMOVED = "ads_removed_pro"
        private const val KEY_VIBRATION_INTENSITY = "vibration_intensity"
        private const val KEY_FLASH_PATTERN = "flash_pattern_style"
        private const val KEY_DND_BYPASS = "dnd_bypass_mode"
        private const val KEY_BLUETOOTH_ALERT = "bluetooth_disconnect_alert"
        private const val KEY_TRIGGER_MODE = "trigger_mode"
        private const val KEY_CUSTOM_TRIGGER_PHRASE = "custom_trigger_phrase"
        private const val KEY_IS_DARK_MODE = "is_dark_mode_theme"
        private const val KEY_CHECK_MIC_PRIVACY = "check_mic_privacy"
        private const val KEY_APP_LANGUAGE = "app_language_preference"
        private const val KEY_LEGAL_TERMS_ACCEPTED = "legal_terms_accepted"

        @Volatile
        private var INSTANCE: SoundRepository? = null

        fun getInstance(context: Context): SoundRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = SoundRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}


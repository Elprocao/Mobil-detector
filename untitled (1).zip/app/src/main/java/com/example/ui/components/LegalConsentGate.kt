package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppLanguage
import com.example.ui.i18n.AppStrings

/**
 * Pantalla de consentimiento legal obligatorio que bloquea la entrada a la app
 * hasta que el usuario acepta expresamente la Política de Privacidad y los Términos de Uso.
 */
@Composable
fun LegalConsentGate(
    appLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit = {},
    onAcceptLegal: () -> Unit
) {
    val s = AppStrings.get(appLanguage)
    var privacyAccepted by remember { mutableStateOf(false) }
    var termsAccepted by remember { mutableStateOf(false) }
    var activeDocToView by remember { mutableStateOf<LegalDocType?>(null) }
    var showRequirementWarning by remember { mutableStateOf(false) }
    var showLanguageSelector by remember { mutableStateOf(false) }

    val canProceed = privacyAccepted && termsAccepted

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("legal_consent_screen"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Selector de idioma en la parte superior
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedCard(
                        onClick = { showLanguageSelector = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.testTag("legal_language_selector_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${appLanguage.flagEmoji} ${if (appLanguage == AppLanguage.SYSTEM_DEFAULT) s.systemDefaultTag else appLanguage.displayName}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Icono escudo de seguridad
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = s.legalTermsWelcome,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = s.legalTermsDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Tarjeta informativa de privacidad de audio en local
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PrivacyTip,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = s.legalPrivacyHighlight,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 17.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Casilla 1: Política de Privacidad
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (privacyAccepted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(
                        if (privacyAccepted) 1.5.dp else 1.dp,
                        if (privacyAccepted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { privacyAccepted = !privacyAccepted }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = privacyAccepted,
                                onCheckedChange = { privacyAccepted = it },
                                modifier = Modifier.testTag("checkbox_legal_privacy"),
                                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = s.legalCheckboxPrivacy,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { activeDocToView = LegalDocType.PRIVACY },
                                modifier = Modifier.testTag("view_privacy_policy_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = s.legalViewPrivacyDoc,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Casilla 2: Términos y Condiciones
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (termsAccepted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(
                        if (termsAccepted) 1.5.dp else 1.dp,
                        if (termsAccepted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { termsAccepted = !termsAccepted }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = termsAccepted,
                                onCheckedChange = { termsAccepted = it },
                                modifier = Modifier.testTag("checkbox_legal_terms"),
                                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = s.legalCheckboxTerms,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { activeDocToView = LegalDocType.TERMS },
                                modifier = Modifier.testTag("view_terms_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Gavel,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = s.legalViewTermsDoc,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                if (showRequirementWarning && !canProceed) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = s.legalMustAcceptToEnter,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Barra inferior con botón de entrada
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        if (canProceed) {
                            onAcceptLegal()
                        } else {
                            showRequirementWarning = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("accept_legal_and_enter_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (canProceed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (canProceed) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    enabled = true
                ) {
                    Icon(
                        imageVector = if (canProceed) Icons.Default.Check else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = s.legalAcceptAndContinue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = s.legalAppBlockedNotice,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    // Modal para seleccionar idioma
    if (showLanguageSelector) {
        Dialog(onDismissRequest = { showLanguageSelector = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = s.settingsLanguageTitle,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        AppLanguage.entries.forEach { lang ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        onLanguageChange(lang)
                                        showLanguageSelector = false
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = appLanguage == lang,
                                    onClick = {
                                        onLanguageChange(lang)
                                        showLanguageSelector = false
                                    }
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "${lang.flagEmoji}  ${lang.displayName}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (appLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showLanguageSelector = false }) {
                            Text(s.closeDoc)
                        }
                    }
                }
            }
        }
    }

    // Modal para leer el documento completo
    activeDocToView?.let { doc ->
        LegalDocumentDialog(
            docType = doc,
            appLanguage = appLanguage,
            onDismiss = { activeDocToView = null }
        )
    }
}

enum class LegalDocType {
    PRIVACY,
    TERMS,
    REFUND
}

@Composable
fun LegalDocumentDialog(
    docType: LegalDocType,
    appLanguage: AppLanguage,
    onDismiss: () -> Unit
) {
    val s = AppStrings.get(appLanguage)
    val isSpanish = appLanguage == AppLanguage.SPANISH || appLanguage == AppLanguage.VALENCIAN ||
            (appLanguage == AppLanguage.SYSTEM_DEFAULT && AppLanguage.getEffectiveLanguage(appLanguage) in listOf(AppLanguage.SPANISH, AppLanguage.VALENCIAN))

    val docTitle = when (docType) {
        LegalDocType.PRIVACY -> s.legalViewPrivacyDoc
        LegalDocType.TERMS -> s.legalViewTermsDoc
        LegalDocType.REFUND -> if (isSpanish) "Política de Reembolsos" else "Refund Policy"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f)
                .padding(vertical = 20.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (docType) {
                                        LegalDocType.PRIVACY -> Icons.Default.PrivacyTip
                                        LegalDocType.TERMS -> Icons.Default.Gavel
                                        LegalDocType.REFUND -> Icons.Default.ReceiptLong
                                    },
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = docTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = s.closeDoc,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                )

                // Contenido del documento con scroll
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    when (docType) {
                        LegalDocType.PRIVACY -> PrivacyPolicyContent(isSpanish = isSpanish)
                        LegalDocType.TERMS -> TermsOfServiceContent(isSpanish = isSpanish)
                        LegalDocType.REFUND -> RefundPolicyContent(isSpanish = isSpanish)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                )

                // Botón inferior para cerrar y ver online
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val context = LocalContext.current
                    TextButton(
                        onClick = {
                            try {
                                val url = when (docType) {
                                    LegalDocType.PRIVACY -> "https://elprocao.github.io/Mobil-detector/privacy_policy.html"
                                    LegalDocType.TERMS -> "https://elprocao.github.io/Mobil-detector/terms_of_service.html"
                                    LegalDocType.REFUND -> "https://elprocao.github.io/Mobil-detector/terms_of_service.html#reembolsos"
                                }
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isSpanish) "Ver online" else "View online")
                    }

                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(s.closeDoc)
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyPolicyContent(isSpanish: Boolean) {
    if (isSpanish) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "POLÍTICA DE PRIVACIDAD DE MÓVIL DETECTOR",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Última actualización: Septiembre 2026\nResponsable: Pablo Valero Trives • Beniarbeig (Alicante, España)\nContacto: contactoelprocao@gmail.com",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Principio Fundamental: Privacidad por Diseño",
                content = "Móvil Detector ha sido desarrollado con el compromiso inquebrantable de proteger la privacidad de sus usuarios. No comercializamos, no recopilamos ni compartimos tus grabaciones personales."
            )

            SectionItem(
                title = "2. Tratamiento de Datos del Micrófono (RECORD_AUDIO)",
                content = "• Procesamiento 100% On-Device: El análisis del sonido para detectar palmadas, silbidos o la palabra de activación se realiza de forma efímera y local en la memoria RAM del procesador de tu propio teléfono móvil.\n" +
                        "• Cero Grabaciones Ocultas: La app no graba conversaciones ni crea archivos temporales ocultos de audio ambiental.\n" +
                        "• Cero Transmisión a Servidores: Ningún fragmento de tu voz o entorno acústico se envía a través de Internet ni a servidores nuestros ni de terceros."
            )

            SectionItem(
                title = "3. Uso del Flash y Linterna (FLASHLIGHT)",
                content = "Se emplea exclusivamente la API de hardware de la linterna de Android para hacer parpadear el flash LED como señal visual de localización. La aplicación nunca accede a la lente de la cámara ni captura fotografías o vídeos."
            )

            SectionItem(
                title = "4. Publicidad y Redes de Anuncios (Google AdMob)",
                content = "Para financiar la versión gratuita, la aplicación integra el SDK de Google AdMob. Google puede recopilar y utilizar identificadores anónimos de publicidad de Android (Advertising ID) y datos de diagnóstico de red para servir anuncios adaptados a las políticas de consentimiento de la UE (RGPD).\n" +
                        "Los usuarios que adquieran 'Eliminar Anuncios' desactivan de forma permanente toda la publicidad y sus identificadores de seguimiento."
            )

            SectionItem(
                title = "5. Pagos y Facturación (Google Play Billing)",
                content = "Las compras de la versión Sin Anuncios son procesadas íntegramente por los servidores seguros de Google Play. El desarrollador no tiene acceso a números de tarjetas de crédito, cuentas bancarias ni datos financieros confidenciales."
            )

            SectionItem(
                title = "6. Derechos del Usuario (RGPD y Normativa Internacional)",
                content = "Conforme al Reglamento General de Protección de Datos (RGPD) y normativa de privacidad aplicable, puedes revocar los permisos de micrófono, notificaciones o almacenamiento en cualquier momento desde los Ajustes de Android. Para cualquier consulta o ejercicio de derechos ARCO, contacta en contactoelprocao@gmail.com."
            )
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "PHONE FINDER DETECTOR PRIVACY POLICY",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Last updated: September 2026\nData Controller: Pablo Valero Trives • Beniarbeig (Alicante, Spain)\nContact: contactoelprocao@gmail.com",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Privacy by Design",
                content = "Phone Finder Detector is built with an uncompromising commitment to user privacy. We do not sell, collect, or distribute your private voice or audio data."
            )

            SectionItem(
                title = "2. Audio and Microphone Processing (RECORD_AUDIO)",
                content = "• 100% On-Device Processing: Sound analysis for detecting claps, whistles, or keyword triggers occurs ephemerally in your device RAM.\n" +
                        "• No Hidden Recordings: The app does not record private conversations or generate covert audio logs.\n" +
                        "• Zero Cloud Transmission: Audio samples are never uploaded over the internet to our servers or third-party cloud services."
            )

            SectionItem(
                title = "3. Flashlight Usage (FLASHLIGHT)",
                content = "The Android flashlight API is used solely to strobe the LED as a visual beacon to help locate your device. The camera sensor is never activated for image or video capture."
            )

            SectionItem(
                title = "4. Advertising (Google AdMob)",
                content = "The free version integrates Google AdMob. Google may process device identifiers (Google Advertising ID) and diagnostic telemetry to serve compliant ads under GDPR/ePrivacy regulations. Purchasing 'Remove Ads' completely disables all advertisements and tracking."
            )

            SectionItem(
                title = "5. In-App Purchases (Google Play Billing)",
                content = "In-app purchases are handled exclusively by Google Play. We do not receive, store, or process any payment credentials or credit card numbers."
            )

            SectionItem(
                title = "6. User Rights (GDPR / CCPA)",
                content = "You may revoke microphone, notification, or flash permissions at any time via Android System Settings. For privacy inquiries, please contact contactoelprocao@gmail.com."
            )
        }
    }
}

@Composable
private fun TermsOfServiceContent(isSpanish: Boolean) {
    if (isSpanish) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "TÉRMINOS Y CONDICIONES DE USO",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Última actualización: Septiembre 2026\nTitular: Móvil Detector • Contacto: contactoelprocao@gmail.com",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Objeto del Servicio",
                content = "Móvil Detector proporciona una herramienta de conveniencia para asistir al usuario a encontrar su teléfono mediante el reconocimiento de señales sonoras predefinidas (palmadas, silbidos o comandos de voz)."
            )

            SectionItem(
                title = "2. Condiciones de Licencia",
                content = "Se concede al usuario una licencia personal, no exclusiva, intransferible y revocable para utilizar la aplicación en dispositivos Android compatibles de acuerdo con estos términos."
            )

            SectionItem(
                title = "3. Exención de Garantías y Responsabilidad Técnica",
                content = "• La precisión de la detección puede verse afectada por factores ambientales ajenos a la app: ruido de fondo elevado, micrófonos obstruidos, fundas gruesas, modos de ultra-ahorro de batería o restricciones de gestión de procesos de ciertos fabricantes.\n" +
                        "• La aplicación no sustituye servicios de emergencia ni herramientas de geolocalización antirrobo."
            )

            SectionItem(
                title = "4. Compras Integradas y Política de Reembolsos",
                content = "• La adquisición de 'Eliminar Anuncios' desbloquea permanentemente los 15 espacios de sonido y suprime todos los anuncios.\n" +
                        "• Las compras se procesan de forma segura a través de Google Play Billing y están amparadas por las políticas oficiales de reembolso de Google Play (solicitables en tu historial de pedidos de Google Play o a través de su centro de ayuda).\n" +
                        "• Conforme a la legislación de consumidores para contenido digital de ejecución inmediata (Art. 103.m LGDCU y Directiva 2011/83/UE), el desistimiento directo frente al desarrollador queda condicionado a la ejecución inmediata del servicio, sin perjuicio de los derechos y garantías que asisten al usuario en la plataforma Google Play o por falta de conformidad técnica.\n" +
                        "• En caso de cualquier error técnico de compra (cobro sin activación de la versión Pro, cambio de dispositivo o duplicidad), el usuario puede pulsar 'Restaurar compras' en la app, acudir a nuestro servidor oficial de Discord (https://discord.gg/MjZsyKjY4r) o escribir a contactoelprocao@gmail.com indicando su ID de pedido de Google Play (GPA.XXXX-XXXX-XXXX-XXXXX) para resolver la incidencia de inmediato."
            )

            SectionItem(
                title = "5. Contacto y Soporte",
                content = "Para soporte comunitario y resolución de dudas dispones de nuestro servidor de Discord oficial (https://discord.gg/MjZsyKjY4r) y para cuestiones legales o comerciales puedes escribir a contactoelprocao@gmail.com."
            )
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "TERMS AND CONDITIONS OF SERVICE",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Last updated: September 2026\nOwner: Phone Finder Detector • Contact: contactoelprocao@gmail.com",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Scope of Service",
                content = "Phone Finder Detector provides a convenience tool to help users locate their misplaced smartphone by recognizing acoustic signals (clapping, whistling, or voice commands)."
            )

            SectionItem(
                title = "2. License Grant",
                content = "Users are granted a personal, non-exclusive, non-transferable, revocable license to use the application on compatible Android devices."
            )

            SectionItem(
                title = "3. Disclaimers and Limitations",
                content = "• Detection accuracy depends on acoustic surroundings, ambient noise, microphone hardware, protective cases, and device battery optimization policies.\n" +
                        "• This app is an acoustic finder tool and is not an emergency service or anti-theft security solution."
            )

            SectionItem(
                title = "4. In-App Purchases & Refund Terms",
                content = "• The 'Remove Ads' in-app purchase permanently eliminates ads and unlocks 15 custom audio slots.\n" +
                        "• All transactions are securely processed through Google Play Billing and governed by Google Play's standard refund policies.\n" +
                        "• Users may submit refund requests through Google Play within the applicable refund window in their purchase history.\n" +
                        "• If you experience any technical glitch, failure to unlock, or switch devices, you can tap 'Restore Purchases' in-app, contact our Discord support (https://discord.gg/MjZsyKjY4r), or email contactoelprocao@gmail.com with your Google Play Order ID (GPA.XXXX-XXXX-XXXX-XXXXX) for immediate assistance."
            )

            SectionItem(
                title = "5. Support & Contact",
                content = "For support or community assistance, visit our Discord server (https://discord.gg/MjZsyKjY4r) or email contactoelprocao@gmail.com."
            )
        }
    }
}

@Composable
private fun RefundPolicyContent(isSpanish: Boolean) {
    val context = LocalContext.current
    if (isSpanish) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "POLÍTICA DE REEMBOLSOS Y DESISTIMIENTO DIGITAL",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Última actualización: Septiembre 2026\nAplicación: Móvil Detector • Responsable: Pablo Valero Trives",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Compras a través de Google Play",
                content = "Todas las compras de productos digitales en Móvil Detector ('Eliminar Anuncios' / 'remove_ads_pro') son procesadas mediante la pasarela de Google Play Billing y están sujetas a los Términos de Servicio y políticas de reembolso de Google Play."
            )

            SectionItem(
                title = "2. Reembolsos en Google Play y Derecho de Desistimiento",
                content = "• Política de Google Play: Puedes solicitar el reembolso de compras digitales directamente a través de tu historial de pedidos en Google Play o en el centro de soporte de Google Play de acuerdo con sus directrices (generalmente dentro de las 48 horas posteriores a la compra).\n" +
                        "• Contenido digital sin soporte material: Conforme a la legislación de consumidores (Art. 103.m LGDCU y Directiva 2011/83/UE), el usuario consiente la ejecución inmediata del contenido. El desistimiento voluntario directo frente al desarrollador tras la activación queda sujeto a dicha entrega inmediata, sin limitar las garantías legales por falta de conformidad o fallos técnicos."
            )

            SectionItem(
                title = "3. Soporte Técnico ante Errores de Facturación o Activación",
                content = "Si experimentas un problema técnico (por ejemplo: Google Play procesó el cargo pero las funciones no se desbloquearon, error de red durante la confirmación, cambio de dispositivo o cargo duplicado):\n\n" +
                        "1. Utiliza el botón 'Restaurar compras' disponible en la app.\n" +
                        "2. Servidor Oficial de Soporte en Discord: Abre un ticket en https://discord.gg/MjZsyKjY4r para atención rápida.\n" +
                        "3. Correo electrónico: Escríbenos a contactoelprocao@gmail.com indicando el problema.\n" +
                        "4. Facilita tu número de pedido oficial de Google Play (identificador que comienza con 'GPA.XXXX-XXXX-XXXX-XXXXX' incluido en el recibo de Google Play). Tras verificar la compra, restauraremos y aseguraremos tu licencia de por vida de inmediato."
            )

            // Tarjeta de acceso a Discord
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Servidor Oficial de Soporte en Discord",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Asistencia directa para compras, errores técnicos y dudas sobre el funcionamiento de Móvil Detector.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.gg/MjZsyKjY4r")).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Abrir Discord de Soporte")
                    }
                }
            }
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "REFUND POLICY & DIGITAL WITHDRAWAL",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Last updated: September 2026\nApplication: Phone Finder Detector • Responsible: Pablo Valero Trives",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionItem(
                title = "1. Google Play In-App Purchases",
                content = "All digital purchases ('Remove Ads' / 'remove_ads_pro') are processed via Google Play Billing and are subject to Google Play Terms of Service and refund policies."
            )

            SectionItem(
                title = "2. Google Play Refunds and Statutory Rights",
                content = "• Google Play Refund Policy: You can request refunds directly via your Google Play order history or Google Play support according to Google Play guidelines (typically within 48 hours of purchase).\n" +
                        "• Digital Content: Pursuant to consumer protection laws (EU Directive 2011/83/EU), voluntary return directly from the developer after immediate digital execution is subject to immediate provision consent, without limiting statutory warranties for defective service."
            )

            SectionItem(
                title = "3. Technical Support for Billing and License Issues",
                content = "If you encounter any technical glitch (payment processed without feature unlock, network loss, device transfer, or duplicate billing):\n\n" +
                        "1. Use 'Restore Purchases' in the app.\n" +
                        "2. Discord Support Server: Open a ticket at https://discord.gg/MjZsyKjY4r for fast assistance.\n" +
                        "3. Email: Write to contactoelprocao@gmail.com with your issue.\n" +
                        "4. Provide your Google Play GPA order ID (format 'GPA.XXXX-XXXX-XXXX-XXXXX' from your email receipt). We will promptly verify and ensure your lifetime license is active."
            )

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Official Discord Support Server",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Direct assistance for purchases, technical troubleshooting, and inquiries.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.gg/MjZsyKjY4r")).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Support Discord")
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionItem(title: String, content: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 18.sp
        )
    }
}

package com.example.widget

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.util.Log
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.repository.SoundRepository
import com.example.hardware.AlertEffectController
import com.example.service.VoiceDetectionService

class DetectorWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE_DETECTION = "com.example.widget.ACTION_TOGGLE_DETECTION"
        private const val TAG = "DetectorWidgetProvider"

        fun updateAllWidgets(context: Context, isListening: Boolean) {
            val appWidgetManager = AppWidgetManager.getInstance(context) ?: return
            val thisWidget = ComponentName(context, DetectorWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            if (appWidgetIds != null && appWidgetIds.isNotEmpty()) {
                for (appWidgetId in appWidgetIds) {
                    updateAppWidget(context, appWidgetManager, appWidgetId, isListening)
                }
            }
        }

        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            isListening: Boolean
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_detector_toggle)

            if (isListening) {
                views.setInt(R.id.widget_button_container, "setBackgroundResource", R.drawable.widget_bg_active)
                views.setImageViewResource(R.id.widget_icon, R.drawable.ic_widget_mic_on)
                views.setTextViewText(R.id.widget_status_text, "Activo")
                views.setTextColor(R.id.widget_status_text, Color.parseColor("#34D399"))
            } else {
                views.setInt(R.id.widget_button_container, "setBackgroundResource", R.drawable.widget_bg_inactive)
                views.setImageViewResource(R.id.widget_icon, R.drawable.ic_widget_mic_off)
                views.setTextViewText(R.id.widget_status_text, "Inactivo")
                views.setTextColor(R.id.widget_status_text, Color.parseColor("#94A3B8"))
            }

            // Click Intent para alternar estado
            val toggleIntent = Intent(context, DetectorWidgetProvider::class.java).apply {
                action = ACTION_TOGGLE_DETECTION
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                toggleIntent,
                flags
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val repository = SoundRepository.getInstance(context)
        val isListening = repository.isListening.value || VoiceDetectionService.isServiceActive.value
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId, isListening)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE_DETECTION) {
            val repository = SoundRepository.getInstance(context)
            val currentListening = repository.isListening.value || VoiceDetectionService.isServiceActive.value
            val alertController = AlertEffectController(context)
            alertController.vibrateToggleFeedback()

            if (currentListening) {
                Log.d(TAG, "Desactivando detector desde Widget")
                repository.setIsListening(false)
                VoiceDetectionService.stop(context)
                updateAllWidgets(context, false)
            } else {
                // Verificar permiso de micrófono antes de activar
                val hasAudioPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (!hasAudioPermission) {
                    Toast.makeText(context, "Abre la aplicación para conceder permiso de micrófono", Toast.LENGTH_SHORT).show()
                    val launchIntent = Intent(context, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    context.startActivity(launchIntent)
                    return
                }

                Log.d(TAG, "Activando detector desde Widget")
                repository.setIsListening(true)
                VoiceDetectionService.start(context)
                updateAllWidgets(context, true)
            }
        }
    }
}

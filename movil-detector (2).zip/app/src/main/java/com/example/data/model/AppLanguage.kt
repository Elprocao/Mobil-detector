package com.example.data.model

import android.app.LocaleManager
import android.content.Context
import android.os.Build
import android.os.LocaleList
import java.util.Locale

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
) {
    SYSTEM_DEFAULT(
        code = "",
        displayName = "Automático",
        nativeName = "Automático (según dispositivo)",
        flagEmoji = "🌐"
    ),
    SPANISH(
        code = "es",
        displayName = "Español",
        nativeName = "Español",
        flagEmoji = "🇪🇸"
    ),
    VALENCIAN(
        code = "ca",
        displayName = "Valenciano",
        nativeName = "Valencià",
        flagEmoji = "🦇"
    ),
    ENGLISH(
        code = "en",
        displayName = "Inglés",
        nativeName = "English",
        flagEmoji = "🇬🇧"
    ),
    FRENCH(
        code = "fr",
        displayName = "Francés",
        nativeName = "Français",
        flagEmoji = "🇫🇷"
    ),
    GERMAN(
        code = "de",
        displayName = "Alemán",
        nativeName = "Deutsch",
        flagEmoji = "🇩🇪"
    ),
    ITALIAN(
        code = "it",
        displayName = "Italiano",
        nativeName = "Italiano",
        flagEmoji = "🇮🇹"
    ),
    PORTUGUESE(
        code = "pt",
        displayName = "Portugués",
        nativeName = "Português",
        flagEmoji = "🇵🇹"
    );

    companion object {
        fun fromCode(code: String?): AppLanguage {
            if (code.isNullOrBlank()) return SYSTEM_DEFAULT
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: SYSTEM_DEFAULT
        }

        fun getEffectiveLanguage(language: AppLanguage): AppLanguage {
            if (language != SYSTEM_DEFAULT) return language
            val deviceLang = Locale.getDefault().language.lowercase()
            return when {
                deviceLang.startsWith("ca") || deviceLang.startsWith("val") -> VALENCIAN
                deviceLang.startsWith("es") -> SPANISH
                deviceLang.startsWith("en") -> ENGLISH
                deviceLang.startsWith("fr") -> FRENCH
                deviceLang.startsWith("de") -> GERMAN
                deviceLang.startsWith("it") -> ITALIAN
                deviceLang.startsWith("pt") -> PORTUGUESE
                else -> SPANISH
            }
        }

        fun applyLanguage(context: Context, language: AppLanguage) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val localeManager = context.getSystemService(Context.LOCALE_SERVICE) as? LocaleManager
                    if (language.code.isBlank()) {
                        localeManager?.applicationLocales = LocaleList.getEmptyLocaleList()
                    } else {
                        localeManager?.applicationLocales = LocaleList.forLanguageTags(language.code)
                    }
                }

                val targetLocale = if (language.code.isBlank()) {
                    Locale.getDefault()
                } else {
                    Locale(language.code)
                }
                Locale.setDefault(targetLocale)
                val resources = context.resources
                val configuration = resources.configuration
                configuration.setLocale(targetLocale)
                @Suppress("DEPRECATION")
                resources.updateConfiguration(configuration, resources.displayMetrics)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

package com.example.data.supabase

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Modelo de datos del perfil de usuario y configuración guardada en Supabase.
 */
@JsonClass(generateAdapter = true)
data class UserProfileSync(
    @Json(name = "user_id") val userId: String,
    @Json(name = "email") val email: String,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "ads_removed") val adsRemoved: Boolean = false,
    @Json(name = "unlocked_slots") val unlockedSlots: Int = 3,
    @Json(name = "trigger_mode") val triggerMode: String = "voice_mode",
    @Json(name = "custom_trigger_phrase") val customTriggerPhrase: String = "Hey Móvil",
    @Json(name = "vibration_intensity") val vibrationIntensity: Int = 1,
    @Json(name = "flash_pattern") val flashPattern: Int = 0,
    @Json(name = "dnd_bypass") val dndBypass: Boolean = true,
    @Json(name = "bluetooth_alert") val bluetoothAlert: Boolean = false,
    @Json(name = "is_dark_mode") val isDarkMode: Boolean = false,
    @Json(name = "app_language") val appLanguage: String = "system",
    @Json(name = "selected_sound_name") val selectedSoundName: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

/**
 * Modelo de metadatos de sonidos guardados en la cuenta en Supabase.
 */
@JsonClass(generateAdapter = true)
data class SoundItemSync(
    @Json(name = "id") val id: String? = null,
    @Json(name = "user_id") val userId: String,
    @Json(name = "name") val name: String,
    @Json(name = "type") val type: String,
    @Json(name = "duration_seconds") val durationSeconds: Int = 2,
    @Json(name = "is_default") val isDefault: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null
)

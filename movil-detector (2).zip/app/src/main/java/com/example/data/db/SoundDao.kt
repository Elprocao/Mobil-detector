package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.SoundEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SoundDao {
    @Query("SELECT * FROM sounds ORDER BY isDefault DESC, createdAt ASC")
    fun getAllSounds(): Flow<List<SoundEntity>>

    @Query("SELECT * FROM sounds ORDER BY isDefault DESC, createdAt ASC")
    suspend fun getAllSoundsList(): List<SoundEntity>

    @Query("SELECT * FROM sounds WHERE id = :id LIMIT 1")
    suspend fun getSoundById(id: Long): SoundEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSound(sound: SoundEntity): Long

    @Delete
    suspend fun deleteSound(sound: SoundEntity)

    @Query("SELECT COUNT(*) FROM sounds")
    suspend fun countSounds(): Int
}

package com.example.service

enum class TriggerMode(val id: String, val title: String, val description: String) {
    VOICE_MODE("voice_mode", "Modo voz", "Di \"Hey Móvil\" o tu frase elegida"),
    CLAP_TWICE("clap_twice", "2 Palmadas", "Da dos palmadas fuertes seguidas"),
    WHISTLE("whistle", "Silbido", "Emite un silbido agudo y constante");

    companion object {
        @Deprecated("Usar VOICE_MODE", ReplaceWith("VOICE_MODE"))
        val VOICE_HEY_MOVIL get() = VOICE_MODE

        fun fromId(id: String?): TriggerMode {
            return when (id) {
                "voice_mode", "voice", "hey_movil", "VOICE_HEY_MOVIL", "VOICE_MODE" -> VOICE_MODE
                "clap_twice", "CLAP_TWICE" -> CLAP_TWICE
                "whistle", "WHISTLE" -> WHISTLE
                else -> VOICE_MODE
            }
        }
    }
}


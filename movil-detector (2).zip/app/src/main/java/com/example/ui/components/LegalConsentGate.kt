package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppLanguage
import com.example.ui.i18n.AppStrings

/**
 * Pantalla de consentimiento legal obligatorio que bloquea la entrada a la app
 * hasta que el usuario acepta expresamente la Política de Privacidad y los Términos de Uso.
 */
@Composable
fun LegalConsentGate(
    appLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit = {},
    onAcceptLegal: () -> Unit
) {
    val s = AppStrings.get(appLanguage)
    var privacyAccepted by remember { mutableStateOf(false) }
    var termsAccepted by remember { mutableStateOf(false) }
    var activeDocToView by remember { mutableStateOf<LegalDocType?>(null) }
    var showRequirementWarning by remember { mutableStateOf(false) }

    val canProceed = privacyAccepted && termsAccepted

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("legal_consent_screen"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Icono escudo de seguridad
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = s.legalTermsWelcome,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = s.legalTermsDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Tarjeta informativa de privacidad de audio en local
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PrivacyTip,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = s.legalPrivacyHighlight,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 17.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Casilla 1: Política de Privacidad
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (privacyAccepted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(
                        if (privacyAccepted) 1.5.dp else 1.dp,
                        if (privacyAccepted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { privacyAccepted = !privacyAccepted }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = privacyAccepted,
                                onCheckedChange = { privacyAccepted = it },
                                modifier = Modifier.testTag("checkbox_legal_privacy"),
                                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = s.legalCheckboxPrivacy,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { activeDocToView = LegalDocType.PRIVACY },
                                modifier = Modifier.testTag("view_privacy_policy_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = s.legalViewPrivacyDoc,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Casilla 2: Términos y Condiciones
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (termsAccepted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(
                        if (termsAccepted) 1.5.dp else 1.dp,
                        if (termsAccepted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { termsAccepted = !termsAccepted }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = termsAccepted,
                                onCheckedChange = { termsAccepted = it },
                                modifier = Modifier.testTag("checkbox_legal_terms"),
                                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = s.legalCheckboxTerms,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { activeDocToView = LegalDocType.TERMS },
                                modifier = Modifier.testTag("view_terms_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Gavel,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = s.legalViewTermsDoc,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                if (showRequirementWarning && !canProceed) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = s.legalMustAcceptToEnter,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Barra inferior con botón de entrada
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        if (canProceed) {
                            onAcceptLegal()
                        } else {
                            showRequirementWarning = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("accept_legal_and_enter_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (canProceed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (canProceed) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    enabled = true
                ) {
                    Icon(
                        imageVector = if (canProceed) Icons.Default.Check else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = s.legalAcceptAndContinue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = s.legalAppBlockedNotice,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    // Modal para leer el documento completo
    activeDocToView?.let { doc ->
        LegalDocumentDialog(
            docType = doc,
            appLanguage = appLanguage,
            onDismiss = { activeDocToView = null }
        )
    }
}

enum class LegalDocType {
    PRIVACY,
    TERMS,
    REFUND
}

@Composable
fun LegalDocumentDialog(
    docType: LegalDocType,
    appLanguage: AppLanguage,
    onDismiss: () -> Unit
) {
    val s = AppStrings.get(appLanguage)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 24.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (docType) {
                                        LegalDocType.PRIVACY -> Icons.Default.PrivacyTip
                                        LegalDocType.TERMS -> Icons.Default.Gavel
                                        LegalDocType.REFUND -> Icons.Default.ReceiptLong
                                    },
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = when (docType) {
                                LegalDocType.PRIVACY -> "Política de Privacidad"
                                LegalDocType.TERMS -> "Términos y Condiciones"
                                LegalDocType.REFUND -> "Política de Reembolsos"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                )

                // Contenido del documento con scroll
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    when (docType) {
                        LegalDocType.PRIVACY -> PrivacyPolicyContent()
                        LegalDocType.TERMS -> TermsOfServiceContent()
                        LegalDocType.REFUND -> RefundPolicyContent()
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                )

                // Botón inferior para cerrar y ver online
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val context = LocalContext.current
                    TextButton(
                        onClick = {
                            try {
                                val url = when (docType) {
                                    LegalDocType.PRIVACY -> "https://elprocao.github.io/Mobil-detector/privacy_policy.html"
                                    LegalDocType.TERMS -> "https://elprocao.github.io/Mobil-detector/terms_of_service.html"
                                    LegalDocType.REFUND -> "https://elprocao.github.io/Mobil-detector/terms_of_service.html#reembolsos"
                                }
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ver online")
                    }

                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(s.closeDoc)
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyPolicyContent() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "POLÍTICA DE PRIVACIDAD DE MÓVIL DETECTOR",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Última actualización: Septiembre 2026\nResponsable: Pablo Valero Trives • Beniarbeig (Alicante, España)\nContacto: contactoelprocao@gmail.com",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionItem(
            title = "1. Principio Fundamental: Privacidad por Diseño",
            content = "Móvil Detector ha sido desarrollado con el compromiso inquebrantable de proteger la privacidad de sus usuarios. No comercializamos, no recopilamos ni compartimos tus grabaciones personales."
        )

        SectionItem(
            title = "2. Tratamiento de Datos del Micrófono (RECORD_AUDIO)",
            content = "• Procesamiento 100% On-Device: El análisis del sonido para detectar palmadas, silbidos o la palabra de activación se realiza de forma efímera y local en la memoria RAM del procesador de tu propio teléfono móvil.\n" +
                    "• Cero Grabaciones Ocultas: La app no graba conversaciones ni crea archivos temporales ocultos de audio ambiental.\n" +
                    "• Cero Transmisión a Servidores: Ningún fragmento de tu voz o entorno acústico se envía a través de Internet ni a servidores nuestros ni de terceros."
        )

        SectionItem(
            title = "3. Uso del Flash y Linterna (FLASHLIGHT)",
            content = "Se emplea exclusivamente la API de hardware de la linterna de Android para hacer parpadear el flash LED como señal visual de localización. La aplicación nunca accede a la lente ni captura fotografías o vídeos."
        )

        SectionItem(
            title = "4. Publicidad y Redes de Anuncios (Google AdMob)",
            content = "Para financiar la versión gratuita, la aplicación integra el SDK de Google AdMob. Google puede recopilar y utilizar identificadores anónimos de publicidad de Android (Advertising ID) y datos de diagnóstico de red para servir anuncios adaptados a las políticas de consentimiento de la UE (RGPD)."
        )

        SectionItem(
            title = "5. Pagos y Facturación (Google Play Billing)",
            content = "Las compras de la versión Sin Anuncios son procesadas íntegramente por los servidores seguros de Google Play. El desarrollador no tiene acceso a números de tarjetas de crédito, cuentas bancarias ni información de pago."
        )

        SectionItem(
            title = "6. Derechos del Usuario (RGPD y Normativa Internacional)",
            content = "Puedes revocar los permisos de micrófono o notificaciones en cualquier momento desde los Ajustes del sistema operativo Android. Para consultas sobre privacidad, contacta directamente con nuestro delegado en contactoelprocao@gmail.com."
        )
    }
}

@Composable
private fun TermsOfServiceContent() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "TÉRMINOS Y CONDICIONES DE USO",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Última actualización: Septiembre 2026\nTitular: Móvil Detector",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionItem(
            title = "1. Objeto del Servicio",
            content = "Móvil Detector proporciona una herramienta de conveniencia para asistir al usuario a encontrar su teléfono mediante el reconocimiento de señales sonoras predefinidas (palmadas, silbidos o comandos de voz)."
        )

        SectionItem(
            title = "2. Condiciones de Licencia",
            content = "Se concede al usuario una licencia personal, no exclusiva, intransferible y revocable para utilizar la aplicación en dispositivos Android compatibles de acuerdo con estos términos."
        )

        SectionItem(
            title = "3. Exención de Garantías y Responsabilidad Técnica",
            content = "• La precisión de la detección puede verse afectada por factores ambientales ajenos a la app: ruido de fondo elevado, micrófonos obstruidos, fundas gruesas, modos de ultra-ahorro de batería o restricciones de gestión de procesos de ciertos fabricantes.\n" +
                    "• La aplicación no sustituye servicios de emergencia ni herramientas de geolocalización antirrobo."
        )

        SectionItem(
            title = "4. Compras Integradas y Política Estricta de Reembolsos",
            content = "• La adquisición de 'Eliminar Anuncios' desbloquea permanentemente los 15 espacios de sonido y suprime todos los anuncios.\n" +
                    "• Contenido digital sin soporte material: De acuerdo con el Art. 103.m del Real Decreto Legislativo 1/2007 de Consumidores y la Directiva Europea 2011/83/UE, el usuario consiente la ejecución inmediata de la compra y reconoce que NO se admiten devoluciones ni reembolsos por desistimiento tras la activación.\n" +
                    "• En caso de cualquier error técnico de compra (cobro sin activación de la versión Pro o cobro duplicado), el usuario debe acudir a nuestro servidor oficial de Discord de soporte (https://discord.gg/MjZsyKjY4r) aportando su ID de pedido oficial de Google Play (GPA.XXXX-XXXX-XXXX-XXXXX) para subsanar la incidencia y restaurar su licencia sin coste alguno, o escribir a contactoelprocao@gmail.com."
        )

        SectionItem(
            title = "5. Contacto y Soporte",
            content = "Para soporte comunitario y resolución de incidencias de compras dispones de nuestro servidor de Discord oficial (https://discord.gg/MjZsyKjY4r) y para cuestiones legales o comerciales puedes escribir a contactoelprocao@gmail.com."
        )
    }
}

@Composable
private fun RefundPolicyContent() {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "POLÍTICA DE REEMBOLSOS Y DESISTIMIENTO DIGITAL",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Última actualización: Septiembre 2026\nAplicación: Móvil Detector • Responsable: Pablo Valero Trives",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionItem(
            title = "1. Regla General: Compras Finales Sin Reembolsos",
            content = "Todas las compras de productos digitales integrados dentro de la aplicación Móvil Detector ('Eliminar Anuncios' / 'remove_ads_pro') tienen carácter definitivo. Una vez abonado el producto y habilitada la funcionalidad sin publicidad en el dispositivo, no se admiten cancelaciones voluntarias ni reembolsos directos."
        )

        SectionItem(
            title = "2. Exclusión Legal del Derecho de Desistimiento",
            content = "En cumplimiento de la legislación española y comunitaria de protección al consumidor (Art. 103, letra m del Real Decreto Legislativo 1/2007 de 16 de noviembre y Art. 16.m de la Directiva 2011/83/UE del Parlamento Europeo):\n" +
                    "• El derecho de desistimiento de 14 días naturales NO es aplicable a contratos de suministro de contenido digital que no se preste en soporte material cuando la ejecución ha comenzado con previo consentimiento expreso del usuario.\n" +
                    "• Al pulsar en comprar dentro de la aplicación, el usuario acepta de forma expresa e inequívoca el suministro inmediato del contenido y reconoce expresamente la pérdida del derecho legal de desistimiento."
        )

        SectionItem(
            title = "3. Procedimiento Ante Errores de Compra o Incidencias Técnicas",
            content = "Si has experimentado un problema técnico atribuible a la pasarela o a la sincronización (por ejemplo, Google Play cargó el importe en tu método de pago pero la app no desbloqueó las funciones, hubo un error de red durante la confirmación, o se produjo una duplicidad injustificada):\n\n" +
                    "1. No tramites reclamaciones bancarias sin antes ponerte en contacto con nosotros.\n" +
                    "2. Acude a nuestro Servidor Oficial de Soporte en Discord: Abre un ticket en el canal de soporte en https://discord.gg/MjZsyKjY4r para atención prioritaria.\n" +
                    "3. Vía de correo electrónico: Puedes escribirnos a contactoelprocao@gmail.com indicando tu caso.\n" +
                    "4. Requisito obligatorio: Aporta el número de pedido oficial de Google Play (identificador que comienza con el formato 'GPA.XXXX-XXXX-XXXX-XXXXX' incluido en el recibo de compra de Google Play). Tras verificar la compra, activaremos y garantizaremos tu licencia de por vida de inmediato."
        )

        // Tarjeta de acceso a Discord
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SupportAgent,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Servidor Oficial de Soporte en Discord",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Asistencia directa para compras, errores técnicos y dudas sobre el funcionamiento de Móvil Detector.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.gg/MjZsyKjY4r")).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Abrir Discord de Soporte")
                }
            }
        }
    }
}

@Composable
private fun SectionItem(title: String, content: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 18.sp
        )
    }
}

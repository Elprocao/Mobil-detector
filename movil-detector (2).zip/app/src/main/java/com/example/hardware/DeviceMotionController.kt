package com.example.hardware

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * Controlador de movimiento con acelerómetro:
 * 1. Detección de movimiento activo mientras escucha:
 *    Si el usuario tiene el teléfono en la mano, camina o gesticula,
 *    pausa o silencia la activación acústica para evitar falsos positivos.
 * 2. Detección de recogida / levantamiento (Pick-up):
 *    Cuando la alarma está sonando, detecta si el usuario coge o levanta
 *    el teléfono para apagar la alarma de inmediato de forma natural.
 */
class DeviceMotionController(
    private val context: Context,
    private val onMotionStateChanged: ((Boolean) -> Unit)? = null
) : SensorEventListener {

    private val TAG = "DeviceMotionController"
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    // Estados de movimiento continuo
    private var lastActiveMotionTimestampMs = 0L
    private var isCurrentlyMoving = false

    // Estados para detección de levantamiento (Pick-up) durante la alarma
    private var isMonitoringPickup = false
    private var pickupArmedTimeMs = 0L
    private var baselineGravityX = 0f
    private var baselineGravityY = 0f
    private var baselineGravityZ = 0f
    private var baselineInitialized = false
    private var filteredX = 0f
    private var filteredY = 0f
    private var filteredZ = 0f
    private var isFilterInitialized = false
    private var consecutiveLiftSamples = 0
    private var onPickedUpCallback: (() -> Unit)? = null

    init {
        try {
            sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining Accelerometer", e)
        }
    }

    /**
     * Inicia la monitorización del acelerómetro en segundo plano con bajo consumo de batería (SENSOR_DELAY_NORMAL).
     */
    fun startMonitoring() {
        if (sensorManager == null || accelerometer == null) {
            Log.w(TAG, "Accelerometer not available")
            return
        }
        try {
            sensorManager?.unregisterListener(this)
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error registering accelerometer listener", e)
        }
    }

    /**
     * Detiene la monitorización del acelerómetro.
     */
    fun stopMonitoring() {
        try {
            sensorManager?.unregisterListener(this)
        } catch (_: Exception) {}
        isMonitoringPickup = false
        onPickedUpCallback = null
    }

    /**
     * Comprueba si el teléfono está en movimiento activo actualmente
     * (por ejemplo, en la mano del usuario, caminando o interactuando).
     * Una ventana de 1500 ms tras el último movimiento mantiene el estado activo.
     */
    fun isPhoneInActiveMotion(): Boolean {
        val now = System.currentTimeMillis()
        return (now - lastActiveMotionTimestampMs) < 1500L
    }

    /**
     * Activa la detección de "Levantar o coger el teléfono" para silenciar la alarma.
     * Cambia temporalmente a alta frecuencia (SENSOR_DELAY_GAME) para máxima reactividad
     * mientras la alarma está sonando.
     */
    fun startPickupDetection(onPickedUp: () -> Unit) {
        onPickedUpCallback = onPickedUp
        isMonitoringPickup = true
        pickupArmedTimeMs = System.currentTimeMillis()
        baselineInitialized = false

        try {
            sensorManager?.unregisterListener(this)
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_GAME
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error elevating accelerometer to SENSOR_DELAY_GAME", e)
        }
    }

    fun stopPickupDetection() {
        isMonitoringPickup = false
        onPickedUpCallback = null
        baselineInitialized = false
        isFilterInitialized = false
        consecutiveLiftSamples = 0

        // Volver al modo de bajo consumo continuo
        startMonitoring()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val totalMagnitude = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        // Aceleración dinámica (descontando la gravedad estática ~9.81 m/s²)
        val dynamicAccel = abs(totalMagnitude - SensorManager.GRAVITY_EARTH)

        val now = System.currentTimeMillis()

        // 1. Detección de movimiento en mano / caminar:
        // Si la aceleración dinámica supera 1.5 m/s², el teléfono se está manipulando o desplazando
        if (dynamicAccel > 1.5f) {
            lastActiveMotionTimestampMs = now
            if (!isCurrentlyMoving) {
                isCurrentlyMoving = true
                onMotionStateChanged?.invoke(true)
            }
        } else if (isCurrentlyMoving && (now - lastActiveMotionTimestampMs) >= 1500L) {
            isCurrentlyMoving = false
            onMotionStateChanged?.invoke(false)
        }

        // 2. Detección de levantamiento / recogida durante la alarma:
        if (isMonitoringPickup) {
            val timeSinceArmed = now - pickupArmedTimeMs

            // Filtro de paso bajo (alpha = 0.8) para eliminar las vibraciones de alta frecuencia del motor (~150-250 Hz)
            val alpha = 0.8f
            if (!isFilterInitialized) {
                filteredX = x
                filteredY = y
                filteredZ = z
                isFilterInitialized = true
            } else {
                filteredX = alpha * filteredX + (1 - alpha) * x
                filteredY = alpha * filteredY + (1 - alpha) * y
                filteredZ = alpha * filteredZ + (1 - alpha) * z
            }

            // Ventana de estabilización inicial (300 a 800 ms) para fijar el vector base de gravedad en reposo
            if (timeSinceArmed in 300..800) {
                baselineGravityX = filteredX
                baselineGravityY = filteredY
                baselineGravityZ = filteredZ
                baselineInitialized = true
            } else if (timeSinceArmed > 800) {
                // Comprobamos si el usuario coge el móvil de la mesa o superficie:
                // Criterio A: Cambio angular significativo en orientación (> 28 grados respecto a la posición de reposo)
                var isTiltedUp = false
                val filteredMag = sqrt((filteredX * filteredX + filteredY * filteredY + filteredZ * filteredZ).toDouble()).toFloat()
                val baseMag = sqrt((baselineGravityX * baselineGravityX + baselineGravityY * baselineGravityY + baselineGravityZ * baselineGravityZ).toDouble()).toFloat()

                if (baselineInitialized && filteredMag > 0.1f && baseMag > 0.1f) {
                    val dotProduct = (filteredX * baselineGravityX + filteredY * baselineGravityY + filteredZ * baselineGravityZ)
                    val cosTheta = (dotProduct / (filteredMag * baseMag)).coerceIn(-1.0f, 1.0f)
                    val angleDegrees = Math.toDegrees(acos(cosTheta.toDouble()))
                    if (angleDegrees > 28.0) {
                        isTiltedUp = true
                    }
                }

                // Criterio B: Aceleración de elevación sostenida (varios fotogramas consecutivos)
                // filtrada para no dispararse por el motor de vibración
                val filteredDynamicAccel = abs(filteredMag - SensorManager.GRAVITY_EARTH)
                if (filteredDynamicAccel > 2.5f) {
                    consecutiveLiftSamples++
                } else {
                    consecutiveLiftSamples = 0
                }
                val isSustainedLift = consecutiveLiftSamples >= 4

                if (isTiltedUp || isSustainedLift) {
                    Log.d(TAG, "¡Teléfono levantado! Silenciando alarma. (Inclinación=$isTiltedUp, Elevación sostenida=$isSustainedLift)")
                    val callback = onPickedUpCallback
                    stopPickupDetection()
                    callback?.invoke()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

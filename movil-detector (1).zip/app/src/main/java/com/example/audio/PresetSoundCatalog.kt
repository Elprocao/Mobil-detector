package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.PI
import kotlin.math.sin

/**
 * Catálogo de sonidos preinstalados listos para descargar o guardar en los slots del usuario.
 * Genera archivos WAV de alta fidelidad con efectos sonoros reconocibles:
 * 1. Sirena de policía (Wail oscilante)
 * 2. Alarma nuclear (Tono grave y pulsante)
 * 3. Timbre de bicicleta (Doble "ring ring" metálico)
 * 4. Maullido fuerte (Sweep de frecuencia expresivo)
 */
object PresetSoundCatalog {
    private const val TAG = "PresetSoundCatalog"

    data class PresetItem(
        val id: String,
        val name: String,
        val description: String,
        val durationSeconds: Int,
        val iconType: String
    )

    val PRESET_ITEMS = listOf(
        PresetItem(
            id = "preset_police_siren",
            name = "Sirena de policía",
            description = "Sonido clásico oscilante de patrulla, estridente y fácil de oír",
            durationSeconds = 3,
            iconType = "siren"
        ),
        PresetItem(
            id = "preset_nuclear_alarm",
            name = "Alarma nuclear",
            description = "Tono grave y penetrante de emergencia industrial",
            durationSeconds = 3,
            iconType = "nuclear"
        ),
        PresetItem(
            id = "preset_bicycle_bell",
            name = "Timbre de bicicleta",
            description = "Doble campanilla metálica aguda y chispeante (Ring-Ring)",
            durationSeconds = 2,
            iconType = "bell"
        ),
        PresetItem(
            id = "preset_loud_meow",
            name = "Maullido fuerte",
            description = "Llamativo maullido felino modulado en frecuencia",
            durationSeconds = 2,
            iconType = "cat"
        )
    )

    /**
     * Genera y escribe el archivo de audio WAV en el directorio local si aún no existe.
     * Devuelve la ruta absoluta del archivo generado.
     */
    fun getOrGeneratePresetFile(context: Context, presetId: String): String? {
        return try {
            val dir = File(context.filesDir, "preset_sounds")
            if (!dir.exists()) dir.mkdirs()

            val targetFile = File(dir, "$presetId.wav")
            if (targetFile.exists() && targetFile.length() > 1000) {
                return targetFile.absolutePath
            }

            val sampleRate = 44100
            val pcmData = when (presetId) {
                "preset_police_siren" -> generatePoliceSirenSamples(sampleRate, durationSec = 3.0)
                "preset_nuclear_alarm" -> generateNuclearAlarmSamples(sampleRate, durationSec = 3.0)
                "preset_bicycle_bell" -> generateBicycleBellSamples(sampleRate)
                "preset_loud_meow" -> generateLoudMeowSamples(sampleRate)
                else -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
            }

            writeWavFile(targetFile, pcmData, sampleRate)
            targetFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error generating preset sound for $presetId", e)
            null
        }
    }

    /**
     * Genera el archivo WAV para el sonido "Saludo" ("¡Hola! ¡Aquí estoy!"),
     * garantizando un audio limpio, melódico y cristalino sin saturación ni distorsión.
     * Si existía un archivo corrupto previo generado en el dispositivo, lo elimina
     * y lo reconstruye de forma garantizada con la firma de versión limpia v2.
     */
    fun getOrGenerateSaludoFile(context: Context, forceRecreate: Boolean = false): String? {
        return try {
            val dir = File(context.filesDir, "preset_sounds")
            if (!dir.exists()) dir.mkdirs()

            val versionMarker = File(dir, ".saludo_clean_v2")
            val targetFile = File(dir, "saludo_vocal.wav")

            // Si el archivo ya existía pero es la versión corrupta anterior o se fuerza recreación,
            // lo eliminamos para reconstruirlo completamente limpio.
            if (forceRecreate || !versionMarker.exists() || !targetFile.exists() || targetFile.length() < 1000) {
                if (targetFile.exists()) {
                    targetFile.delete()
                }
                val sampleRate = 44100
                val pcmData = generateSaludoVocalSamples(sampleRate)
                writeWavFile(targetFile, pcmData, sampleRate)
                try {
                    versionMarker.writeText("clean_v2")
                } catch (_: Exception) {}
            }

            targetFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error generating saludo vocal sound", e)
            null
        }
    }

    /**
     * Síntesis de saludo de alta fidelidad ("¡Hola! ¡Aquí estoy!") mediante síntesis aditiva
     * armónica perfectamente acotada (libre de saturación y sin ruidos parásitos),
     * precedida por campanas alegres de localización para destacar claramente en cualquier ambiente.
     */
    fun generateSaludoVocalSamples(sampleRate: Int): ShortArray {
        val durationSec = 2.6
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        // 1. Campanitas alegres de localización ("Ding-Dong-Ding" brillante de atención)
        val chimeNotes = listOf(
            Triple(0.04, 0.22, 1046.50), // C6
            Triple(0.20, 0.26, 1318.51), // E6
            Triple(0.38, 0.32, 1567.98)  // G6
        )
        for ((start, dur, freq) in chimeNotes) {
            val startIdx = (start * sampleRate).toInt()
            val endIdx = ((start + dur) * sampleRate).toInt().coerceAtMost(totalSamples)
            for (i in startIdx until endIdx) {
                val t = (i - startIdx).toDouble() / sampleRate
                val env = Math.exp(-t * 11.0)
                val wave = 0.65 * sin(2.0 * PI * freq * t) + 0.35 * sin(2.0 * PI * (freq * 2.0) * t)
                val sampleVal = (wave * env * 0.35 * Short.MAX_VALUE).toInt()
                val current = buffer[i].toInt()
                buffer[i] = (current + sampleVal).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }

        // 2. Frase vocal melódica ("¡HO-LA! ... ¡A-QUÍ ES-TOY!")
        // Tonos modelados con armónicos vocales cálidos y envolventes suaves sin cortes
        data class VocalNote(
            val startSec: Double,
            val durSec: Double,
            val startFreq: Double,
            val endFreq: Double,
            val h1: Double,
            val h2: Double,
            val h3: Double,
            val h4: Double
        )

        val vocalNotes = listOf(
            // "¡HO-" (330Hz a 370Hz)
            VocalNote(0.68, 0.30, 330.0, 370.0, 0.45, 0.35, 0.15, 0.05),
            // "-LA!" (370Hz a 294Hz)
            VocalNote(1.00, 0.36, 370.0, 294.0, 0.40, 0.25, 0.25, 0.10),
            // "¡A-" (349Hz a 370Hz)
            VocalNote(1.48, 0.18, 349.0, 370.0, 0.45, 0.25, 0.20, 0.10),
            // "-QUÍ" (494Hz a 523Hz - agudo y resaltado de localización)
            VocalNote(1.68, 0.28, 494.0, 523.0, 0.35, 0.25, 0.25, 0.15),
            // "ES-" (440Hz a 392Hz)
            VocalNote(1.98, 0.18, 440.0, 392.0, 0.45, 0.35, 0.15, 0.05),
            // "-TOY!" (392Hz a 330Hz con resolución cálida)
            VocalNote(2.18, 0.40, 392.0, 330.0, 0.50, 0.30, 0.15, 0.05)
        )

        for (note in vocalNotes) {
            val startIdx = (note.startSec * sampleRate).toInt()
            val numSamples = (note.durSec * sampleRate).toInt()
            var phase = 0.0

            for (j in 0 until numSamples) {
                val idx = startIdx + j
                if (idx >= totalSamples) break

                val progress = j.toDouble() / numSamples
                // Envolvente con ataque suave de 15ms y decaimiento gradual para evitar clicks
                val env = when {
                    progress < 0.12 -> (progress / 0.12)
                    progress > 0.70 -> ((1.0 - progress) / 0.30)
                    else -> 1.0
                }

                val currentFreq = note.startFreq + (note.endFreq - note.startFreq) * progress
                phase += 2.0 * PI * currentFreq / sampleRate
                if (phase > 2.0 * PI) phase -= 2.0 * PI

                val wave = note.h1 * sin(phase) +
                           note.h2 * sin(2.0 * phase) +
                           note.h3 * sin(3.0 * phase) +
                           note.h4 * sin(4.0 * phase)

                val sampleVal = (wave * env * 0.55 * Short.MAX_VALUE).toInt()
                val current = buffer[idx].toInt()
                buffer[idx] = (current + sampleVal).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }

        return buffer
    }

    /**
     * Reproduce una muestra de prueba del preset usando AudioTrack estático en memoria.
     */
    fun playPreview(presetId: String, onDone: () -> Unit): AudioTrack? {
        return try {
            val sampleRate = 44100
            val pcmData = when (presetId) {
                "preset_police_siren" -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
                "preset_nuclear_alarm" -> generateNuclearAlarmSamples(sampleRate, durationSec = 2.0)
                "preset_bicycle_bell" -> generateBicycleBellSamples(sampleRate)
                "preset_loud_meow" -> generateLoudMeowSamples(sampleRate)
                else -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
            }

            val audioTrack = AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
                pcmData.size * 2,
                AudioTrack.MODE_STATIC,
                android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
            )

            audioTrack.write(pcmData, 0, pcmData.size)
            audioTrack.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack?) {
                    try {
                        track?.stop()
                        track?.release()
                    } catch (_: Exception) {}
                    onDone()
                }

                override fun onPeriodicNotification(track: AudioTrack?) {}
            })
            audioTrack.notificationMarkerPosition = pcmData.size
            audioTrack.play()
            audioTrack
        } catch (e: Exception) {
            Log.e(TAG, "Error playing preview for preset", e)
            onDone()
            null
        }
    }

    // 1. Sirena de policía oscilante (650 Hz a 1350 Hz en ciclos de 0.6s)
    private fun generatePoliceSirenSamples(sampleRate: Int, durationSec: Double): ShortArray {
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            // Frecuencia oscilante
            val sweep = 0.5 * (1.0 + sin(2.0 * PI * 1.6 * t))
            val freq = 650.0 + sweep * 700.0 // 650 Hz a 1350 Hz
            phase += 2.0 * PI * freq / sampleRate
            if (phase > 2.0 * PI) phase -= 2.0 * PI

            // Onda sinusoidal enriquecida con armónico suave
            val wave = 0.85 * sin(phase) + 0.15 * sin(2.0 * phase)
            buffer[i] = (wave * Short.MAX_VALUE * 0.92).toInt().toShort()
        }
        return buffer
    }

    // 2. Alarma nuclear (Tono bajo pulsante 420 Hz modulado fuertemente con silencios de alarma)
    private fun generateNuclearAlarmSamples(sampleRate: Int, durationSec: Double): ShortArray {
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val pulseCycle = (t % 0.5) / 0.5 // Ciclo de 500 ms (pulso de alarma)
            val envelope = if (pulseCycle < 0.75) {
                // Sonando con ataque suave
                sin(pulseCycle / 0.75 * PI)
            } else {
                0.0 // Breve pausa entre bocinazos
            }

            // Frecuencia grave penetrante con modulación de vibrato
            val freq = 440.0 + 35.0 * sin(2.0 * PI * 6.0 * t)
            phase += 2.0 * PI * freq / sampleRate
            if (phase > 2.0 * PI) phase -= 2.0 * PI

            val wave = 0.75 * sin(phase) + 0.25 * sin(3.0 * phase)
            buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.95).toInt().toShort()
        }
        return buffer
    }

    // 3. Timbre de bicicleta (Ring-Ring metálico con armónicos 2100 Hz y 2400 Hz)
    private fun generateBicycleBellSamples(sampleRate: Int): ShortArray {
        val durationSec = 1.8
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        val rings = listOf(0.05, 0.45, 0.95, 1.35) // 4 campanadas en pares
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            var sampleSum = 0.0

            for (ringStart in rings) {
                if (t >= ringStart) {
                    val dt = t - ringStart
                    if (dt < 0.35) {
                        // Decaimiento exponencial típico de campana metálica
                        val decay = Math.exp(-dt * 14.0)
                        val chime1 = sin(2.0 * PI * 2093.0 * dt) // C7
                        val chime2 = sin(2.0 * PI * 2520.0 * dt) // Armónico metálico
                        val shimmer = sin(2.0 * PI * 3135.0 * dt) * 0.4
                        sampleSum += (chime1 * 0.5 + chime2 * 0.35 + shimmer) * decay
                    }
                }
            }

            buffer[i] = (sampleSum.coerceIn(-1.0, 1.0) * Short.MAX_VALUE * 0.90).toInt().toShort()
        }
        return buffer
    }

    // 4. Maullido fuerte (Curva ascendente y descendente de frecuencia felina con formantes)
    private fun generateLoudMeowSamples(sampleRate: Int): ShortArray {
        val durationSec = 1.8
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        val meowStarts = listOf(0.1, 0.95) // 2 maullidos expresivos
        for (meowStart in meowStarts) {
            val meowDuration = 0.75
            val startIndex = (meowStart * sampleRate).toInt()
            val meowSamples = (meowDuration * sampleRate).toInt()
            var phase1 = 0.0
            var phase2 = 0.0

            for (j in 0 until meowSamples) {
                val idx = startIndex + j
                if (idx >= totalSamples) break

                val progress = j.toDouble() / meowSamples
                // Envolvente vocal de maullido: sube rápido, se mantiene y baja
                val envelope = when {
                    progress < 0.15 -> progress / 0.15
                    progress < 0.75 -> 1.0 - (progress - 0.15) * 0.3
                    else -> ((1.0 - progress) / 0.25).coerceAtLeast(0.0)
                }

                // Curva de frecuencia: sube de 550 a 920 Hz y luego cae a 620 Hz
                val freq = if (progress < 0.4) {
                    550.0 + (progress / 0.4) * 370.0
                } else {
                    920.0 - ((progress - 0.4) / 0.6) * 300.0
                }

                phase1 += 2.0 * PI * freq / sampleRate
                phase2 += 2.0 * PI * (freq * 1.5) / sampleRate
                if (phase1 > 2.0 * PI) phase1 -= 2.0 * PI
                if (phase2 > 2.0 * PI) phase2 -= 2.0 * PI

                val vocalTone = 0.65 * sin(phase1) + 0.35 * sin(phase2)
                buffer[idx] = (vocalTone * envelope * Short.MAX_VALUE * 0.92).toInt().toShort()
            }
        }
        return buffer
    }

    /**
     * Escribe un archivo de audio WAV PCM de 16 bits estándar compatible con Android.
     */
    private fun writeWavFile(file: File, pcmData: ShortArray, sampleRate: Int) {
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * bitsPerSample / 8
        val totalAudioLen = pcmData.size * 2
        val totalDataLen = totalAudioLen + 36

        FileOutputStream(file).use { out ->
            val header = ByteArray(44)
            // RIFF/WAVE header
            header[0] = 'R'.code.toByte()
            header[1] = 'I'.code.toByte()
            header[2] = 'F'.code.toByte()
            header[3] = 'F'.code.toByte()
            header[4] = (totalDataLen and 0xff).toByte()
            header[5] = ((totalDataLen shr 8) and 0xff).toByte()
            header[6] = ((totalDataLen shr 16) and 0xff).toByte()
            header[7] = ((totalDataLen shr 24) and 0xff).toByte()
            header[8] = 'W'.code.toByte()
            header[9] = 'A'.code.toByte()
            header[10] = 'V'.code.toByte()
            header[11] = 'E'.code.toByte()
            header[12] = 'f'.code.toByte()
            header[13] = 'm'.code.toByte()
            header[14] = 't'.code.toByte()
            header[15] = ' '.code.toByte()
            header[16] = 16
            header[17] = 0
            header[18] = 0
            header[19] = 0
            header[20] = 1 // PCM
            header[21] = 0
            header[22] = numChannels.toByte()
            header[23] = 0
            header[24] = (sampleRate and 0xff).toByte()
            header[25] = ((sampleRate shr 8) and 0xff).toByte()
            header[26] = ((sampleRate shr 16) and 0xff).toByte()
            header[27] = ((sampleRate shr 24) and 0xff).toByte()
            header[28] = (byteRate and 0xff).toByte()
            header[29] = ((byteRate shr 8) and 0xff).toByte()
            header[30] = ((byteRate shr 16) and 0xff).toByte()
            header[31] = ((byteRate shr 24) and 0xff).toByte()
            header[32] = (numChannels * bitsPerSample / 8).toByte()
            header[33] = 0
            header[34] = bitsPerSample.toByte()
            header[35] = 0
            header[36] = 'd'.code.toByte()
            header[37] = 'a'.code.toByte()
            header[38] = 't'.code.toByte()
            header[39] = 'a'.code.toByte()
            header[40] = (totalAudioLen and 0xff).toByte()
            header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
            header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
            header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

            out.write(header, 0, 44)

            // Escribir muestras en Little-Endian
            val byteBuffer = ByteArray(pcmData.size * 2)
            var byteIdx = 0
            for (sample in pcmData) {
                byteBuffer[byteIdx++] = (sample.toInt() and 0xFF).toByte()
                byteBuffer[byteIdx++] = ((sample.toInt() shr 8) and 0xFF).toByte()
            }
            out.write(byteBuffer)
        }
    }
}

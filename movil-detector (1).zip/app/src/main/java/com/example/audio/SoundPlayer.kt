package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.data.model.SoundEntity
import com.example.data.model.SoundType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

class SoundPlayer(private val context: Context) : TextToSpeech.OnInitListener {
    private val TAG = "SoundPlayer"
    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private val scope = CoroutineScope(Dispatchers.Default)
    private var playingJob: Job? = null

    // Audio Focus para pausar música o videos activos en el móvil (YouTube, Spotify, etc.)
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* Mantener el estado */ }

    // Variable para restaurar el volumen original del usuario tras finalizar la alarma
    private var originalMusicVolume: Int? = null
    private var originalAlarmVolume: Int? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing TTS", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            try {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                tts?.setAudioAttributes(audioAttributes)
            } catch (e: Exception) {
                Log.w(TAG, "Could not set TTS AudioAttributes", e)
            }

            val result = tts?.setLanguage(Locale("es", "ES"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default locale
                tts?.language = Locale.getDefault()
            }
            tts?.setPitch(1.3f)
            tts?.setSpeechRate(1.1f)
            isTtsReady = true
        } else {
            Log.e(TAG, "TTS init failed with status: $status")
        }
    }

    /**
     * Ajusta el volumen del sistema al porcentaje especificado (50%, 75% o 100%).
     * Guarda el volumen previo del usuario de forma atómica para poder restaurarlo al terminar la alarma.
     */
    fun applyTargetVolume(targetRatio: Float) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val maxAlarm = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val maxMusic = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

            // Solo capturar el volumen original si no ha sido capturado previamente durante esta sesión de alarma
            if (originalAlarmVolume == null) {
                originalAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
            }
            if (originalMusicVolume == null) {
                originalMusicVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            }

            val alarmTarget = (maxAlarm * targetRatio).toInt().coerceAtLeast(1)
            val musicTarget = (maxMusic * targetRatio).toInt().coerceAtLeast(1)

            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, alarmTarget, 0)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, musicTarget, 0)
        } catch (e: Exception) {
            Log.w(TAG, "Could not adjust audio volume ratio", e)
        }
    }

    fun restoreOriginalVolume() {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            originalAlarmVolume?.let {
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, it, 0)
            }
            originalMusicVolume?.let {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not restore volume", e)
        } finally {
            originalAlarmVolume = null
            originalMusicVolume = null
        }
    }

    /**
     * Solicita foco de audio exclusivo (AUDIOFOCUS_GAIN). Esto provoca que cualquier
     * música, podcast o video en reproducción (YouTube, Spotify, Chrome, etc.) se detenga.
     * Al no liberar el foco de audio o solicitar GAIN permanente, el reproductor externo
     * permanecerá pausado para salvaguardar la privacidad.
     */
    private fun requestAudioFocus() {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener(audioFocusListener)
                    .build()
                audioManager.requestAudioFocus(audioFocusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    audioFocusListener,
                    AudioManager.STREAM_ALARM,
                    AudioManager.AUDIOFOCUS_GAIN
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error requesting audio focus", e)
        }
    }

    private fun abandonAudioFocus() {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusListener)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error abandoning audio focus", e)
        } finally {
            audioFocusRequest = null
        }
    }

    /**
     * Reproduce el ciclo completo de la alarma garantizando un máximo de 10 segundos.
     * Si el sonido dura menos de 10s, se reproduce en bucle continuo hasta completar los 10s.
     * Si dura 10s o más, se detiene automáticamente a los 10s.
     * Si se detiene antes (por el usuario o recogida), se cancela inmediatamente y se restaura el volumen.
     */
    fun playAlarmCycle(
        sound: SoundEntity,
        volumeRatio: Float = 1.0f,
        maxDurationMs: Long = 10_000L,
        dndBypass: Boolean = true,
        onComplete: (() -> Unit)? = null
    ) {
        stopSound()

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val isSilentOrVibrate = audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL

        // Si el usuario deshabilitó DND bypass y el móvil está en silencio/vibración, respetar su elección
        if (!dndBypass && isSilentOrVibrate) {
            Log.d(TAG, "DND bypass desactivado y teléfono en silencio: respetando modo silencio")
            playingJob = scope.launch {
                delay(maxDurationMs)
                launch(Dispatchers.Main) { onComplete?.invoke() }
            }
            return
        }

        requestAudioFocus()
        applyTargetVolume(volumeRatio)

        val startTime = System.currentTimeMillis()

        playingJob = scope.launch {
            try {
                when (sound.type) {
                    SoundType.DEFAULT_BEEPS -> {
                        while (isActive && (System.currentTimeMillis() - startTime) < maxDurationMs) {
                            playTwoBeeps()
                            val remaining = maxDurationMs - (System.currentTimeMillis() - startTime)
                            if (remaining > 250L && isActive) {
                                delay(250L)
                            } else {
                                break
                            }
                        }
                    }
                    SoundType.DEFAULT_FUNNY_VOICE -> {
                        while (isActive && (System.currentTimeMillis() - startTime) < maxDurationMs) {
                            val iterDeferred = CompletableDeferred<Unit>()
                            playSingleSaludoIteration {
                                iterDeferred.complete(Unit)
                            }
                            iterDeferred.await()
                            val remaining = maxDurationMs - (System.currentTimeMillis() - startTime)
                            if (remaining > 300L && isActive) {
                                delay(300L)
                            } else {
                                break
                            }
                        }
                    }
                    SoundType.CUSTOM_RECORDING -> {
                        val path = sound.filePath
                        if (path != null && File(path).exists()) {
                            val completionDeferred = CompletableDeferred<Unit>()
                            launch(Dispatchers.Main) {
                                playCustomFileWith10sCap(path, maxDurationMs, startTime) {
                                    completionDeferred.complete(Unit)
                                }
                            }
                            completionDeferred.await()
                        } else {
                            while (isActive && (System.currentTimeMillis() - startTime) < maxDurationMs) {
                                playTwoBeeps()
                                val remaining = maxDurationMs - (System.currentTimeMillis() - startTime)
                                if (remaining > 250L && isActive) {
                                    delay(250L)
                                } else {
                                    break
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Alarma interrumpida o cancelada: ${e.message}")
            } finally {
                stopAudioPlayback()
                restoreOriginalVolume()
                abandonAudioFocus()
                launch(Dispatchers.Main) {
                    onComplete?.invoke()
                }
            }
        }
    }

    private fun playCustomFileWith10sCap(
        filePath: String,
        maxDurationMs: Long,
        startTime: Long,
        onDone: () -> Unit
    ) {
        try {
            stopAudioPlaybackOnly()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(filePath)
                prepare()
                // Si el audio dura menos de 10s, ponerlo en bucle hasta que venza el tiempo total
                isLooping = duration < maxDurationMs
                start()
            }

            val remainingTime = (maxDurationMs - (System.currentTimeMillis() - startTime)).coerceAtLeast(100L)
            scope.launch {
                delay(remainingTime)
                stopAudioPlaybackOnly()
                onDone()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en reproducción con límite de 10s: ${e.message}", e)
            onDone()
        }
    }

    private fun playSingleSaludoIteration(onIterationDone: () -> Unit) {
        val saludoFilePath = PresetSoundCatalog.getOrGenerateSaludoFile(context)
        if (saludoFilePath != null && File(saludoFilePath).exists()) {
            try {
                stopAudioPlaybackOnly()
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(saludoFilePath)
                    prepare()
                    setOnCompletionListener {
                        stopAudioPlaybackOnly()
                        onIterationDone()
                    }
                    start()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error playing saludo file: ${e.message}", e)
                playSaludoAudioTrackDirect()
                onIterationDone()
            }
        } else {
            playSaludoAudioTrackDirect()
            onIterationDone()
        }
    }

    /**
     * Emite un aviso sonoro corto y agradable cuando se desconectan auriculares Bluetooth.
     */
    fun playShortNotificationBeep() {
        scope.launch {
            try {
                val sampleRate = 44100
                val durationMs = 260
                val numSamples = (sampleRate * durationMs) / 1000
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val freq = 880.0 + (i.toDouble() / numSamples) * 280.0
                    val angle = 2.0 * PI * i * freq / sampleRate
                    val envelope = when {
                        i < 120 -> i / 120.0
                        i > numSamples - 240 -> (numSamples - i) / 240.0
                        else -> 1.0
                    }
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.75 * envelope).toInt().toShort()
                }
                val track = AudioTrack(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                    buffer.size * 2,
                    AudioTrack.MODE_STATIC,
                    AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                track.write(buffer, 0, buffer.size)
                track.play()
                delay(durationMs + 40L)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            } catch (e: Exception) {
                Log.w(TAG, "Error playing short notification beep", e)
            }
        }
    }

    private fun stopAudioPlaybackOnly() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    /**
     * Detiene la reproducción de audio en curso sin restaurar el volumen (útil entre repeticiones consecutivas de la alarma).
     */
    fun stopAudioPlayback() {
        playingJob?.cancel()
        playingJob = null
        stopAudioPlaybackOnly()
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping TTS", e)
        }
    }

    /**
     * Reproduce el sonido seleccionado con el porcentaje de volumen progresivo requerido.
     * Si se reproduce en bucle, el sonido no se superpone y el volumen se mantiene atómico.
     */
    fun playSound(
        sound: SoundEntity,
        volumeRatio: Float = 1.0f,
        onComplete: (() -> Unit)? = null
    ) {
        stopAudioPlayback()
        // Pausar inmediatamente cualquier canción o vídeo en reproducción en el dispositivo
        requestAudioFocus()
        applyTargetVolume(volumeRatio)

        val completionWrapper: () -> Unit = {
            onComplete?.invoke()
        }

        when (sound.type) {
            SoundType.DEFAULT_BEEPS -> {
                playingJob = scope.launch {
                    playTwoBeeps()
                    launch(Dispatchers.Main) { completionWrapper() }
                }
            }
            SoundType.DEFAULT_FUNNY_VOICE -> {
                playSaludoVoice(completionWrapper)
            }
            SoundType.CUSTOM_RECORDING -> {
                val path = sound.filePath
                if (path != null && File(path).exists()) {
                    playCustomFile(path, completionWrapper)
                } else {
                    // Fallback to beeps if file missing
                    playingJob = scope.launch {
                        playTwoBeeps()
                        launch(Dispatchers.Main) { completionWrapper() }
                    }
                }
            }
        }
    }

    /**
     * Detiene la reproducción y restaura de forma segura el volumen original previo del usuario.
     */
    fun stopSound() {
        stopAudioPlayback()
        restoreOriginalVolume()
        abandonAudioFocus()
    }

    fun playCustomFileRange(
        filePath: String,
        startSec: Float,
        endSec: Float,
        volumeRatio: Float = 1.0f,
        onComplete: (() -> Unit)? = null
    ) {
        stopSound()
        requestAudioFocus()
        applyTargetVolume(volumeRatio)

        val completionWrapper: () -> Unit = {
            restoreOriginalVolume()
            abandonAudioFocus()
            onComplete?.invoke()
        }

        try {
            val startMs = (startSec * 1000f).toInt().coerceAtLeast(0)
            val endMs = (endSec * 1000f).toInt()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(filePath)
                prepare()
                seekTo(startMs)
                setOnCompletionListener {
                    completionWrapper()
                }
                start()
            }

            // Scheduled check to stop at endMs if before track duration
            val durationMs = (endMs - startMs).toLong()
            if (durationMs > 200L) {
                playingJob = scope.launch {
                    kotlinx.coroutines.delay(durationMs)
                    stopSound()
                    launch(Dispatchers.Main) {
                        completionWrapper()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing custom file range", e)
            completionWrapper()
        }
    }

    private fun playTwoBeeps() {
        val sampleRate = 44100
        val beep1DurationMs = 280
        val pauseDurationMs = 120
        val beep2DurationMs = 380

        val freq1 = 980.0
        val freq2 = 1350.0

        val numSamplesBeep1 = (sampleRate * beep1DurationMs) / 1000
        val numSamplesPause = (sampleRate * pauseDurationMs) / 1000
        val numSamplesBeep2 = (sampleRate * beep2DurationMs) / 1000
        val totalSamples = numSamplesBeep1 + numSamplesPause + numSamplesBeep2

        val buffer = ShortArray(totalSamples)

        for (i in 0 until numSamplesBeep1) {
            val angle = 2.0 * PI * i * freq1 / sampleRate
            val envelope = when {
                i < 300 -> i / 300.0
                i > numSamplesBeep1 - 300 -> (numSamplesBeep1 - i) / 300.0
                else -> 1.0
            }
            buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.95 * envelope).toInt().toShort()
        }

        val startBeep2 = numSamplesBeep1 + numSamplesPause
        for (i in 0 until numSamplesBeep2) {
            val angle = 2.0 * PI * i * freq2 / sampleRate
            val envelope = when {
                i < 300 -> i / 300.0
                i > numSamplesBeep2 - 300 -> (numSamplesBeep2 - i) / 300.0
                else -> 1.0
            }
            buffer[startBeep2 + i] = (sin(angle) * Short.MAX_VALUE * 0.98 * envelope).toInt().toShort()
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val track = AudioTrack(
            audioAttributes,
            audioFormat,
            buffer.size * 2,
            AudioTrack.MODE_STATIC,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        track.write(buffer, 0, buffer.size)
        track.play()

        Thread.sleep(beep1DurationMs + pauseDurationMs + beep2DurationMs + 100L)
        try {
            track.stop()
            track.release()
        } catch (_: Exception) {}
    }

    private fun playSaludoVoice(onComplete: (() -> Unit)?) {
        playingJob = scope.launch {
            val saludoFilePath = PresetSoundCatalog.getOrGenerateSaludoFile(context)
            if (saludoFilePath != null && File(saludoFilePath).exists()) {
                val completionDeferred = CompletableDeferred<Unit>()
                launch(Dispatchers.Main) {
                    playCustomFile(saludoFilePath) {
                        completionDeferred.complete(Unit)
                    }
                }
                completionDeferred.await()
            } else {
                playSaludoAudioTrackDirect()
            }

            launch(Dispatchers.Main) { onComplete?.invoke() }
        }
    }

    private fun playSaludoAudioTrackDirect() {
        try {
            val sampleRate = 44100
            val pcmData = PresetSoundCatalog.generateSaludoVocalSamples(sampleRate)

            val track = AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
                pcmData.size * 2,
                AudioTrack.MODE_STATIC,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
            track.write(pcmData, 0, pcmData.size)
            track.play()
            Thread.sleep((pcmData.size * 1000L / sampleRate) + 80L)
            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}
        } catch (e: Exception) {
            Log.e(TAG, "Error playing direct saludo audio track", e)
        }
    }

    private fun playCustomFile(filePath: String, onComplete: (() -> Unit)?) {
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    onComplete?.invoke()
                }
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing custom audio file", e)
            onComplete?.invoke()
        }
    }

    fun release() {
        stopSound()
        try {
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {}
    }
}

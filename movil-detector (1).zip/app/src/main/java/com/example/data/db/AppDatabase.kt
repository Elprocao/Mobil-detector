package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.SoundEntity
import com.example.data.model.SoundType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SoundTypeConverters {
    @TypeConverter
    fun fromSoundType(type: SoundType): String = type.name

    @TypeConverter
    fun toSoundType(value: String): SoundType = try {
        SoundType.valueOf(value)
    } catch (e: Exception) {
        SoundType.DEFAULT_BEEPS
    }
}

@Database(entities = [SoundEntity::class], version = 1, exportSchema = false)
@TypeConverters(SoundTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun soundDao(): SoundDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "movil_detector.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).soundDao()
                            dao.insertSound(
                                SoundEntity(
                                    id = 1,
                                    name = "Dos pitidos",
                                    type = SoundType.DEFAULT_BEEPS,
                                    durationSeconds = 2,
                                    isDefault = true
                                )
                            )
                            dao.insertSound(
                                SoundEntity(
                                    id = 2,
                                    name = "Saludo",
                                    type = SoundType.DEFAULT_FUNNY_VOICE,
                                    durationSeconds = 3,
                                    isDefault = true
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

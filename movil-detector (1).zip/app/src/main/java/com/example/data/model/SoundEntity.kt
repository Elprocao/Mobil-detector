package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SoundType {
    DEFAULT_BEEPS,
    DEFAULT_FUNNY_VOICE,
    CUSTOM_RECORDING;

    companion object {
        val DEFAULT_SALUDO get() = DEFAULT_FUNNY_VOICE
    }
}

@Entity(tableName = "sounds")
data class SoundEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: SoundType,
    val filePath: String? = null,
    val durationSeconds: Int = 2,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    /**
     * Los sonidos predeterminados ("Dos pitidos" y "Saludo") son permanentes,
     * nunca pueden ser eliminados por el usuario y garantizan que la app siempre tenga sonido.
     */
    val isPermanentDefault: Boolean
        get() = isDefault ||
                type == SoundType.DEFAULT_BEEPS ||
                type == SoundType.DEFAULT_FUNNY_VOICE ||
                name.equals("Dos pitidos", ignoreCase = true) ||
                name.equals("Saludo", ignoreCase = true) ||
                name.equals("Hola gracioso", ignoreCase = true)
}

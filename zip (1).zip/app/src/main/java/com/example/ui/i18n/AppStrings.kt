package com.example.ui.i18n

import com.example.data.model.AppLanguage

/**
 * Diccionario centralizado de textos multiidioma para la interfaz de Móvil Detector.
 * Soporta actualización reactiva instantánea al cambiar el idioma sin reiniciar la app.
 */
object AppStrings {

    fun get(lang: AppLanguage): Strings {
        val effective = AppLanguage.getEffectiveLanguage(lang)
        return when (effective) {
            AppLanguage.VALENCIAN -> ValencianStrings
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.FRENCH -> FrenchStrings
            AppLanguage.GERMAN -> GermanStrings
            AppLanguage.ITALIAN -> ItalianStrings
            AppLanguage.PORTUGUESE -> PortugueseStrings
            AppLanguage.SPANISH, AppLanguage.SYSTEM_DEFAULT -> SpanishStrings
        }
    }

    interface Strings {
        // TopBar
        val appTitle: String
        val appSubtitle: String
        val proBadge: String
        val settingsMenuCd: String

        // Hero Card
        val listeningActive: String
        val listeningPaused: String
        val tapToActivate: String
        val sayPhrase: (String) -> String
        val clapTwice: String
        val whistle: String
        val heroListeningDesc: String
        val heroPausedDesc: String
        val detectedVoice: (String) -> String
        val micStatusCd: String

        // System mic warning
        val micBlockedTitle: String
        val micBlockedDesc: String

        // Slots Card
        val slotsTitle: String
        val slotsProSubtitle: String
        val slotsFreeSubtitle: String
        val slotsOccupied: (Int, Int) -> String
        val slotsCurrentCapacity: (Int) -> String
        val slotsMax: (Int) -> String
        val exploreCatalogButton: String
        val watchAdToUnlockButton: (Int) -> String

        // Sounds List
        val soundsHeaderTitle: String
        val soundsHeaderSubtitle: String
        val defaultBeepsDesc: String
        val defaultVoiceDesc: String
        val customRecordingDesc: (Int) -> String
        val playSoundCd: String
        val pauseSoundCd: String
        val editNameCd: String
        val deleteSoundCd: String
        val newSoundFab: (Int, Int) -> String
        val soundSelectedSnackbar: (String) -> String

        // Floating & actions
        val maxSlotsReached: String
        val removeAdsTitle: String
        val removeAdsDesc: String
        val unlockWithAd: String
        val cancel: String
        val understood: String
        val grantPermission: String
        val micPermissionTitle: String
        val micPermissionDesc: String

        // Legal Consent First Run Dialog
        val legalTermsTitle: String
        val legalTermsWelcome: String
        val legalTermsDescription: String
        val legalCheckboxPrivacy: String
        val legalCheckboxTerms: String
        val legalPrivacyHighlight: String
        val legalAcceptAndContinue: String
        val legalViewPrivacyDoc: String
        val legalViewTermsDoc: String
        val legalMustAcceptToEnter: String
        val legalAppBlockedNotice: String

        // Legal viewer dialog
        val closeDoc: String

        // Settings Sheet Menus
        val settingsTitle: String
        val settingsDetectionTitle: String
        val settingsDetectionSubtitle: String
        val settingsAlarmTitle: String
        val settingsAlarmSubtitle: String
        val settingsAppearanceTitle: String
        val settingsAppearanceSubtitle: String
        val settingsLanguageTitle: String
        val settingsLanguageSubtitle: String
        val settingsProTitle: String
        val settingsProSubtitle: String
        val settingsSupportTitle: String
        val settingsSupportSubtitle: String
        val settingsLegalTitle: String
        val settingsLegalSubtitle: String

        // Language submenu
        val languageAutoTitle: String
        val languageAutoDesc: (String) -> String
        val languageFixedDesc: (String, String) -> String
        val availableLanguages: String
        val systemDefaultTag: String
        val languageChangedToast: (String) -> String
    }

    object SpanishStrings : Strings {
        override val appTitle = "Móvil Detector"
        override val appSubtitle = "Encuentra tu teléfono al instante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menú de ajustes"

        override val listeningActive = "ESCUCHA ACTIVA"
        override val listeningPaused = "DETECTOR EN PAUSA"
        override val tapToActivate = "Toca para activar"
        override val sayPhrase = { phrase: String -> "Di \"$phrase\"" }
        override val clapTwice = "Da 2 palmadas seguidas"
        override val whistle = "Emite un silbido"
        override val heroListeningDesc = "Responderá de inmediato con linterna, vibración y volumen inteligente (incluso con la pantalla bloqueada)."
        override val heroPausedDesc = "El servicio está en reposo. Pulsa el botón para ponerlo a escuchar en segundo plano."
        override val detectedVoice = { text: String -> "Detectado: \"$text\"" }
        override val micStatusCd = "Estado de micrófono"

        override val micBlockedTitle = "Micrófono bloqueado en Android"
        override val micBlockedDesc = "El acceso al micrófono está desactivado en la barra de ajustes rápidos del sistema. Actívalo para que la app pueda escuchar."

        override val slotsTitle = "Espacios de Sonidos"
        override val slotsProSubtitle = "Plan PRO • Todos desbloqueados"
        override val slotsFreeSubtitle = "3 iniciales • Ampliable hasta 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupados" }
        override val slotsCurrentCapacity = { count: Int -> "Capacidad actual: $count sonidos" }
        override val slotsMax = { max: Int -> "Máximo: $max" }
        override val exploreCatalogButton = "Explorar catálogo de efectos divertidos"
        override val watchAdToUnlockButton = { next: Int -> "Ver anuncio breve para desbloquear espacio #$next" }

        override val soundsHeaderTitle = "Sonidos de respuesta"
        override val soundsHeaderSubtitle = "Toca para elegir cómo contestará el móvil. Puedes editar el nombre o eliminarlos."
        override val defaultBeepsDesc = "Alerta aguda • Doble tono"
        override val defaultVoiceDesc = "Voz de saludo • \"¡Hola! ¡Aquí estoy!\""
        override val customRecordingDesc = { sec: Int -> "Grabación propia • ${sec}s" }
        override val playSoundCd = "Escuchar sonido"
        override val pauseSoundCd = "Pausar sonido"
        override val editNameCd = "Editar nombre"
        override val deleteSoundCd = "Eliminar sonido"
        override val newSoundFab = { cur: Int, max: Int -> "Nuevo sonido ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Sonido seleccionado: $name" }

        override val maxSlotsReached = "Has alcanzado el límite máximo de 15 sonidos."
        override val removeAdsTitle = "Espacios de sonido llenos"
        override val removeAdsDesc = "Has ocupado todos tus espacios disponibles. Puedes desbloquear más viendo un anuncio o con la versión PRO."
        override val unlockWithAd = "Desbloquear con anuncio"
        override val cancel = "Cancelar"
        override val understood = "Entendido"
        override val grantPermission = "Conceder permiso"
        override val micPermissionTitle = "Permiso de micrófono requerido"
        override val micPermissionDesc = "Para detectar tu voz, palmadas o silbidos cuando tu móvil esté perdido, la aplicación necesita acceso al micrófono."

        override val legalTermsTitle = "Condiciones y Privacidad"
        override val legalTermsWelcome = "Bienvenido a Móvil Detector"
        override val legalTermsDescription = "Para poder utilizar la aplicación y activar la escucha en tu dispositivo, es obligatorio leer y aceptar nuestras condiciones de uso y política de privacidad."
        override val legalCheckboxPrivacy = "He leído y acepto la Política de Privacidad (procesamiento de audio 100% en el dispositivo)."
        override val legalCheckboxTerms = "Acepto los Términos y Condiciones de Uso de la aplicación."
        override val legalPrivacyHighlight = "🔒 Privacidad garantizada: El audio se procesa de forma efímera en la memoria de tu móvil. No se graba ni se envía ninguna conversación a servidores externos."
        override val legalAcceptAndContinue = "Aceptar y entrar a la app"
        override val legalViewPrivacyDoc = "Leer Política de Privacidad"
        override val legalViewTermsDoc = "Leer Términos y Condiciones"
        override val legalMustAcceptToEnter = "Debes marcar ambas casillas para poder acceder a la aplicación."
        override val legalAppBlockedNotice = "El acceso permanece bloqueado hasta aceptar los términos legales."

        override val closeDoc = "Cerrar"

        override val settingsTitle = "Ajustes de la aplicación"
        override val settingsDetectionTitle = "Detección y Activación"
        override val settingsDetectionSubtitle = "Modo voz, palmadas, silbido y palabra clave"
        override val settingsAlarmTitle = "Alarma y Respuesta"
        override val settingsAlarmSubtitle = "Linterna, vibración, volumen y modo silencio"
        override val settingsAppearanceTitle = "Pantalla y Personalización"
        override val settingsAppearanceSubtitle = "Tema claro/oscuro y sonidos predeterminados"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automático, Español, Valencià, English..."
        override val settingsProTitle = "Plan PRO y Licencia"
        override val settingsProSubtitle = "Eliminar anuncios y funciones completas"
        override val settingsSupportTitle = "Soporte"
        override val settingsSupportSubtitle = "Servidor oficial de Discord para ayuda y sugerencias"
        override val settingsLegalTitle = "Legal y Privacidad"
        override val settingsLegalSubtitle = "Consultar términos aceptados y política de datos"

        override val languageAutoTitle = "Detección automática activa"
        override val languageAutoDesc = { detected: String -> "El idioma se adapta al de tu móvil. Actualmente: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fijado en $native ($display)." }
        override val availableLanguages = "Idiomas disponibles"
        override val systemDefaultTag = "Predeterminado"
        override val languageChangedToast = { lang: String -> "Idioma seleccionado: $lang" }
    }

    object ValencianStrings : Strings {
        override val appTitle = "Mòbil Detector"
        override val appSubtitle = "Troba el teu telèfon a l'instant"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menú d'ajustos"

        override val listeningActive = "ESCOLTA ACTIVA"
        override val listeningPaused = "DETECTOR EN PAUSA"
        override val tapToActivate = "Toca per a activar"
        override val sayPhrase = { phrase: String -> "Diu \"$phrase\"" }
        override val clapTwice = "Dóna 2 palmades seguides"
        override val whistle = "Fes un xiulit"
        override val heroListeningDesc = "Respondrà de seguida amb llanterna, vibració i volum intel·ligent (fins i tot amb la pantalla bloquejada)."
        override val heroPausedDesc = "El servei està en repòs. Prem el botó per a posar-lo a escoltar en segon pla."
        override val detectedVoice = { text: String -> "Detectat: \"$text\"" }
        override val micStatusCd = "Estat del micròfon"

        override val micBlockedTitle = "Micròfon bloquejat en Android"
        override val micBlockedDesc = "L'accés al micròfon està desactivat en la barra d'ajustos ràpids. Activa'l perquè l'app puga escoltar."

        override val slotsTitle = "Espais de Sons"
        override val slotsProSubtitle = "Pla PRO • Tots desbloquejats"
        override val slotsFreeSubtitle = "3 inicials • Ampliable fins a 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupats" }
        override val slotsCurrentCapacity = { count: Int -> "Capacitat actual: $count sons" }
        override val slotsMax = { max: Int -> "Màxim: $max" }
        override val exploreCatalogButton = "Explorar catàleg d'efectes divertits"
        override val watchAdToUnlockButton = { next: Int -> "Veure anunci breu per a desbloquejar espai #$next" }

        override val soundsHeaderTitle = "Sons de resposta"
        override val soundsHeaderSubtitle = "Toca per a triar com contestarà el mòbil. Pots editar el nom o esborrar-los."
        override val defaultBeepsDesc = "Alerta aguda • Doble to"
        override val defaultVoiceDesc = "Veu de salutació • \"Hola! Sóc ací!\""
        override val customRecordingDesc = { sec: Int -> "Gravació pròpia • ${sec}s" }
        override val playSoundCd = "Escoltar so"
        override val pauseSoundCd = "Pausar so"
        override val editNameCd = "Editar nom"
        override val deleteSoundCd = "Esborrar so"
        override val newSoundFab = { cur: Int, max: Int -> "Nou so ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "So seleccionat: $name" }

        override val maxSlotsReached = "Has aconseguit el límit màxim de 15 sons."
        override val removeAdsTitle = "Espais de so plens"
        override val removeAdsDesc = "Has ocupat tots els espais disponibles. Pots desbloquejar-ne més veient un anunci o amb el Pla PRO."
        override val unlockWithAd = "Desbloquejar amb anunci"
        override val cancel = "Cancel·lar"
        override val understood = "Entés"
        override val grantPermission = "Concedir permís"
        override val micPermissionTitle = "Permís de micròfon necessari"
        override val micPermissionDesc = "Per a detectar la teua veu, palmades o xiulits quan el mòbil estiga perdut, l'aplicació necessita accés al micròfon."

        override val legalTermsTitle = "Condicions i Privacitat"
        override val legalTermsWelcome = "Benvingut a Mòbil Detector"
        override val legalTermsDescription = "Per a poder utilitzar l'aplicació i activar l'escolta en el teu dispositiu, cal llegir i acceptar les condicions d'ús i la política de privacitat."
        override val legalCheckboxPrivacy = "He llegit i accepte la Política de Privacitat (processament d'àudio 100% en el dispositiu)."
        override val legalCheckboxTerms = "Accepte els Termes i Condicions d'Ús de l'aplicació."
        override val legalPrivacyHighlight = "🔒 Privacitat garantida: L'àudio es processa de manera efímera en la memòria del teu mòbil. No es grava ni s'envia cap conversa a servidors externs."
        override val legalAcceptAndContinue = "Acceptar i entrar a l'app"
        override val legalViewPrivacyDoc = "Llegir Política de Privacitat"
        override val legalViewTermsDoc = "Llegir Termes i Condicions"
        override val legalMustAcceptToEnter = "Has de marcar ambdues caselles per a poder accedir a l'aplicació."
        override val legalAppBlockedNotice = "L'accés roman bloquejat fins que s'accepten els termes legals."

        override val closeDoc = "Tancar"

        override val settingsTitle = "Ajustos de l'aplicació"
        override val settingsDetectionTitle = "Detecció i Activació"
        override val settingsDetectionSubtitle = "Mode veu, palmades, xiulit i paraula clau"
        override val settingsAlarmTitle = "Alarma i Resposta"
        override val settingsAlarmSubtitle = "Llanterna, vibració, volum i mode silenci"
        override val settingsAppearanceTitle = "Pantalla i Personalització"
        override val settingsAppearanceSubtitle = "Tema clar/fosc i sons predeterminats"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automàtic, Valencià, Castellà, English..."
        override val settingsProTitle = "Pla PRO i Llicència"
        override val settingsProSubtitle = "Eliminar anuncis i funcions completes"
        override val settingsSupportTitle = "Suport"
        override val settingsSupportSubtitle = "Servidor oficial de Discord per a ajuda i suggeriments"
        override val settingsLegalTitle = "Legal i Privacitat"
        override val settingsLegalSubtitle = "Consultar termes acceptats i política de dades"

        override val languageAutoTitle = "Detecció automàtica activa"
        override val languageAutoDesc = { detected: String -> "L'idioma s'adapta al del teu mòbil. Actualment: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fixat en $native ($display)." }
        override val availableLanguages = "Idiomes disponibles"
        override val systemDefaultTag = "Predeterminat"
        override val languageChangedToast = { lang: String -> "Idioma seleccionat: $lang" }
    }

    object EnglishStrings : Strings {
        override val appTitle = "Phone Finder Detector"
        override val appSubtitle = "Find your phone instantly"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Settings menu"

        override val listeningActive = "LISTENING ACTIVE"
        override val listeningPaused = "DETECTOR PAUSED"
        override val tapToActivate = "Tap to activate"
        override val sayPhrase = { phrase: String -> "Say \"$phrase\"" }
        override val clapTwice = "Clap twice"
        override val whistle = "Whistle"
        override val heroListeningDesc = "It will respond instantly with flashlight, vibration and progressive volume (even when locked)."
        override val heroPausedDesc = "Service is idle. Tap the button to enable background listening."
        override val detectedVoice = { text: String -> "Heard: \"$text\"" }
        override val micStatusCd = "Microphone status"

        override val micBlockedTitle = "Microphone blocked in Android"
        override val micBlockedDesc = "Microphone access is toggled off in system quick settings. Turn it on for the app to listen."

        override val slotsTitle = "Sound Slots"
        override val slotsProSubtitle = "PRO Plan • All unlocked"
        override val slotsFreeSubtitle = "3 initial • Expandable up to 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupied" }
        override val slotsCurrentCapacity = { count: Int -> "Current capacity: $count sounds" }
        override val slotsMax = { max: Int -> "Max: $max" }
        override val exploreCatalogButton = "Explore fun sound effects catalog"
        override val watchAdToUnlockButton = { next: Int -> "Watch quick ad to unlock slot #$next" }

        override val soundsHeaderTitle = "Response Sounds"
        override val soundsHeaderSubtitle = "Tap to choose how your phone responds. You can rename or delete them."
        override val defaultBeepsDesc = "High alert • Double beep"
        override val defaultVoiceDesc = "Greeting voice • \"Hello! Here I am!\""
        override val customRecordingDesc = { sec: Int -> "Custom recording • ${sec}s" }
        override val playSoundCd = "Play sound"
        override val pauseSoundCd = "Pause sound"
        override val editNameCd = "Edit name"
        override val deleteSoundCd = "Delete sound"
        override val newSoundFab = { cur: Int, max: Int -> "New sound ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Selected sound: $name" }

        override val maxSlotsReached = "You have reached the maximum capacity of 15 sounds."
        override val removeAdsTitle = "Sound slots full"
        override val removeAdsDesc = "You have filled all available slots. Unlock more by watching an ad or upgrading to PRO."
        override val unlockWithAd = "Unlock with ad"
        override val cancel = "Cancel"
        override val understood = "Understood"
        override val grantPermission = "Grant permission"
        override val micPermissionTitle = "Microphone permission required"
        override val micPermissionDesc = "To detect your trigger phrase, claps or whistles when lost, the app requires microphone access."

        override val legalTermsTitle = "Terms & Privacy"
        override val legalTermsWelcome = "Welcome to Phone Finder Detector"
        override val legalTermsDescription = "To use the app and enable listening on your device, you must review and accept our terms of service and privacy policy."
        override val legalCheckboxPrivacy = "I have read and accept the Privacy Policy (100% on-device audio processing)."
        override val legalCheckboxTerms = "I accept the Terms and Conditions of Use."
        override val legalPrivacyHighlight = "🔒 Guaranteed Privacy: Audio is processed ephemerally in device RAM. No voice or recording is ever saved or sent to any server."
        override val legalAcceptAndContinue = "Accept & enter app"
        override val legalViewPrivacyDoc = "View Privacy Policy"
        override val legalViewTermsDoc = "View Terms & Conditions"
        override val legalMustAcceptToEnter = "You must check both boxes to access the application."
        override val legalAppBlockedNotice = "Access remains locked until legal terms are accepted."

        override val closeDoc = "Close"

        override val settingsTitle = "App Settings"
        override val settingsDetectionTitle = "Detection & Triggers"
        override val settingsDetectionSubtitle = "Voice phrase, clapping, whistling and keyword"
        override val settingsAlarmTitle = "Alarm & Response"
        override val settingsAlarmSubtitle = "Flashlight, vibration, volume and silent bypass"
        override val settingsAppearanceTitle = "Appearance & Display"
        override val settingsAppearanceSubtitle = "Dark/light theme and reset defaults"
        override val settingsLanguageTitle = "Language"
        override val settingsLanguageSubtitle = "Automatic, English, Spanish, French..."
        override val settingsProTitle = "PRO Plan & License"
        override val settingsProSubtitle = "Remove ads and unlock all features"
        override val settingsSupportTitle = "Support"
        override val settingsSupportSubtitle = "Official Discord server for help and suggestions"
        override val settingsLegalTitle = "Legal & Privacy"
        override val settingsLegalSubtitle = "View accepted terms and data privacy policy"

        override val languageAutoTitle = "Automatic detection active"
        override val languageAutoDesc = { detected: String -> "App language matches your phone language. Current: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fixed to $native ($display)." }
        override val availableLanguages = "Available Languages"
        override val systemDefaultTag = "Default"
        override val languageChangedToast = { lang: String -> "Language selected: $lang" }
    }

    object FrenchStrings : Strings {
        override val appTitle = "Détecteur Téléphone"
        override val appSubtitle = "Retrouvez votre téléphone instantanément"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu paramètres"

        override val listeningActive = "ÉCOUTE ACTIVE"
        override val listeningPaused = "DÉTECTEUR EN PAUSE"
        override val tapToActivate = "Appuyer pour activer"
        override val sayPhrase = { phrase: String -> "Dites \"$phrase\"" }
        override val clapTwice = "Tapez 2 fois dans les mains"
        override val whistle = "Sifflez"
        override val heroListeningDesc = "Répondra immédiatement par lampe torche, vibration et volume progressif."
        override val heroPausedDesc = "Service en pause. Appuyez sur le bouton pour activer l'écoute."
        override val detectedVoice = { text: String -> "Détecté : \"$text\"" }
        override val micStatusCd = "État du microphone"

        override val micBlockedTitle = "Microphone bloqué sur Android"
        override val micBlockedDesc = "L'accès au micro est désactivé dans les paramètres rapides. Activez-le pour permettre l'écoute."

        override val slotsTitle = "Emplacements de Sons"
        override val slotsProSubtitle = "Plan PRO • Tout débloqué"
        override val slotsFreeSubtitle = "3 initiaux • Extensible jusqu'à 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupés" }
        override val slotsCurrentCapacity = { count: Int -> "Capacité actuelle : $count sons" }
        override val slotsMax = { max: Int -> "Maximum : $max" }
        override val exploreCatalogButton = "Explorer le catalogue d'effets sonores"
        override val watchAdToUnlockButton = { next: Int -> "Voir pub pour débloquer l'emplacement #$next" }

        override val soundsHeaderTitle = "Sons de réponse"
        override val soundsHeaderSubtitle = "Touchez pour choisir comment le téléphone répondra."
        override val defaultBeepsDesc = "Alerte aiguë • Double bip"
        override val defaultVoiceDesc = "Voix amicale • \"Salut ! Je suis ici !\""
        override val customRecordingDesc = { sec: Int -> "Enregistrement personnel • ${sec}s" }
        override val playSoundCd = "Écouter"
        override val pauseSoundCd = "Pause"
        override val editNameCd = "Modifier le nom"
        override val deleteSoundCd = "Supprimer le son"
        override val newSoundFab = { cur: Int, max: Int -> "Nouveau son ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Son sélectionné : $name" }

        override val maxSlotsReached = "Limite maximale de 15 sons atteinte."
        override val removeAdsTitle = "Emplacements pleins"
        override val removeAdsDesc = "Tous les emplacements sont occupés. Débloquez-en plus avec une pub ou en version PRO."
        override val unlockWithAd = "Débloquer avec publicité"
        override val cancel = "Annuler"
        override val understood = "Compris"
        override val grantPermission = "Accorder l'autorisation"
        override val micPermissionTitle = "Autorisation micro requise"
        override val micPermissionDesc = "Pour détecter vos mains ou votre voix, l'application a besoin du micro."

        override val legalTermsTitle = "Conditions et Confidentialité"
        override val legalTermsWelcome = "Bienvenue sur Détecteur Téléphone"
        override val legalTermsDescription = "Pour utiliser l'application et activer l'écoute, vous devez lire et accepter nos conditions et politique de confidentialité."
        override val legalCheckboxPrivacy = "J'ai lu et j'accepte la Politique de Confidentialité (traitement 100% local)."
        override val legalCheckboxTerms = "J'accepte les Conditions Générales d'Utilisation."
        override val legalPrivacyHighlight = "🔒 Confidentialité garantie : Le son est traité uniquement dans la mémoire RAM. Aucun enregistrement n'est envoyé à des serveurs."
        override val legalAcceptAndContinue = "Accepter et accéder à l'app"
        override val legalViewPrivacyDoc = "Lire Politique de Confidentialité"
        override val legalViewTermsDoc = "Lire Conditions d'Utilisation"
        override val legalMustAcceptToEnter = "Vous devez cocher les deux cases pour entrer dans l'application."
        override val legalAppBlockedNotice = "L'accès reste bloqué tant que les conditions ne sont pas acceptées."

        override val closeDoc = "Fermer"

        override val settingsTitle = "Paramètres de l'application"
        override val settingsDetectionTitle = "Détection et Déclencheurs"
        override val settingsDetectionSubtitle = "Mode voix, claquements, sifflement et mot-clé"
        override val settingsAlarmTitle = "Alarme et Réponse"
        override val settingsAlarmSubtitle = "Lampe torche, vibration et volume"
        override val settingsAppearanceTitle = "Apparence et Thème"
        override val settingsAppearanceSubtitle = "Thème sombre/clair et réinitialisation"
        override val settingsLanguageTitle = "Langue"
        override val settingsLanguageSubtitle = "Automatique, Français, Anglais, Espagnol..."
        override val settingsProTitle = "Plan PRO et Licence"
        override val settingsProSubtitle = "Supprimer les publicités et tout débloquer"
        override val settingsSupportTitle = "Support"
        override val settingsSupportSubtitle = "Serveur Discord officiel pour aide et retours"
        override val settingsLegalTitle = "Légal et Confidentialité"
        override val settingsLegalSubtitle = "Consulter les termes acceptés"

        override val languageAutoTitle = "Détection automatique active"
        override val languageAutoDesc = { detected: String -> "La langue s'adapte à celle de votre téléphone ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Fixé sur $native ($display)." }
        override val availableLanguages = "Langues disponibles"
        override val systemDefaultTag = "Par défaut"
        override val languageChangedToast = { lang: String -> "Langue sélectionnée : $lang" }
    }

    object GermanStrings : Strings {
        override val appTitle = "Handy Finder Detektor"
        override val appSubtitle = "Finde dein Smartphone sofort wieder"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Einstellungsmenü"

        override val listeningActive = "ERKENNUNG AKTIV"
        override val listeningPaused = "DETEKTOR PAUSIERT"
        override val tapToActivate = "Tippen zum Aktivieren"
        override val sayPhrase = { phrase: String -> "Sage \"$phrase\"" }
        override val clapTwice = "2 Mal klatschen"
        override val whistle = "Pfeifen"
        override val heroListeningDesc = "Reagiert sofort mit Taschenlampe, Vibration und Lautstärke."
        override val heroPausedDesc = "Detektor im Ruhezustand. Tippen zum Starten."
        override val detectedVoice = { text: String -> "Erkannt: \"$text\"" }
        override val micStatusCd = "Mikrofonstatus"

        override val micBlockedTitle = "Mikrofon in Android blockiert"
        override val micBlockedDesc = "Der Mikrofonzugriff ist in den Schnelleinstellungen deaktiviert."

        override val slotsTitle = "Sound-Plätze"
        override val slotsProSubtitle = "PRO-Plan • Alle freigeschaltet"
        override val slotsFreeSubtitle = "3 Plätze • Erweiterbar bis 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max belegt" }
        override val slotsCurrentCapacity = { count: Int -> "Aktuelle Kapazität: $count Sounds" }
        override val slotsMax = { max: Int -> "Maximal: $max" }
        override val exploreCatalogButton = "Soundeffekte-Katalog durchsuchen"
        override val watchAdToUnlockButton = { next: Int -> "Kurzes Video ansehen für Platz #$next" }

        override val soundsHeaderTitle = "Antwort-Töne"
        override val soundsHeaderSubtitle = "Wähle aus, wie das Telefon antworten soll."
        override val defaultBeepsDesc = "Hoher Warnton • Doppelsignal"
        override val defaultVoiceDesc = "Stimme • \"Hallo! Hier bin ich!\""
        override val customRecordingDesc = { sec: Int -> "Eigene Aufnahme • ${sec}s" }
        override val playSoundCd = "Abspielen"
        override val pauseSoundCd = "Pause"
        override val editNameCd = "Namen bearbeiten"
        override val deleteSoundCd = "Sound löschen"
        override val newSoundFab = { cur: Int, max: Int -> "Neuer Ton ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Ausgewählter Ton: $name" }

        override val maxSlotsReached = "Maximales Limit von 15 Tönen erreicht."
        override val removeAdsTitle = "Sound-Plätze voll"
        override val removeAdsDesc = "Schalte weitere Plätze durch kurze Werbung oder mit PRO frei."
        override val unlockWithAd = "Mit Video freischalten"
        override val cancel = "Abbrechen"
        override val understood = "Verstanden"
        override val grantPermission = "Berechtigung erteilen"
        override val micPermissionTitle = "Mikrofon-Berechtigung erforderlich"
        override val micPermissionDesc = "Um Klatschen oder Rufen zu erkennen, wird Mikrofonzugriff benötigt."

        override val legalTermsTitle = "Bedingungen & Datenschutz"
        override val legalTermsWelcome = "Willkommen bei Handy Finder Detektor"
        override val legalTermsDescription = "Um die App zu nutzen, müssen Sie die Nutzungsbedingungen und die Datenschutzerklärung akzeptieren."
        override val legalCheckboxPrivacy = "Ich akzeptiere die Datenschutzerklärung (100% lokale Audioverarbeitung)."
        override val legalCheckboxTerms = "Ich akzeptiere die Allgemeinen Geschäftsbedingungen."
        override val legalPrivacyHighlight = "🔒 Garantierter Datenschutz: Audio wird nur lokal im RAM verarbeitet. Es werden keine Daten übertragen."
        override val legalAcceptAndContinue = "Akzeptieren und fortfahren"
        override val legalViewPrivacyDoc = "Datenschutzerklärung lesen"
        override val legalViewTermsDoc = "Nutzungsbedingungen lesen"
        override val legalMustAcceptToEnter = "Sie müssen beide Optionen ankreuzen, um fortzufahren."
        override val legalAppBlockedNotice = "Der Zugriff bleibt gesperrt, bis die Bedingungen akzeptiert wurden."

        override val closeDoc = "Schließen"

        override val settingsTitle = "App-Einstellungen"
        override val settingsDetectionTitle = "Erkennung & Auslöser"
        override val settingsDetectionSubtitle = "Sprachmodus, Klatschen, Pfeifen"
        override val settingsAlarmTitle = "Alarm & Reaktion"
        override val settingsAlarmSubtitle = "Taschenlampe, Vibration und Lautstärke"
        override val settingsAppearanceTitle = "Darstellung"
        override val settingsAppearanceSubtitle = "Dunkelmodus und Standardtöne"
        override val settingsLanguageTitle = "Sprache"
        override val settingsLanguageSubtitle = "Automatisch, Deutsch, Englisch..."
        override val settingsProTitle = "PRO-Plan & Lizenz"
        override val settingsProSubtitle = "Werbung entfernen und Vollversion"
        override val settingsSupportTitle = "Hilfe & Support"
        override val settingsSupportSubtitle = "Offizieller Discord-Server"
        override val settingsLegalTitle = "Rechtliches"
        override val settingsLegalSubtitle = "Bedingungen und Datenschutz einsehen"

        override val languageAutoTitle = "Automatische Erkennung aktiv"
        override val languageAutoDesc = { detected: String -> "Sprache passt sich dem Gerät an: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Eingestellt auf $native ($display)." }
        override val availableLanguages = "Verfügbare Sprachen"
        override val systemDefaultTag = "Standard"
        override val languageChangedToast = { lang: String -> "Sprache ausgewählt: $lang" }
    }

    object ItalianStrings : Strings {
        override val appTitle = "Trova Telefono"
        override val appSubtitle = "Trova il tuo telefono all'istante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu impostazioni"

        override val listeningActive = "ASCOLTO ATTIVO"
        override val listeningPaused = "RILEVATORE IN PAUSA"
        override val tapToActivate = "Tocca per attivare"
        override val sayPhrase = { phrase: String -> "Dì \"$phrase\"" }
        override val clapTwice = "Batti le mani 2 volte"
        override val whistle = "Fischia"
        override val heroListeningDesc = "Risponderà subito con torcia, vibrazione e volume intelligente."
        override val heroPausedDesc = "Servizio in pausa. Tocca per iniziare ad ascoltare."
        override val detectedVoice = { text: String -> "Rilevato: \"$text\"" }
        override val micStatusCd = "Stato microfono"

        override val micBlockedTitle = "Microfono disattivato su Android"
        override val micBlockedDesc = "L'accesso al microfono è disattivato nelle impostazioni rapide di sistema."

        override val slotsTitle = "Slot Suoni"
        override val slotsProSubtitle = "Piano PRO • Tutti sbloccati"
        override val slotsFreeSubtitle = "3 iniziali • Espandibile fino a 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupati" }
        override val slotsCurrentCapacity = { count: Int -> "Capacità attuale: $count suoni" }
        override val slotsMax = { max: Int -> "Massimo: $max" }
        override val exploreCatalogButton = "Esplora catalogo effetti sonori"
        override val watchAdToUnlockButton = { next: Int -> "Guarda breve annuncio per sbloccare slot #$next" }

        override val soundsHeaderTitle = "Suoni di risposta"
        override val soundsHeaderSubtitle = "Tocca per scegliere come risponderà il cellulare."
        override val defaultBeepsDesc = "Allarme acuto • Doppio beep"
        override val defaultVoiceDesc = "Voce di saluto • \"Ciao! Sono qui!\""
        override val customRecordingDesc = { sec: Int -> "Registrazione propria • ${sec}s" }
        override val playSoundCd = "Ascolta"
        override val pauseSoundCd = "Pausa"
        override val editNameCd = "Modifica nome"
        override val deleteSoundCd = "Elimina suono"
        override val newSoundFab = { cur: Int, max: Int -> "Nuovo suono ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Suono selezionato: $name" }

        override val maxSlotsReached = "Raggiunto il limite massimo di 15 suoni."
        override val removeAdsTitle = "Slot pieni"
        override val removeAdsDesc = "Sblocca altri slot guardando una pubblicità o con il piano PRO."
        override val unlockWithAd = "Sblocca con annuncio"
        override val cancel = "Annulla"
        override val understood = "Ho capito"
        override val grantPermission = "Concedi permesso"
        override val micPermissionTitle = "Permesso microfono necessario"
        override val micPermissionDesc = "Per rilevare la tua voce, battiti o fischi, l'app ha bisogno del microfono."

        override val legalTermsTitle = "Termini e Privacy"
        override val legalTermsWelcome = "Benvenuto in Trova Telefono"
        override val legalTermsDescription = "Per usare l'applicazione è obbligatorio leggere e accettare i termini d'uso e l'informativa sulla privacy."
        override val legalCheckboxPrivacy = "Ho letto e accetto l'Informativa sulla Privacy (elaborazione audio 100% sul dispositivo)."
        override val legalCheckboxTerms = "Accetto i Termini e le Condizioni d'Uso."
        override val legalPrivacyHighlight = "🔒 Privacy garantita: L'audio viene elaborato esclusivamente nella RAM del dispositivo. Nessuna voce viene salvata o inviata a server."
        override val legalAcceptAndContinue = "Accetta ed entra nell'app"
        override val legalViewPrivacyDoc = "Leggi Informativa Privacy"
        override val legalViewTermsDoc = "Leggi Termini d'Uso"
        override val legalMustAcceptToEnter = "Devi selezionare entrambe le caselle per entrare nell'app."
        override val legalAppBlockedNotice = "L'accesso è bloccato finché non si accettano i termini legali."

        override val closeDoc = "Chiudi"

        override val settingsTitle = "Impostazioni applicazione"
        override val settingsDetectionTitle = "Rilevamento e Attivazione"
        override val settingsDetectionSubtitle = "Modalità voce, battito, fischio"
        override val settingsAlarmTitle = "Allarme e Risposta"
        override val settingsAlarmSubtitle = "Torcia, vibrazione e volume"
        override val settingsAppearanceTitle = "Aspetto e Tema"
        override val settingsAppearanceSubtitle = "Tema chiaro/scuro"
        override val settingsLanguageTitle = "Lingua"
        override val settingsLanguageSubtitle = "Automatico, Italiano, Spagnolo, Inglese..."
        override val settingsProTitle = "Piano PRO e Licenza"
        override val settingsProSubtitle = "Rimuovi annunci e sblocca tutto"
        override val settingsSupportTitle = "Supporto"
        override val settingsSupportSubtitle = "Server Discord ufficiale per aiuto"
        override val settingsLegalTitle = "Legale e Privacy"
        override val settingsLegalSubtitle = "Visualizza termini e condizioni"

        override val languageAutoTitle = "Rilevamento automatico attivo"
        override val languageAutoDesc = { detected: String -> "La lingua corrisponde a quella del dispositivo ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Impostato su $native ($display)." }
        override val availableLanguages = "Lingue disponibili"
        override val systemDefaultTag = "Predefinito"
        override val languageChangedToast = { lang: String -> "Lingua selezionata: $lang" }
    }

    object PortugueseStrings : Strings {
        override val appTitle = "Localizador de Telemóvel"
        override val appSubtitle = "Encontra o teu telemóvel num instante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu de definições"

        override val listeningActive = "ESCUTA ATIVA"
        override val listeningPaused = "DETETOR EM PAUSA"
        override val tapToActivate = "Toca para ativar"
        override val sayPhrase = { phrase: String -> "Diz \"$phrase\"" }
        override val clapTwice = "Bate 2 palmas seguidas"
        override val whistle = "Assobia"
        override val heroListeningDesc = "Responderá de imediato com lanterna, vibração e volume progressivo."
        override val heroPausedDesc = "Serviço em pausa. Toca para ativar a escuta em segundo plano."
        override val detectedVoice = { text: String -> "Detetado: \"$text\"" }
        override val micStatusCd = "Estado do microfone"

        override val micBlockedTitle = "Microfone bloqueado no Android"
        override val micBlockedDesc = "O microfone está desativado nas definições rápidas do sistema."

        override val slotsTitle = "Espaços de Sons"
        override val slotsProSubtitle = "Plano PRO • Todos desbloqueados"
        override val slotsFreeSubtitle = "3 iniciais • Expansível até 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupados" }
        override val slotsCurrentCapacity = { count: Int -> "Capacidade atual: $count sons" }
        override val slotsMax = { max: Int -> "Máximo: $max" }
        override val exploreCatalogButton = "Explorar catálogo de efeitos sonoros"
        override val watchAdToUnlockButton = { next: Int -> "Ver anúncio para desbloquear espaço #$next" }

        override val soundsHeaderTitle = "Sons de resposta"
        override val soundsHeaderSubtitle = "Toca para escolher como o telemóvel irá responder."
        override val defaultBeepsDesc = "Alerta agudo • Duplo bip"
        override val defaultVoiceDesc = "Voz amigável • \"Olá! Estou aqui!\""
        override val customRecordingDesc = { sec: Int -> "Gravação própria • ${sec}s" }
        override val playSoundCd = "Ouvir som"
        override val pauseSoundCd = "Pausar som"
        override val editNameCd = "Editar nome"
        override val deleteSoundCd = "Eliminar som"
        override val newSoundFab = { cur: Int, max: Int -> "Novo som ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Som selecionado: $name" }

        override val maxSlotsReached = "Atingiste o limite máximo de 15 sons."
        override val removeAdsTitle = "Espaços cheios"
        override val removeAdsDesc = "Desbloqueia mais espaços vendo um anúncio ou atualizando para PRO."
        override val unlockWithAd = "Desbloquear com anúncio"
        override val cancel = "Cancelar"
        override val understood = "Entendido"
        override val grantPermission = "Conceder permissão"
        override val micPermissionTitle = "Permissão de microfone necessária"
        override val micPermissionDesc = "Para detetar a tua voz, palmas ou assobios, a app precisa do microfone."

        override val legalTermsTitle = "Termos e Privacidade"
        override val legalTermsWelcome = "Bem-vindo ao Localizador de Telemóvel"
        override val legalTermsDescription = "Para utilizar a aplicação, é obrigatório ler e aceitar as condições de utilização e a política de privacidade."
        override val legalCheckboxPrivacy = "Li e aceito a Política de Privacidade (processamento de áudio 100% no dispositivo)."
        override val legalCheckboxTerms = "Aceito os Termos e Condições de Utilização."
        override val legalPrivacyHighlight = "🔒 Privacidade garantida: O áudio é processado de forma efémera na memória do telemóvel. Nenhuma conversa é enviada para servidores."
        override val legalAcceptAndContinue = "Aceitar e entrar na app"
        override val legalViewPrivacyDoc = "Ler Política de Privacidade"
        override val legalViewTermsDoc = "Ler Termos e Condições"
        override val legalMustAcceptToEnter = "Deves marcar ambas as caixas para aceder à aplicação."
        override val legalAppBlockedNotice = "O acesso permanece bloqueado até aceitares os termos legais."

        override val closeDoc = "Fechar"

        override val settingsTitle = "Definições da aplicação"
        override val settingsDetectionTitle = "Deteção e Ativação"
        override val settingsDetectionSubtitle = "Modo voz, palmas, assobio e palavra-chave"
        override val settingsAlarmTitle = "Alarme e Resposta"
        override val settingsAlarmSubtitle = "Lanterna, vibração e volume"
        override val settingsAppearanceTitle = "Aparência e Ecrã"
        override val settingsAppearanceSubtitle = "Tema claro/escuro"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automático, Português, Espanhol, Inglês..."
        override val settingsProTitle = "Plano PRO e Licença"
        override val settingsProSubtitle = "Remover anúncios e funcionalidades totais"
        override val settingsSupportTitle = "Suporte"
        override val settingsSupportSubtitle = "Servidor oficial do Discord para ajuda"
        override val settingsLegalTitle = "Legal e Privacidade"
        override val settingsLegalSubtitle = "Consultar termos aceites"

        override val languageAutoTitle = "Deteção automática ativa"
        override val languageAutoDesc = { detected: String -> "O idioma adapta-se ao do teu telemóvel ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Definido para $native ($display)." }
        override val availableLanguages = "Idiomas disponíveis"
        override val systemDefaultTag = "Predefinido"
        override val languageChangedToast = { lang: String -> "Idioma selecionado: $lang" }
    }
}

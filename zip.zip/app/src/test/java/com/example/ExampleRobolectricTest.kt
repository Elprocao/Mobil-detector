package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.SoundRepository
import com.example.hardware.FlashPattern
import com.example.hardware.VibrationIntensity
import com.example.service.TriggerMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Movil Detector", appName)
    }

    @Test
    fun `test SoundRepository initialization and default sounds`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = SoundRepository.getInstance(context)
        assertNotNull(repo)

        // Verificación de configuración inicial
        repo.setTriggerMode(TriggerMode.VOICE_MODE)
        assertEquals(TriggerMode.VOICE_MODE, repo.triggerMode.value)

        repo.setFlashPattern(FlashPattern.FAST_STROBE)
        assertEquals(FlashPattern.FAST_STROBE, repo.flashPattern.value)

        repo.setVibrationIntensity(VibrationIntensity.HIGH)
        assertEquals(VibrationIntensity.HIGH, repo.vibrationIntensity.value)

        repo.setDndBypass(true)
        assertTrue(repo.dndBypass.value)

        repo.setBluetoothAlertEnabled(true)
        assertTrue(repo.bluetoothAlertEnabled.value)
    }
}

package com.example.hardware

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * Controlador de movimiento con acelerómetro:
 * 1. Detección de movimiento activo mientras escucha:
 *    Si el usuario tiene el teléfono en la mano, camina o gesticula,
 *    pausa o silencia la activación acústica para evitar falsos positivos.
 * 2. Detección de recogida / levantamiento (Pick-up):
 *    Cuando la alarma está sonando, detecta si el usuario coge o levanta
 *    el teléfono para apagar la alarma de inmediato de forma natural.
 */
class DeviceMotionController(
    private val context: Context,
    private val onMotionStateChanged: ((Boolean) -> Unit)? = null
) : SensorEventListener {

    private val TAG = "DeviceMotionController"
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    // Estados de movimiento continuo
    private var lastActiveMotionTimestampMs = 0L
    private var isCurrentlyMoving = false

    // Estados para detección de levantamiento (Pick-up) durante la alarma
    private var isMonitoringPickup = false
    private var pickupArmedTimeMs = 0L
    private var baselineGravityX = 0f
    private var baselineGravityY = 0f
    private var baselineGravityZ = 0f
    private var baselineInitialized = false
    private var onPickedUpCallback: (() -> Unit)? = null

    init {
        try {
            sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining Accelerometer", e)
        }
    }

    /**
     * Inicia la monitorización del acelerómetro en segundo plano con bajo consumo de batería (SENSOR_DELAY_NORMAL).
     */
    fun startMonitoring() {
        if (sensorManager == null || accelerometer == null) {
            Log.w(TAG, "Accelerometer not available")
            return
        }
        try {
            sensorManager?.unregisterListener(this)
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error registering accelerometer listener", e)
        }
    }

    /**
     * Detiene la monitorización del acelerómetro.
     */
    fun stopMonitoring() {
        try {
            sensorManager?.unregisterListener(this)
        } catch (_: Exception) {}
        isMonitoringPickup = false
        onPickedUpCallback = null
    }

    /**
     * Comprueba si el teléfono está en movimiento activo actualmente
     * (por ejemplo, en la mano del usuario, caminando o interactuando).
     * Una ventana de 1500 ms tras el último movimiento mantiene el estado activo.
     */
    fun isPhoneInActiveMotion(): Boolean {
        val now = System.currentTimeMillis()
        return (now - lastActiveMotionTimestampMs) < 1500L
    }

    /**
     * Activa la detección de "Levantar o coger el teléfono" para silenciar la alarma.
     * Cambia temporalmente a alta frecuencia (SENSOR_DELAY_GAME) para máxima reactividad
     * mientras la alarma está sonando.
     */
    fun startPickupDetection(onPickedUp: () -> Unit) {
        onPickedUpCallback = onPickedUp
        isMonitoringPickup = true
        pickupArmedTimeMs = System.currentTimeMillis()
        baselineInitialized = false

        try {
            sensorManager?.unregisterListener(this)
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_GAME
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error elevating accelerometer to SENSOR_DELAY_GAME", e)
        }
    }

    fun stopPickupDetection() {
        isMonitoringPickup = false
        onPickedUpCallback = null
        baselineInitialized = false

        // Volver al modo de bajo consumo continuo
        startMonitoring()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val totalMagnitude = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        // Aceleración dinámica (descontando la gravedad estática ~9.81 m/s²)
        val dynamicAccel = abs(totalMagnitude - SensorManager.GRAVITY_EARTH)

        val now = System.currentTimeMillis()

        // 1. Detección de movimiento en mano / caminar:
        // Si la aceleración dinámica supera 1.5 m/s², el teléfono se está manipulando o desplazando
        if (dynamicAccel > 1.5f) {
            lastActiveMotionTimestampMs = now
            if (!isCurrentlyMoving) {
                isCurrentlyMoving = true
                onMotionStateChanged?.invoke(true)
            }
        } else if (isCurrentlyMoving && (now - lastActiveMotionTimestampMs) >= 1500L) {
            isCurrentlyMoving = false
            onMotionStateChanged?.invoke(false)
        }

        // 2. Detección de levantamiento / recogida durante la alarma:
        if (isMonitoringPickup) {
            val timeSinceArmed = now - pickupArmedTimeMs

            // Ventana de 700 ms para capturar la orientación base de reposo antes de la recogida
            if (timeSinceArmed in 200..700) {
                baselineGravityX = x
                baselineGravityY = y
                baselineGravityZ = z
                baselineInitialized = true
            } else if (timeSinceArmed > 700) {
                // Pasado el periodo de amortiguación:
                // Comprobamos si el usuario levanta o manipula el móvil:
                // Criterio A: Impulso de aceleración de recogida (> 2.8 m/s²)
                val isLiftingImpulse = dynamicAccel > 2.8f

                // Criterio B: Cambio angular significativo de orientación (el teléfono estaba sobre la mesa
                // y se inclina > 25 grados hacia el usuario al cogerlo)
                var isTiltedUp = false
                if (baselineInitialized) {
                    val dotProduct = (x * baselineGravityX + y * baselineGravityY + z * baselineGravityZ)
                    val magCurrent = totalMagnitude
                    val magBase = sqrt((baselineGravityX * baselineGravityX + baselineGravityY * baselineGravityY + baselineGravityZ * baselineGravityZ).toDouble()).toFloat()
                    if (magCurrent > 0f && magBase > 0f) {
                        val cosTheta = (dotProduct / (magCurrent * magBase)).coerceIn(-1.0f, 1.0f)
                        val angleDegrees = Math.toDegrees(acos(cosTheta.toDouble()))
                        if (angleDegrees > 25.0) {
                            isTiltedUp = true
                        }
                    }
                }

                if (isLiftingImpulse || isTiltedUp) {
                    Log.d(TAG, "¡Teléfono levantado! Silenciando alarma. (Impulso=$isLiftingImpulse, Inclinación=$isTiltedUp)")
                    val callback = onPickedUpCallback
                    stopPickupDetection()
                    callback?.invoke()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

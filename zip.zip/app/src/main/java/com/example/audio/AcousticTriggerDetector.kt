package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detector de sonido acústico en tiempo real de alta precisión:
 * - 2 Palmadas: Detección estricta de pulsos impulsivos con comprobación de tiempo de ataque,
 *   factor de cresta elevado, rápida extinción transitoria y rechazo explícito de la voz humana y tos.
 * - Silbido: Detección por autocorrelación normalizada y pureza armónica sinusoidal en la banda
 *   de 950 Hz a 2800 Hz con filtro de rechazo de soplo y respiración.
 */
class AcousticTriggerDetector(
    private val context: Context,
    private val onTriggerDetected: (reason: String) -> Unit,
    private val onRmsUpdated: ((Float) -> Unit)? = null,
    private val isMotionSuppressed: (() -> Boolean)? = null
) {
    private val TAG = "AcousticTriggerDetector"
    private val scope = CoroutineScope(Dispatchers.Default)
    private var listeningJob: Job? = null
    @Volatile
    private var audioRecord: AudioRecord? = null
    @Volatile
    private var isAudioRunning = false

    // Estados para 2 palmadas
    private var lastClapTimeMs = 0L
    private var clapCandidateTimeMs = 0L
    private var waitingForClapDecay = false
    private var candidateClapAmp = 0
    private var candidateClapRms = 0.0
    private var continuousSpeechCounter = 0
    private var lastClapTriggerTimeMs = 0L

    // Estados para silbidos (detección por correlación de pureza sinusoidal)
    private var whistleConfidence = 0
    private var lastWhistleTriggerTimeMs = 0L

    @SuppressLint("MissingPermission")
    fun startListening(modeIsClap: Boolean) {
        stopListening()

        val sampleRates = intArrayOf(16000, 44100, 22050)
        var selectedRate = 16000
        var record: AudioRecord? = null

        for (rate in sampleRates) {
            val minBuf = AudioRecord.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf > 0) {
                try {
                    val candidate = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        rate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        max(minBuf, 4096)
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        record = candidate
                        selectedRate = rate
                        break
                    } else {
                        candidate.release()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Sample rate $rate not supported: ${e.message}")
                }
            }
        }

        if (record == null) {
            Log.e(TAG, "No suitable AudioRecord found")
            return
        }

        try {
            record.startRecording()
            audioRecord = record
            isAudioRunning = true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting AudioRecord", e)
            try { record.release() } catch (_: Exception) {}
            return
        }

        lastClapTimeMs = 0L
        clapCandidateTimeMs = 0L
        waitingForClapDecay = false
        continuousSpeechCounter = 0
        whistleConfidence = 0

        listeningJob = scope.launch {
            val shortBuffer = ShortArray(1024)
            while (isActive && isAudioRunning) {
                val currentRecord = audioRecord ?: break
                if (currentRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) break

                val readCount = try {
                    currentRecord.read(shortBuffer, 0, shortBuffer.size)
                } catch (e: Exception) {
                    Log.w(TAG, "AudioRecord read interrumpido: ${e.message}")
                    -1
                }
                if (readCount <= 0 || !isAudioRunning) continue

                // Si el usuario tiene el móvil en la mano o se está moviendo activamente, suprimir detección
                if (isMotionSuppressed?.invoke() == true) {
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    continuousSpeechCounter = 0
                    whistleConfidence = 0
                    continue
                }

                // 1. Remoción de DC offset (sesgo de continua común en micrófonos)
                var sum = 0.0
                for (i in 0 until readCount) {
                    sum += shortBuffer[i].toInt()
                }
                val mean = sum / readCount

                var sumSquare = 0.0
                var maxAmp = 0
                var zeroCrossings = 0
                var prevSample = 0.0

                for (i in 0 until readCount) {
                    val sample = shortBuffer[i].toInt() - mean
                    sumSquare += sample * sample
                    val absSample = abs(sample).toInt()
                    if (absSample > maxAmp) maxAmp = absSample

                    if (i > 0 && ((sample >= 0 && prevSample < 0) || (sample < 0 && prevSample >= 0))) {
                        zeroCrossings++
                    }
                    prevSample = sample
                }

                val rms = sqrt(sumSquare / readCount)
                val rmsDb = (20 * kotlin.math.log10(rms.coerceAtLeast(1.0))).toFloat()
                onRmsUpdated?.invoke(rmsDb)

                val now = System.currentTimeMillis()

                if (modeIsClap) {
                    // Contar cuántas muestras superan el 40% del pico para evaluar ancho del impulso
                    val threshold = maxAmp * 0.40
                    var highPeakCount = 0
                    for (i in 0 until readCount) {
                        val s = abs(shortBuffer[i].toInt() - mean)
                        if (s >= threshold) highPeakCount++
                    }

                    processClapDetection(now, maxAmp, rms, zeroCrossings, highPeakCount, readCount, selectedRate)
                } else {
                    processWhistleDetection(shortBuffer, readCount, selectedRate, rms, mean)
                }
            }
        }
    }

    /**
     * Detección de 2 Palmadas inteligente y resistente a la voz:
     * - Una palmada es un pulso mecánico súbito de muy corta duración (<15ms) con crest factor muy alto (>3.5).
     * - La voz humana ("hey móvil", risas, conversación) tiene forma de onda armónica sostenida en el tiempo
     *   (crest factor típicamente <2.8) y mantiene energía RMS en los cuadros subsiguientes.
     */
    private fun processClapDetection(
        now: Long,
        maxAmp: Int,
        rms: Double,
        zeroCrossings: Int,
        highPeakCount: Int,
        readCount: Int,
        sampleRate: Int
    ) {
        // Enfriamiento tras disparar una detección
        if (now - lastClapTriggerTimeMs < 2500L) {
            lastClapTimeMs = 0L
            clapCandidateTimeMs = 0L
            waitingForClapDecay = false
            return
        }

        val crestFactor = if (rms > 0.0) maxAmp / rms else 0.0

        // 1. Verificación de decaimiento del cuadro posterior al impacto candidato
        if (waitingForClapDecay) {
            // En una palmada real, tras el golpe transitorio el nivel de audio se desploma inmediatamente
            val decayedFast = rms < candidateClapRms * 0.40 && maxAmp < candidateClapAmp * 0.40
            val reachedQuiet = rms < 850.0

            if (decayedFast || reachedQuiet) {
                // Confirmado como pulso impulsivo real (no es voz ni sonido continuo)
                val timeSinceFirstClap = clapCandidateTimeMs - lastClapTimeMs

                if (lastClapTimeMs > 0L && timeSinceFirstClap in 200..1150) {
                    // ¡Segunda palmada en la ventana de ritmo natural (200ms - 1.15s)!
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    continuousSpeechCounter = 0
                    lastClapTriggerTimeMs = now
                    onTriggerDetected("¡2 Palmadas detectadas!")
                    return
                } else {
                    // Primera palmada registrada
                    lastClapTimeMs = clapCandidateTimeMs
                    continuousSpeechCounter = 0
                }
            } else {
                // Si el sonido continuó sonando en el siguiente bloque, fue voz sostenida ("hey...", sílabas, etc.)
                // Descartamos el candidato
            }
            waitingForClapDecay = false
            clapCandidateTimeMs = 0L
        }

        // 2. Control de silencio entre palmadas y expiración
        if (lastClapTimeMs > 0L) {
            // Si pasó más de 1.15 segundos sin la segunda palmada, reiniciar
            if (now - lastClapTimeMs > 1150L) {
                lastClapTimeMs = 0L
                continuousSpeechCounter = 0
            } else {
                // Si durante el intervalo de espera entre palmadas hay voz o ruido sostenido continuo,
                // invalidamos la primera palmada (no fue un patrón silencioso de aplausos, sino conversación)
                if (rms > 1200.0) {
                    continuousSpeechCounter++
                    if (continuousSpeechCounter >= 3) {
                        lastClapTimeMs = 0L
                        continuousSpeechCounter = 0
                    }
                }
            }
        }

        // 3. Criterios de discriminación para un nuevo impacto de palmada:
        // - maxAmp >= 7000: Umbral firme para no activarse con habla normal ("hey móvil" a distancia normal ronda 2000-5000).
        // - crestFactor >= 3.6: Impulso concentrado en pocas muestras respecto al RMS promedio del bloque.
        // - highPeakCount acotado: Un choque mecánico real dura muy pocos milisegundos (<45 muestras a 16kHz).
        // - zeroCrossings adecuado: Banda ancha transitoria.
        val maxAllowedHighPeakSamples = (readCount * 0.05).toInt().coerceAtLeast(18)
        val minZeroCrossings = (18.0 * readCount / 1024.0).toInt()

        val isTransientImpulse = maxAmp >= 7000 &&
                rms >= 500.0 &&
                crestFactor >= 3.6 &&
                highPeakCount <= maxAllowedHighPeakSamples &&
                zeroCrossings >= minZeroCrossings

        if (isTransientImpulse) {
            clapCandidateTimeMs = now
            candidateClapAmp = maxAmp
            candidateClapRms = rms
            waitingForClapDecay = true
        }
    }

    /**
     * Detección de Silbidos por Autocorrelación Normalizada:
     * - El silbido humano es una oscilación sinusoidal pura en la banda de 950 Hz a 2800 Hz.
     * - Se aplica un filtro paso alto IIR para eliminar el soplo de aire/viento contra el micrófono
     *   y los ruidos mecánicos graves (< 800 Hz).
     * - La autocorrelación normalizada r(tau) mide la pureza periódica exacta sin depender de bins
     *   fijos, detectando instantáneamente cualquier silbido continuo con cero falsos positivos de voz.
     */
    private fun processWhistleDetection(
        buffer: ShortArray,
        length: Int,
        sampleRate: Int,
        rawRms: Double,
        mean: Double
    ) {
        val now = System.currentTimeMillis()
        if (now - lastWhistleTriggerTimeMs < 2500L) {
            whistleConfidence = 0
            return
        }

        // 1. Filtrado paso alto de primer orden (~800 Hz) para aislar la banda del silbido
        // y suprimir el soplido de aire contra el micrófono y armónicos graves de la voz
        val filtered = DoubleArray(length)
        var prevX = 0.0
        var prevY = 0.0
        val alpha = 0.90
        var filteredSumSquares = 0.0

        for (i in 0 until length) {
            val x = buffer[i].toInt() - mean
            val y = alpha * (prevY + x - prevX)
            filtered[i] = y
            filteredSumSquares += y * y
            prevX = x
            prevY = y
        }

        val filteredRms = sqrt(filteredSumSquares / length)
        // Umbral de volumen mínimo en la banda de silbido
        if (filteredRms < 220.0) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        // 2. Rango de retardos tau para silbido humano (950 Hz a 2800 Hz)
        val minTau = max(2, (sampleRate / 2850.0).toInt())
        val maxTau = (sampleRate / 950.0).toInt()

        if (maxTau >= length - 50) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        val windowSize = length - maxTau
        var baseEnergy = 0.0
        for (i in 0 until windowSize) {
            baseEnergy += filtered[i] * filtered[i]
        }

        if (baseEnergy <= 1e-4) {
            whistleConfidence = max(0, whistleConfidence - 1)
            return
        }

        var maxCorrelation = -1.0
        var bestTau = minTau

        for (tau in minTau..maxTau) {
            var dotProduct = 0.0
            var delayedEnergy = 0.0
            for (i in 0 until windowSize) {
                val f1 = filtered[i]
                val f2 = filtered[i + tau]
                dotProduct += f1 * f2
                delayedEnergy += f2 * f2
            }

            val denom = sqrt(baseEnergy * delayedEnergy)
            val normCorr = if (denom > 1e-4) dotProduct / denom else 0.0

            if (normCorr > maxCorrelation) {
                maxCorrelation = normCorr
                bestTau = tau
            }
        }

        val estimatedFreq = sampleRate.toDouble() / bestTau

        // 3. Verificación de pureza sinusoidal:
        // Un silbido limpio tiene una correlación normalizada superior a 0.65
        val isWhistleTone = maxCorrelation >= 0.65 && estimatedFreq in 950.0..2800.0

        if (isWhistleTone) {
            // Sumamos confianza rápidamente (2 puntos por cada frame tonal confirmado)
            whistleConfidence = min(6, whistleConfidence + 2)
            if (whistleConfidence >= 4) {
                // Silbido sostenido durante ~150-200ms confirmado
                whistleConfidence = 0
                lastWhistleTriggerTimeMs = now
                onTriggerDetected("¡Silbido detectado!")
            }
        } else {
            // Decaimiento suave para tolerar pequeñas fluctuaciones del aire al silbar
            whistleConfidence = max(0, whistleConfidence - 1)
        }
    }

    fun stopListening() {
        isAudioRunning = false
        val job = listeningJob
        listeningJob = null
        val record = audioRecord
        audioRecord = null

        job?.cancel()
        try {
            if (record != null) {
                if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                }
                record.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Excepción segura ignorada al detener/liberar AudioRecord: ${e.message}")
        }
    }
}


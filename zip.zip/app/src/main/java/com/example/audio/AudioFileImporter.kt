package com.example.audio

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import java.io.File
import java.io.FileOutputStream

/**
 * Utilidad para importar y validar archivos de audio subidos por el usuario desde el almacenamiento del dispositivo.
 */
object AudioFileImporter {
    private const val TAG = "AudioFileImporter"

    data class ImportedAudioResult(
        val filePath: String,
        val durationSeconds: Int,
        val originalFileName: String
    )

    sealed class ImportStatus {
        data class Success(val result: ImportedAudioResult) : ImportStatus()
        data class ErrorExceedsDuration(val durationSeconds: Int, val maxAllowedSeconds: Int) : ImportStatus()
        data class Error(val message: String) : ImportStatus()
    }

    /**
     * Procesa un URI de audio seleccionado por el usuario, lo copia a la carpeta privada de la app
     * y comprueba su duración contra el límite permitido (25s o 60s si es Premium).
     */
    fun importAudioFromUri(
        context: Context,
        uri: Uri,
        maxAllowedSeconds: Int
    ): ImportStatus {
        val contentResolver = context.contentResolver

        // 1. Obtener nombre original del archivo
        var displayName = "audio_importado"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) {
                            displayName = name.substringBeforeLast(".")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo extraer el nombre original", e)
        }

        // 2. Copiar el archivo a un archivo temporal privado para medir duración y reproducirlo
        val soundsDir = File(context.filesDir, "custom_sounds")
        if (!soundsDir.exists()) {
            soundsDir.mkdirs()
        }

        val destinationFile = File(soundsDir, "imported_${System.currentTimeMillis()}.m4a")

        try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return ImportStatus.Error("No se pudo leer el archivo de audio seleccionado")
        } catch (e: Exception) {
            Log.e(TAG, "Error al copiar archivo de audio", e)
            return ImportStatus.Error("Error al importar el archivo: ${e.localizedMessage}")
        }

        // 3. Medir duración real con MediaMetadataRetriever
        val retriever = MediaMetadataRetriever()
        var durationSeconds = 1
        try {
            retriever.setDataSource(destinationFile.absolutePath)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 0L
            durationSeconds = ((durationMs + 999) / 1000).toInt().coerceAtLeast(1)
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo extraer duración con MediaMetadataRetriever, intentando continuar", e)
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        // 4. Validar límite máximo de duración (con margen de tolerancia de 1 segundo para redondear)
        if (durationSeconds > maxAllowedSeconds + 1) {
            // Eliminar archivo temporal ya que excede el tiempo
            if (destinationFile.exists()) {
                destinationFile.delete()
            }
            return ImportStatus.ErrorExceedsDuration(
                durationSeconds = durationSeconds,
                maxAllowedSeconds = maxAllowedSeconds
            )
        }

        return ImportStatus.Success(
            ImportedAudioResult(
                filePath = destinationFile.absolutePath,
                durationSeconds = durationSeconds.coerceAtMost(maxAllowedSeconds),
                originalFileName = displayName
            )
        )
    }

    /**
     * Elimina de forma segura un archivo de audio temporal o descartado.
     */
    fun cleanUpFile(filePath: String?) {
        if (filePath.isNullOrBlank()) return
        try {
            val file = File(filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error cleaning up temporary audio file: $filePath", e)
        }
    }
}

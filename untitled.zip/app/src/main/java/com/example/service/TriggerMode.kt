package com.example.service

enum class TriggerMode(val id: String, val title: String, val description: String) {
    VOICE_HEY_MOVIL("voice", "Modo voz", "Di \"Hey Móvil\" o tu palabra elegida"),
    CLAP_TWICE("clap_twice", "2 Palmadas", "Da dos palmadas fuertes seguidas"),
    WHISTLE("whistle", "Silbido", "Emite un silbido agudo y constante");

    companion object {
        // Compatibilidad semántica completa
        val VOICE_MODE get() = VOICE_HEY_MOVIL

        fun fromId(id: String): TriggerMode = values().find {
            it.id == id || (it == VOICE_HEY_MOVIL && (id == "hey_movil" || id == "voice"))
        } ?: VOICE_HEY_MOVIL
    }
}

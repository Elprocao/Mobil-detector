package com.example.hardware

import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class VibrationIntensity(val id: Int, val label: String) {
    LOW(0, "Baja"),
    MEDIUM(1, "Media"),
    HIGH(2, "Alta");

    companion object {
        fun fromId(id: Int): VibrationIntensity = values().find { it.id == id } ?: MEDIUM
    }
}

class AlertEffectController(private val context: Context) {
    private val TAG = "AlertEffectController"
    private val scope = CoroutineScope(Dispatchers.Default)
    private var flashJob: Job? = null
    private var vibrationJob: Job? = null
    private var cameraManager: CameraManager? = null
    private var cameraIdWithFlash: String? = null

    init {
        try {
            cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            cameraManager?.let { manager ->
                for (id in manager.cameraIdList) {
                    val characteristics = manager.getCameraCharacteristics(id)
                    val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                    if (hasFlash) {
                        cameraIdWithFlash = id
                        break
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "No camera with flash available", e)
        }
    }

    /**
     * Activa el parpadeo estroboscópico de la linterna y la vibración según la intensidad configurada.
     */
    fun startEffects(intensity: VibrationIntensity = VibrationIntensity.MEDIUM) {
        startStrobeFlashlight()
        startVibration(intensity)
    }

    /**
     * Detiene la linterna y la vibración, apagando la linterna con seguridad.
     */
    fun stopEffects() {
        stopFlashlight()
        stopVibration()
    }

    private fun startStrobeFlashlight() {
        stopFlashlight()
        val manager = cameraManager
        val camId = cameraIdWithFlash
        if (manager == null || camId == null) {
            Log.d(TAG, "Flashlight hardware not available on this device")
            return
        }

        flashJob = scope.launch {
            try {
                var state = false
                while (isActive) {
                    state = !state
                    try {
                        manager.setTorchMode(camId, state)
                    } catch (e: CameraAccessException) {
                        Log.w(TAG, "CameraAccessException toggling flash", e)
                        break
                    } catch (e: Exception) {
                        Log.w(TAG, "Error toggling flash", e)
                        break
                    }
                    // Flash estroboscópico rápido: 140ms encendido, 110ms apagado
                    delay(if (state) 140L else 110L)
                }
            } finally {
                try {
                    manager.setTorchMode(camId, false)
                } catch (_: Exception) {}
            }
        }
    }

    private fun stopFlashlight() {
        flashJob?.cancel()
        flashJob = null
        try {
            val camId = cameraIdWithFlash
            if (camId != null && cameraManager != null) {
                cameraManager?.setTorchMode(camId, false)
            }
        } catch (_: Exception) {}
    }

    private fun startVibration(intensity: VibrationIntensity) {
        stopVibration()
        vibrationJob = scope.launch {
            try {
                while (isActive) {
                    when (intensity) {
                        VibrationIntensity.LOW -> {
                            // Patrón Suave: pulsos cortos y discretos (tipo latido sutil)
                            triggerSingleVibrate(100L, 70)
                            delay(160L)
                            triggerSingleVibrate(100L, 70)
                            delay(650L)
                        }
                        VibrationIntensity.MEDIUM -> {
                            // Patrón Rítmico Medio: doble toque energético (cadencia estándar de notificación)
                            triggerSingleVibrate(220L, 175)
                            delay(120L)
                            triggerSingleVibrate(220L, 175)
                            delay(400L)
                        }
                        VibrationIntensity.HIGH -> {
                            // Patrón Fuerte y Continuo: ráfagas prolongadas a máxima potencia (para encontrarlo rápido)
                            triggerSingleVibrate(650L, 255)
                            delay(120L)
                            triggerSingleVibrate(650L, 255)
                            delay(200L)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error in continuous vibration", e)
            }
        }
    }

    private fun triggerSingleVibrate(durationMs: Long, amplitude: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vibrator = vibratorManager?.defaultVibrator
                if (vibrator?.hasVibrator() == true) {
                    if (vibrator.hasAmplitudeControl()) {
                        vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
                    } else {
                        vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vibrator?.hasVibrator() == true) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (vibrator.hasAmplitudeControl()) {
                            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
                        } else {
                            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(durationMs)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Single vibrate call failed", e)
        }
    }

    private fun stopVibration() {
        vibrationJob?.cancel()
        vibrationJob = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.cancel()
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.cancel()
            }
        } catch (_: Exception) {}
    }
}

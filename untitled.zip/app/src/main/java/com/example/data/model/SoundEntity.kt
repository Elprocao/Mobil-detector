package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SoundType {
    DEFAULT_BEEPS,
    DEFAULT_FUNNY_VOICE,
    CUSTOM_RECORDING
}

@Entity(tableName = "sounds")
data class SoundEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: SoundType,
    val filePath: String? = null,
    val durationSeconds: Int = 2,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

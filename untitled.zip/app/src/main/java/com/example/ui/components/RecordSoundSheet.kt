package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioFileImporter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordSoundSheet(
    sheetState: SheetState,
    isRecording: Boolean,
    recordingSeconds: Float,
    recordingAmplitude: Float,
    recordedTempPath: String?,
    isPreviewPlaying: Boolean,
    maxDurationSeconds: Int,
    isPremiumUser: Boolean,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayPreview: () -> Unit,
    onPlayTrimmedPreview: (filePath: String, startSec: Float, endSec: Float) -> Unit,
    onStopPreview: () -> Unit,
    onCancel: () -> Unit,
    onSaveSound: (name: String) -> Unit,
    onSaveTrimmedSound: (name: String, filePath: String, startSec: Float, endSec: Float) -> Unit,
    onSaveImportedSound: (name: String, filePath: String, durationSeconds: Int) -> Unit,
    onSaveTrimmedImportedSound: (name: String, filePath: String, startSec: Float, endSec: Float, totalDuration: Float) -> Unit,
    onOpenPremiumDialog: () -> Unit,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Grabar con micro, 1: Subir archivo
    var soundName by remember { mutableStateOf("") }

    // Trimming range states
    var recordedStartTrim by remember { mutableStateOf(0f) }
    var recordedEndTrim by remember { mutableStateOf(0f) }

    var importedStartTrim by remember { mutableStateOf(0f) }
    var importedEndTrim by remember { mutableStateOf(0f) }

    // Estado para el archivo importado
    var importedResult by remember { mutableStateOf<AudioFileImporter.ImportedAudioResult?>(null) }
    var importErrorMessage by remember { mutableStateOf<String?>(null) }

    val progress = (recordingSeconds / maxDurationSeconds.toFloat()).coerceIn(0f, 1f)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Launcher de permiso de micrófono
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onStartRecording()
        }
    }

    // Selector de archivos de audio desde el almacenamiento
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            importErrorMessage = null
            when (val result = AudioFileImporter.importAudioFromUri(context, uri, maxDurationSeconds)) {
                is AudioFileImporter.ImportStatus.Success -> {
                    importedResult = result.result
                    soundName = result.result.originalFileName
                    importErrorMessage = null
                }
                is AudioFileImporter.ImportStatus.ErrorExceedsDuration -> {
                    importedResult = null
                    importErrorMessage = "El audio dura ${result.durationSeconds}s (máximo permitido: ${result.maxAllowedSeconds}s)."
                }
                is AudioFileImporter.ImportStatus.Error -> {
                    importedResult = null
                    importErrorMessage = result.message
                }
            }
        }
    }

    // Manejador seguro de cierre con limpieza de archivos temporales
    val handleDismissWithCleanup: () -> Unit = {
        AudioFileImporter.cleanUpFile(importedResult?.filePath)
        importedResult = null
        onDismissRequest()
    }

    val handleCancelWithCleanup: () -> Unit = {
        AudioFileImporter.cleanUpFile(importedResult?.filePath)
        importedResult = null
        onCancel()
    }

    ModalBottomSheet(
        onDismissRequest = handleDismissWithCleanup,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Añadir sonido personalizado",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Badge indicador del límite de tiempo (25s o 60s con Premium)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isPremiumUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isPremiumUser) {
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = "Premium",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Máximo Premium: 60 segundos",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    } else {
                        Text(
                            text = "Máximo: 25 segundos",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            onClick = onOpenPremiumDialog,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Ampliar a 60s",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Pestañas: Grabar con Micro / Subir Archivo
            if (!isRecording && recordedTempPath == null && importedResult == null) {
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .padding(bottom = 20.dp)
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Grabar")
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Subir audio")
                            }
                        }
                    )
                }
            }

            // CONTENIDO PESTAÑA 0: GRABAR
            if (selectedTabIndex == 0 && importedResult == null) {
                // Circular progress & Mic indicator
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(160.dp)
                        .padding(8.dp)
                ) {
                    // Background Track
                    CircularProgressIndicator(
                        progress = { 1f },
                        modifier = Modifier.size(150.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        strokeWidth = 8.dp,
                    )

                    // Active Progress
                    CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.size(150.dp),
                        color = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        strokeWidth = 8.dp,
                    )

                    // Central Icon / Pulse
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(100.dp)
                            .scale(if (isRecording) pulseScale else 1f)
                            .clip(CircleShape)
                            .background(
                                if (isRecording) {
                                    MaterialTheme.colorScheme.errorContainer
                                } else if (recordedTempPath != null) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Mic else if (recordedTempPath != null) Icons.Default.PlayArrow else Icons.Default.Mic,
                            contentDescription = "Estado de grabación",
                            modifier = Modifier.size(42.dp),
                            tint = if (isRecording) {
                                MaterialTheme.colorScheme.error
                            } else if (recordedTempPath != null) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }

                // Elapsed time indicator
                val elapsedInt = recordingSeconds.toInt()
                Text(
                    text = String.format(
                        Locale.US,
                        "%02d:%02d / 00:%02d",
                        elapsedInt / 60,
                        elapsedInt % 60,
                        maxDurationSeconds
                    ),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                )

                // Audio wave bars preview when recording
                if (isRecording) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(32.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(12) { index ->
                            val barFactor = ((recordingAmplitude * 30 + (index % 4) * 6).coerceIn(4f, 32f)).dp
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(barFactor)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(MaterialTheme.colorScheme.error)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Action buttons according to state
                if (isRecording) {
                    Button(
                        onClick = onStopRecording,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("stop_recording_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Detener grabación")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Detener grabación", style = MaterialTheme.typography.titleMedium)
                    }
                } else if (recordedTempPath != null) {
                    // Recording finished: Preview & Save
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = onPlayPreview,
                                modifier = Modifier.testTag("play_recorded_preview_button")
                            ) {
                                Icon(
                                    imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Escuchar prueba"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isPreviewPlaying) "Pausar" else "Escuchar prueba")
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            TextButton(
                                onClick = onStartRecording,
                                modifier = Modifier.testTag("re_record_button")
                            ) {
                                Text("Grabar otra vez")
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Trim / Recorte de audio para eliminar silencios de inicio y fin
                        AudioTrimEditor(
                            totalDurationSeconds = recordingSeconds.coerceAtLeast(1f),
                            isPlaying = isPreviewPlaying,
                            onPlayTrimmedPreview = { startSec, endSec ->
                                recordedStartTrim = startSec
                                recordedEndTrim = endSec
                                onPlayTrimmedPreview(recordedTempPath, startSec, endSec)
                            },
                            onStopPreview = onStopPreview,
                            onTrimSelected = { startSec, endSec ->
                                recordedStartTrim = startSec
                                recordedEndTrim = endSec
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = soundName,
                            onValueChange = { soundName = it },
                            label = { Text("Nombre del sonido") },
                            placeholder = { Text("Ej. Mi silbido, Alarma fuerte...") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sound_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = handleCancelWithCleanup,
                                modifier = Modifier.testTag("cancel_record_button")
                            ) {
                                Text("Descartar")
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Button(
                                onClick = {
                                    val finalName = if (soundName.isNotBlank()) soundName else "Sonido grabado"
                                    val endSec = if (recordedEndTrim > 0.1f) recordedEndTrim else recordingSeconds
                                    onSaveTrimmedSound(finalName, recordedTempPath, recordedStartTrim, endSec)
                                },
                                modifier = Modifier.testTag("save_custom_sound_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Guardar sonido")
                            }
                        }
                    }
                } else {
                    // Not recording yet: Start button
                    Button(
                        onClick = {
                            val micGranted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (micGranted) {
                                onStartRecording()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("start_recording_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Comenzar grabación")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Iniciar grabación", style = MaterialTheme.typography.titleMedium)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = handleCancelWithCleanup,
                        modifier = Modifier.testTag("close_sheet_button")
                    ) {
                        Text("Cancelar")
                    }
                }
            }

            // CONTENIDO PESTAÑA 1: SUBIR AUDIO
            if (selectedTabIndex == 1 || importedResult != null) {
                if (importedResult == null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Elige un archivo de audio",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Formatos MP3, M4A, WAV, OGG (máx. ${maxDurationSeconds}s)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        if (importErrorMessage != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.errorContainer
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = importErrorMessage ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        textAlign = TextAlign.Center
                                    )
                                    if (!isPremiumUser && importErrorMessage?.contains("máximo") == true) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = onOpenPremiumDialog,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.error
                                            ),
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Ampliar a 60s con Premium")
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                audioPickerLauncher.launch("audio/*")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("select_audio_file_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Seleccionar archivo de audio", style = MaterialTheme.typography.titleMedium)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = onCancel,
                            modifier = Modifier.testTag("cancel_upload_button")
                        ) {
                            Text("Cancelar")
                        }
                    }
                } else {
                    // Audio subido y listo para nombrar y guardar
                    val audio = importedResult!!
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = audio.originalFileName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "Duración: ${audio.durationSeconds} segundos",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Trim / Recorte de audio para eliminar silencios del audio subido
                        AudioTrimEditor(
                            totalDurationSeconds = audio.durationSeconds.toFloat(),
                            isPlaying = isPreviewPlaying,
                            onPlayTrimmedPreview = { startSec, endSec ->
                                importedStartTrim = startSec
                                importedEndTrim = endSec
                                onPlayTrimmedPreview(audio.filePath, startSec, endSec)
                            },
                            onStopPreview = onStopPreview,
                            onTrimSelected = { startSec, endSec ->
                                importedStartTrim = startSec
                                importedEndTrim = endSec
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = soundName,
                            onValueChange = { soundName = it },
                            label = { Text("Nombre para la app") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("imported_sound_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    AudioFileImporter.cleanUpFile(importedResult?.filePath)
                                    importedResult = null
                                    importErrorMessage = null
                                },
                                modifier = Modifier.testTag("choose_another_audio_button")
                            ) {
                                Text("Elegir otro")
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Button(
                                onClick = {
                                    val finalName = if (soundName.isNotBlank()) soundName else audio.originalFileName
                                    val endSec = if (importedEndTrim > 0.1f) importedEndTrim else audio.durationSeconds.toFloat()
                                    onSaveTrimmedImportedSound(
                                        finalName,
                                        audio.filePath,
                                        importedStartTrim,
                                        endSec,
                                        audio.durationSeconds.toFloat()
                                    )
                                },
                                modifier = Modifier.testTag("save_imported_sound_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Guardar sonido")
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme - Calidez, elegancia y contraste premium (por defecto)
val PrimaryLight = Color(0xFF2563EB)          // Vibrant Indigo / Royal Blue
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE) // Soft blue tint
val OnPrimaryContainerLight = Color(0xFF1E40AF)

val SecondaryLight = Color(0xFF0D9488)        // Radiant Emerald / Teal
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCFBF1)
val OnSecondaryContainerLight = Color(0xFF115E59)

val TertiaryLight = Color(0xFFF59E0B)         // Warm Amber
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFEF3C7)
val OnTertiaryContainerLight = Color(0xFF92400E)

val BackgroundLight = Color(0xFFF8FAFC)       // Crisp soft slate
val SurfaceLight = Color(0xFFFFFFFF)          // Pure white card surfaces
val SurfaceVariantLight = Color(0xFFF1F5F9)   // Subtle surface container
val OnSurfaceLight = Color(0xFF0F172A)        // Deep slate high-contrast text
val OnSurfaceVariantLight = Color(0xFF475569) // Neutral text
val OutlineLight = Color(0xFFCBD5E1)
val OutlineVariantLight = Color(0xFFE2E8F0)

// Dark Scheme - Profundo, inmersivo, OLED Friendly con acentos luminosos
val PrimaryDark = Color(0xFF60A5FA)           // Luminous Sky Blue
val OnPrimaryDark = Color(0xFF082F49)
val PrimaryContainerDark = Color(0xFF1E3A8A)
val OnPrimaryContainerDark = Color(0xFFBFDBFE)

val SecondaryDark = Color(0xFF2DD4BF)         // Neon Mint
val OnSecondaryDark = Color(0xFF042F2E)
val SecondaryContainerDark = Color(0xFF134E4A)
val OnSecondaryContainerDark = Color(0xFFCCFBF1)

val TertiaryDark = Color(0xFFFBBF24)          // Luminous Amber
val OnTertiaryDark = Color(0xFF451A03)
val TertiaryContainerDark = Color(0xFF78350F)
val OnTertiaryContainerDark = Color(0xFFFDE68A)

val BackgroundDark = Color(0xFF090D16)        // Midnight Obsidian
val SurfaceDark = Color(0xFF111827)           // Rich Dark Card Surface
val SurfaceVariantDark = Color(0xFF1F2937)    // Elevated Surface
val OnSurfaceDark = Color(0xFFF9FAFB)         // Bright crisp text
val OnSurfaceVariantDark = Color(0xFF9CA3AF)  // Medium emphasis text
val OutlineDark = Color(0xFF374151)
val OutlineVariantDark = Color(0xFF1F2937)

package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Detector de sonido en tiempo real:
 * - 2 Palmadas: Detección precisa de pulsos de impacto con alto factor de cresta y caída rápida (filtra voz y tos).
 * - Silbidos: Detección espectral con pureza tonal y rechazo de bajas frecuencias (filtra tos, voz y ruidos).
 */
class AcousticTriggerDetector(
    private val context: Context,
    private val onTriggerDetected: (reason: String) -> Unit,
    private val onRmsUpdated: ((Float) -> Unit)? = null,
    private val isMotionSuppressed: (() -> Boolean)? = null
) {
    private val TAG = "AcousticTriggerDetector"
    private val scope = CoroutineScope(Dispatchers.Default)
    private var listeningJob: Job? = null
    private var audioRecord: AudioRecord? = null

    // Estados para 2 palmadas
    private var lastClapTimeMs = 0L
    private var clapCandidateTimeMs = 0L
    private var waitingForClapDecay = false
    private var candidateClapAmp = 0
    private var candidateClapRms = 0.0

    // Estados para silbidos (detección espectral continua)
    private var consecutiveWhistleFrames = 0

    @SuppressLint("MissingPermission")
    fun startListening(modeIsClap: Boolean) {
        stopListening()

        val sampleRates = intArrayOf(16000, 44100, 22050)
        var selectedRate = 16000
        var record: AudioRecord? = null

        for (rate in sampleRates) {
            val minBuf = AudioRecord.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf > 0) {
                try {
                    val candidate = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        rate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        max(minBuf, 4096)
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        record = candidate
                        selectedRate = rate
                        break
                    } else {
                        candidate.release()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Sample rate $rate not supported: ${e.message}")
                }
            }
        }

        if (record == null) {
            Log.e(TAG, "No suitable AudioRecord found")
            return
        }

        try {
            record.startRecording()
            audioRecord = record
        } catch (e: Exception) {
            Log.e(TAG, "Error starting AudioRecord", e)
            record.release()
            return
        }

        lastClapTimeMs = 0L
        clapCandidateTimeMs = 0L
        waitingForClapDecay = false
        consecutiveWhistleFrames = 0

        listeningJob = scope.launch {
            val shortBuffer = ShortArray(1024)
            while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val readCount = audioRecord?.read(shortBuffer, 0, shortBuffer.size) ?: -1
                if (readCount <= 0) continue

                // Si el usuario tiene el móvil en la mano o se está moviendo activamente, suprimir detección
                if (isMotionSuppressed?.invoke() == true) {
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    consecutiveWhistleFrames = 0
                    continue
                }

                // Métricas acústicas: RMS, Amplitud máxima, Cruces por cero
                var sumSquare = 0.0
                var maxAmp = 0
                var zeroCrossings = 0
                for (i in 0 until readCount) {
                    val sample = shortBuffer[i].toInt()
                    sumSquare += sample * sample
                    val absSample = abs(sample)
                    if (absSample > maxAmp) maxAmp = absSample
                    if (i > 0 && ((shortBuffer[i] >= 0 && shortBuffer[i - 1] < 0) || (shortBuffer[i] < 0 && shortBuffer[i - 1] >= 0))) {
                        zeroCrossings++
                    }
                }
                val rms = sqrt(sumSquare / readCount)
                val rmsDb = (20 * kotlin.math.log10(rms.coerceAtLeast(1.0))).toFloat()
                onRmsUpdated?.invoke(rmsDb)

                val now = System.currentTimeMillis()

                if (modeIsClap) {
                    processClapDetection(now, maxAmp, rms, zeroCrossings)
                } else {
                    processWhistleDetection(shortBuffer, readCount, selectedRate, rms, sumSquare, zeroCrossings)
                }
            }
        }
    }

    /**
     * Detección de 2 Palmadas inteligente:
     * Una palmada real es un pulso transitorio de alta energía y ataque abrupto (crest factor alto)
     * seguido de una caída rápida a silencio.
     * La voz humana, tos o ruido continuo NO tienen decaimiento inmediato ni el factor de cresta de una palmada.
     */
    private fun processClapDetection(now: Long, maxAmp: Int, rms: Double, zeroCrossings: Int) {
        val crestFactor = if (rms > 0.0) maxAmp / rms else 0.0

        if (waitingForClapDecay) {
            // Comprobamos si el cuadro posterior a la palmada candidata decae inmediatamente
            val decayed = rms < candidateClapRms * 0.70 || rms < 1100
            val isTransient = decayed && maxAmp < candidateClapAmp * 0.80

            if (isTransient) {
                // Confirmada palmada acústica válida (pulso transitorio real)
                val timeSinceFirstClap = clapCandidateTimeMs - lastClapTimeMs

                if (lastClapTimeMs > 0L && timeSinceFirstClap in 150..1300) {
                    // ¡Segunda palmada en la ventana de ritmo natural (150ms - 1.3s)!
                    lastClapTimeMs = 0L
                    clapCandidateTimeMs = 0L
                    waitingForClapDecay = false
                    onTriggerDetected("¡2 Palmadas detectadas!")
                    return
                } else {
                    // Primera palmada registrada
                    lastClapTimeMs = clapCandidateTimeMs
                }
            }
            waitingForClapDecay = false
            clapCandidateTimeMs = 0L
        }

        // Si pasó más de 1.3 segundos sin una segunda palmada, reiniciar el contador
        if (lastClapTimeMs > 0L && now - lastClapTimeMs > 1300) {
            lastClapTimeMs = 0L
        }

        // Criterios para una palmada genuina con calibración realista
        val isPotentialClap = maxAmp >= 2800 && rms >= 350 && crestFactor >= 2.2 && zeroCrossings >= 18

        if (isPotentialClap) {
            clapCandidateTimeMs = now
            candidateClapAmp = maxAmp
            candidateClapRms = rms
            waitingForClapDecay = true
        }
    }

    /**
     * Detección de Silbido con Pureza Tonal y Rechazo de Tos / Voz:
     * Un silbido es una oscilación sinusoidal pura en frecuencias de 1000 Hz a 2900 Hz.
     * La tos y la voz tienen energía distribuida en banda ancha y son dominantemente graves (< 800 Hz).
     */
    private fun processWhistleDetection(
        buffer: ShortArray,
        length: Int,
        sampleRate: Int,
        rms: Double,
        totalEnergy: Double,
        zeroCrossings: Int
    ) {
        // Umbral mínimo de volumen para considerar un silbido
        if (rms < 300 || totalEnergy <= 0.0) {
            consecutiveWhistleFrames = max(0, consecutiveWhistleFrames - 1)
            return
        }

        // Verificación de cruce por cero según la tasa de muestreo activa
        val minExpectedZc = (700.0 * length / sampleRate).toInt()
        val maxExpectedZc = (3400.0 * length / sampleRate).toInt()
        if (zeroCrossings !in minExpectedZc..maxExpectedZc) {
            consecutiveWhistleFrames = max(0, consecutiveWhistleFrames - 1)
            return
        }

        // Frecuencias de silbido típicas (paso de 100 Hz para cubrir exhaustivamente 1000 Hz - 2800 Hz)
        val whistleFreqs = doubleArrayOf(
            1000.0, 1100.0, 1200.0, 1300.0, 1400.0, 1500.0, 1600.0,
            1700.0, 1800.0, 1900.0, 2000.0, 2100.0, 2200.0, 2300.0,
            2400.0, 2500.0, 2600.0, 2700.0, 2800.0
        )

        // Frecuencias graves (voz humana, tos, carraspeo, golpes en la mesa)
        val lowFreqs = doubleArrayOf(250.0, 400.0, 550.0, 700.0)

        var maxWhistleEnergy = 0.0
        for (freq in whistleFreqs) {
            val e = calculateGoertzelEnergy(buffer, length, freq, sampleRate)
            if (e > maxWhistleEnergy) {
                maxWhistleEnergy = e
            }
        }

        var maxLowEnergy = 0.0
        for (freq in lowFreqs) {
            val e = calculateGoertzelEnergy(buffer, length, freq, sampleRate)
            if (e > maxLowEnergy) {
                maxLowEnergy = e
            }
        }

        // Relación de pureza tonal: energía concentrada en la frecuencia de silbido
        val normalizedWhistleRatio = maxWhistleEnergy / (length.toDouble() * totalEnergy)
        val isPureWhistle = normalizedWhistleRatio > 0.12 && (maxLowEnergy < maxWhistleEnergy * 0.65)

        if (isPureWhistle) {
            consecutiveWhistleFrames++
            // Requiere 3 cuadros consecutivos (~120-150 ms) para confirmar
            if (consecutiveWhistleFrames >= 3) {
                consecutiveWhistleFrames = 0
                onTriggerDetected("¡Silbido detectado!")
            }
        } else {
            consecutiveWhistleFrames = max(0, consecutiveWhistleFrames - 1)
        }
    }

    /**
     * Algoritmo de Goertzel optimizado para evaluar la energía en una frecuencia específica.
     */
    private fun calculateGoertzelEnergy(
        buffer: ShortArray,
        length: Int,
        targetFreq: Double,
        sampleRate: Int
    ): Double {
        val k = (0.5 + (length * targetFreq / sampleRate)).toInt()
        val w = 2.0 * Math.PI * k / length
        val cosine = cos(w)
        val coeff = 2.0 * cosine

        var q0 = 0.0
        var q1 = 0.0
        var q2 = 0.0

        for (i in 0 until length) {
            q0 = coeff * q1 - q2 + buffer[i]
            q2 = q1
            q1 = q0
        }

        return q1 * q1 + q2 * q2 - q1 * q2 * coeff
    }

    fun stopListening() {
        listeningJob?.cancel()
        listeningJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }
}

package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.PI
import kotlin.math.sin

/**
 * Catálogo de sonidos preinstalados listos para descargar o guardar en los slots del usuario.
 * Genera archivos WAV de alta fidelidad con efectos sonoros reconocibles:
 * 1. Sirena de policía (Wail oscilante)
 * 2. Alarma nuclear (Tono grave y pulsante)
 * 3. Timbre de bicicleta (Doble "ring ring" metálico)
 * 4. Maullido fuerte (Sweep de frecuencia expresivo)
 */
object PresetSoundCatalog {
    private const val TAG = "PresetSoundCatalog"

    data class PresetItem(
        val id: String,
        val name: String,
        val description: String,
        val durationSeconds: Int,
        val iconType: String
    )

    val PRESET_ITEMS = listOf(
        PresetItem(
            id = "preset_police_siren",
            name = "Sirena de policía",
            description = "Sonido clásico oscilante de patrulla, estridente y fácil de oír",
            durationSeconds = 3,
            iconType = "siren"
        ),
        PresetItem(
            id = "preset_nuclear_alarm",
            name = "Alarma nuclear",
            description = "Tono grave y penetrante de emergencia industrial",
            durationSeconds = 3,
            iconType = "nuclear"
        ),
        PresetItem(
            id = "preset_bicycle_bell",
            name = "Timbre de bicicleta",
            description = "Doble campanilla metálica aguda y chispeante (Ring-Ring)",
            durationSeconds = 2,
            iconType = "bell"
        ),
        PresetItem(
            id = "preset_loud_meow",
            name = "Maullido fuerte",
            description = "Llamativo maullido felino modulado en frecuencia",
            durationSeconds = 2,
            iconType = "cat"
        )
    )

    /**
     * Genera y escribe el archivo de audio WAV en el directorio local si aún no existe.
     * Devuelve la ruta absoluta del archivo generado.
     */
    fun getOrGeneratePresetFile(context: Context, presetId: String): String? {
        return try {
            val dir = File(context.filesDir, "preset_sounds")
            if (!dir.exists()) dir.mkdirs()

            val targetFile = File(dir, "$presetId.wav")
            if (targetFile.exists() && targetFile.length() > 1000) {
                return targetFile.absolutePath
            }

            val sampleRate = 44100
            val pcmData = when (presetId) {
                "preset_police_siren" -> generatePoliceSirenSamples(sampleRate, durationSec = 3.0)
                "preset_nuclear_alarm" -> generateNuclearAlarmSamples(sampleRate, durationSec = 3.0)
                "preset_bicycle_bell" -> generateBicycleBellSamples(sampleRate)
                "preset_loud_meow" -> generateLoudMeowSamples(sampleRate)
                else -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
            }

            writeWavFile(targetFile, pcmData, sampleRate)
            targetFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error generating preset sound for $presetId", e)
            null
        }
    }

    /**
     * Genera el archivo WAV para el sonido de voz "Saludo" ("¡Hola! ¡Aquí estoy!"),
     * garantizando que funcione en cualquier dispositivo sin depender de si el motor
     * TTS del sistema está instalado o configurado en español.
     */
    fun getOrGenerateSaludoFile(context: Context): String? {
        return try {
            val dir = File(context.filesDir, "preset_sounds")
            if (!dir.exists()) dir.mkdirs()

            val targetFile = File(dir, "saludo_vocal.wav")
            if (targetFile.exists() && targetFile.length() > 5000) {
                return targetFile.absolutePath
            }

            val sampleRate = 44100
            val pcmData = generateSaludoVocalSamples(sampleRate)
            writeWavFile(targetFile, pcmData, sampleRate)
            targetFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error generating saludo vocal sound", e)
            null
        }
    }

    /**
     * Síntesis de voz acústica de alta fidelidad ("¡Hola! ¡Aquí estoy!") mediante
     * resonadores de formantes vocales (F1, F2, F3) y excitación glótica armónica,
     * precedida por un repique brillante de campanas de localización.
     */
    fun generateSaludoVocalSamples(sampleRate: Int): ShortArray {
        val durationSec = 2.6
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        // Campanas iniciales alegres ("Ding-Dong" de atención brillante)
        val chimeNotes = listOf(
            Triple(0.04, 0.22, 1046.50), // C6
            Triple(0.20, 0.28, 1318.51), // E6
            Triple(0.36, 0.35, 1567.98)  // G6
        )
        for ((start, dur, freq) in chimeNotes) {
            val startIdx = (start * sampleRate).toInt()
            val endIdx = ((start + dur) * sampleRate).toInt().coerceAtMost(totalSamples)
            for (i in startIdx until endIdx) {
                val t = (i - startIdx).toDouble() / sampleRate
                val env = Math.exp(-t * 9.0)
                val wave = sin(2.0 * PI * freq * t) + 0.3 * sin(2.0 * PI * (freq * 2) * t)
                val sampleVal = (wave * env * 0.40 * Short.MAX_VALUE).toInt()
                buffer[i] = (buffer[i] + sampleVal).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }

        // Síntesis de voz articulada ("¡HO-LA! ... ¡A-QUÍ ES-TOY!")
        data class Phoneme(
            val startSec: Double,
            val durSec: Double,
            val startF0: Double,
            val endF0: Double,
            val f1: Double,
            val f2: Double,
            val f3: Double,
            val noiseRatio: Double = 0.0
        )

        val phonemes = listOf(
            // "¡HO-" (inicio vocal cálido, pitch sube de 220Hz a 270Hz)
            Phoneme(0.55, 0.32, 220.0, 270.0, 480.0, 840.0, 2400.0, 0.05),
            // "-LA!" (acento descendente de 270Hz a 210Hz)
            Phoneme(0.88, 0.38, 270.0, 210.0, 800.0, 1250.0, 2600.0, 0.02),
            // Pausa breve
            // "¡A-" (inicio agudo 230Hz a 250Hz)
            Phoneme(1.35, 0.18, 230.0, 250.0, 800.0, 1250.0, 2600.0, 0.02),
            // "-QUÍ" (tono alto enfático 280Hz a 300Hz, formante F2 agudo)
            Phoneme(1.54, 0.28, 280.0, 290.0, 320.0, 2300.0, 3100.0, 0.04),
            // "-ES-" (fricativa suave con formante de transición)
            Phoneme(1.83, 0.18, 260.0, 240.0, 450.0, 1850.0, 2700.0, 0.15),
            // "-TOY!" (cierre rotundo de 250Hz a 180Hz)
            Phoneme(2.02, 0.44, 250.0, 180.0, 500.0, 920.0, 2500.0, 0.02)
        )

        val random = java.util.Random(42)
        for (ph in phonemes) {
            val startIdx = (ph.startSec * sampleRate).toInt()
            val numSamples = (ph.durSec * sampleRate).toInt()
            var phaseF0 = 0.0

            var y1Prev1 = 0.0
            var y1Prev2 = 0.0
            var y2Prev1 = 0.0
            var y2Prev2 = 0.0
            var y3Prev1 = 0.0
            var y3Prev2 = 0.0

            val r1 = Math.exp(-PI * 80.0 / sampleRate)
            val r2 = Math.exp(-PI * 100.0 / sampleRate)
            val r3 = Math.exp(-PI * 120.0 / sampleRate)

            val cos1 = Math.cos(2.0 * PI * ph.f1 / sampleRate)
            val cos2 = Math.cos(2.0 * PI * ph.f2 / sampleRate)
            val cos3 = Math.cos(2.0 * PI * ph.f3 / sampleRate)

            for (j in 0 until numSamples) {
                val idx = startIdx + j
                if (idx >= totalSamples) break

                val progress = j.toDouble() / numSamples
                val env = when {
                    progress < 0.12 -> progress / 0.12
                    progress > 0.80 -> (1.0 - progress) / 0.20
                    else -> 1.0
                }

                val currentF0 = ph.startF0 + (ph.endF0 - ph.startF0) * progress
                phaseF0 += 2.0 * PI * currentF0 / sampleRate
                if (phaseF0 > 2.0 * PI) phaseF0 -= 2.0 * PI

                val glottal = (sin(phaseF0) + 0.5 * sin(2.0 * phaseF0) + 0.3 * sin(3.0 * phaseF0) + 0.2 * sin(4.0 * phaseF0)) * (1.0 - ph.noiseRatio)
                val noise = (random.nextDouble() * 2.0 - 1.0) * ph.noiseRatio
                val excitation = glottal + noise

                val y1 = 2.0 * r1 * cos1 * y1Prev1 - (r1 * r1) * y1Prev2 + (1.0 - r1) * excitation
                y1Prev2 = y1Prev1
                y1Prev1 = y1

                val y2 = 2.0 * r2 * cos2 * y2Prev1 - (r2 * r2) * y2Prev2 + (1.0 - r2) * excitation
                y2Prev2 = y2Prev1
                y2Prev1 = y2

                val y3 = 2.0 * r3 * cos3 * y3Prev1 - (r3 * r3) * y3Prev2 + (1.0 - r3) * excitation
                y3Prev2 = y3Prev1
                y3Prev1 = y3

                val vocalSample = (y1 * 0.55 + y2 * 0.32 + y3 * 0.13) * env * 1.45
                val currentShort = buffer[idx].toInt()
                val combined = (currentShort + (vocalSample * Short.MAX_VALUE * 0.85).toInt()).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                buffer[idx] = combined.toShort()
            }
        }

        return buffer
    }

    /**
     * Reproduce una muestra de prueba del preset usando AudioTrack estático en memoria.
     */
    fun playPreview(presetId: String, onDone: () -> Unit): AudioTrack? {
        return try {
            val sampleRate = 44100
            val pcmData = when (presetId) {
                "preset_police_siren" -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
                "preset_nuclear_alarm" -> generateNuclearAlarmSamples(sampleRate, durationSec = 2.0)
                "preset_bicycle_bell" -> generateBicycleBellSamples(sampleRate)
                "preset_loud_meow" -> generateLoudMeowSamples(sampleRate)
                else -> generatePoliceSirenSamples(sampleRate, durationSec = 2.0)
            }

            val audioTrack = AudioTrack(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
                pcmData.size * 2,
                AudioTrack.MODE_STATIC,
                android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
            )

            audioTrack.write(pcmData, 0, pcmData.size)
            audioTrack.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack?) {
                    try {
                        track?.stop()
                        track?.release()
                    } catch (_: Exception) {}
                    onDone()
                }

                override fun onPeriodicNotification(track: AudioTrack?) {}
            })
            audioTrack.notificationMarkerPosition = pcmData.size
            audioTrack.play()
            audioTrack
        } catch (e: Exception) {
            Log.e(TAG, "Error playing preview for preset", e)
            onDone()
            null
        }
    }

    // 1. Sirena de policía oscilante (650 Hz a 1350 Hz en ciclos de 0.6s)
    private fun generatePoliceSirenSamples(sampleRate: Int, durationSec: Double): ShortArray {
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            // Frecuencia oscilante
            val sweep = 0.5 * (1.0 + sin(2.0 * PI * 1.6 * t))
            val freq = 650.0 + sweep * 700.0 // 650 Hz a 1350 Hz
            phase += 2.0 * PI * freq / sampleRate
            if (phase > 2.0 * PI) phase -= 2.0 * PI

            // Onda sinusoidal enriquecida con armónico suave
            val wave = 0.85 * sin(phase) + 0.15 * sin(2.0 * phase)
            buffer[i] = (wave * Short.MAX_VALUE * 0.92).toInt().toShort()
        }
        return buffer
    }

    // 2. Alarma nuclear (Tono bajo pulsante 420 Hz modulado fuertemente con silencios de alarma)
    private fun generateNuclearAlarmSamples(sampleRate: Int, durationSec: Double): ShortArray {
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val pulseCycle = (t % 0.5) / 0.5 // Ciclo de 500 ms (pulso de alarma)
            val envelope = if (pulseCycle < 0.75) {
                // Sonando con ataque suave
                sin(pulseCycle / 0.75 * PI)
            } else {
                0.0 // Breve pausa entre bocinazos
            }

            // Frecuencia grave penetrante con modulación de vibrato
            val freq = 440.0 + 35.0 * sin(2.0 * PI * 6.0 * t)
            phase += 2.0 * PI * freq / sampleRate
            if (phase > 2.0 * PI) phase -= 2.0 * PI

            val wave = 0.75 * sin(phase) + 0.25 * sin(3.0 * phase)
            buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.95).toInt().toShort()
        }
        return buffer
    }

    // 3. Timbre de bicicleta (Ring-Ring metálico con armónicos 2100 Hz y 2400 Hz)
    private fun generateBicycleBellSamples(sampleRate: Int): ShortArray {
        val durationSec = 1.8
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        val rings = listOf(0.05, 0.45, 0.95, 1.35) // 4 campanadas en pares
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            var sampleSum = 0.0

            for (ringStart in rings) {
                if (t >= ringStart) {
                    val dt = t - ringStart
                    if (dt < 0.35) {
                        // Decaimiento exponencial típico de campana metálica
                        val decay = Math.exp(-dt * 14.0)
                        val chime1 = sin(2.0 * PI * 2093.0 * dt) // C7
                        val chime2 = sin(2.0 * PI * 2520.0 * dt) // Armónico metálico
                        val shimmer = sin(2.0 * PI * 3135.0 * dt) * 0.4
                        sampleSum += (chime1 * 0.5 + chime2 * 0.35 + shimmer) * decay
                    }
                }
            }

            buffer[i] = (sampleSum.coerceIn(-1.0, 1.0) * Short.MAX_VALUE * 0.90).toInt().toShort()
        }
        return buffer
    }

    // 4. Maullido fuerte (Curva ascendente y descendente de frecuencia felina con formantes)
    private fun generateLoudMeowSamples(sampleRate: Int): ShortArray {
        val durationSec = 1.8
        val totalSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(totalSamples)

        val meowStarts = listOf(0.1, 0.95) // 2 maullidos expresivos
        for (meowStart in meowStarts) {
            val meowDuration = 0.75
            val startIndex = (meowStart * sampleRate).toInt()
            val meowSamples = (meowDuration * sampleRate).toInt()
            var phase1 = 0.0
            var phase2 = 0.0

            for (j in 0 until meowSamples) {
                val idx = startIndex + j
                if (idx >= totalSamples) break

                val progress = j.toDouble() / meowSamples
                // Envolvente vocal de maullido: sube rápido, se mantiene y baja
                val envelope = when {
                    progress < 0.15 -> progress / 0.15
                    progress < 0.75 -> 1.0 - (progress - 0.15) * 0.3
                    else -> ((1.0 - progress) / 0.25).coerceAtLeast(0.0)
                }

                // Curva de frecuencia: sube de 550 a 920 Hz y luego cae a 620 Hz
                val freq = if (progress < 0.4) {
                    550.0 + (progress / 0.4) * 370.0
                } else {
                    920.0 - ((progress - 0.4) / 0.6) * 300.0
                }

                phase1 += 2.0 * PI * freq / sampleRate
                phase2 += 2.0 * PI * (freq * 1.5) / sampleRate
                if (phase1 > 2.0 * PI) phase1 -= 2.0 * PI
                if (phase2 > 2.0 * PI) phase2 -= 2.0 * PI

                val vocalTone = 0.65 * sin(phase1) + 0.35 * sin(phase2)
                buffer[idx] = (vocalTone * envelope * Short.MAX_VALUE * 0.92).toInt().toShort()
            }
        }
        return buffer
    }

    /**
     * Escribe un archivo de audio WAV PCM de 16 bits estándar compatible con Android.
     */
    private fun writeWavFile(file: File, pcmData: ShortArray, sampleRate: Int) {
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * bitsPerSample / 8
        val totalAudioLen = pcmData.size * 2
        val totalDataLen = totalAudioLen + 36

        FileOutputStream(file).use { out ->
            val header = ByteArray(44)
            // RIFF/WAVE header
            header[0] = 'R'.code.toByte()
            header[1] = 'I'.code.toByte()
            header[2] = 'F'.code.toByte()
            header[3] = 'F'.code.toByte()
            header[4] = (totalDataLen and 0xff).toByte()
            header[5] = ((totalDataLen shr 8) and 0xff).toByte()
            header[6] = ((totalDataLen shr 16) and 0xff).toByte()
            header[7] = ((totalDataLen shr 24) and 0xff).toByte()
            header[8] = 'W'.code.toByte()
            header[9] = 'A'.code.toByte()
            header[10] = 'V'.code.toByte()
            header[11] = 'E'.code.toByte()
            header[12] = 'f'.code.toByte()
            header[13] = 'm'.code.toByte()
            header[14] = 't'.code.toByte()
            header[15] = ' '.code.toByte()
            header[16] = 16
            header[17] = 0
            header[18] = 0
            header[19] = 0
            header[20] = 1 // PCM
            header[21] = 0
            header[22] = numChannels.toByte()
            header[23] = 0
            header[24] = (sampleRate and 0xff).toByte()
            header[25] = ((sampleRate shr 8) and 0xff).toByte()
            header[26] = ((sampleRate shr 16) and 0xff).toByte()
            header[27] = ((sampleRate shr 24) and 0xff).toByte()
            header[28] = (byteRate and 0xff).toByte()
            header[29] = ((byteRate shr 8) and 0xff).toByte()
            header[30] = ((byteRate shr 16) and 0xff).toByte()
            header[31] = ((byteRate shr 24) and 0xff).toByte()
            header[32] = (numChannels * bitsPerSample / 8).toByte()
            header[33] = 0
            header[34] = bitsPerSample.toByte()
            header[35] = 0
            header[36] = 'd'.code.toByte()
            header[37] = 'a'.code.toByte()
            header[38] = 't'.code.toByte()
            header[39] = 'a'.code.toByte()
            header[40] = (totalAudioLen and 0xff).toByte()
            header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
            header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
            header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

            out.write(header, 0, 44)

            // Escribir muestras en Little-Endian
            val byteBuffer = ByteArray(pcmData.size * 2)
            var byteIdx = 0
            for (sample in pcmData) {
                byteBuffer[byteIdx++] = (sample.toInt() and 0xFF).toByte()
                byteBuffer[byteIdx++] = ((sample.toInt() shr 8) and 0xFF).toByte()
            }
            out.write(byteBuffer)
        }
    }
}

package com.example.ui.i18n

import com.example.data.model.AppLanguage

/**
 * Diccionario centralizado de textos multiidioma para la interfaz de Móvil Detector.
 * Soporta actualización reactiva instantánea al cambiar el idioma sin reiniciar la app.
 */
object AppStrings {

    fun get(lang: AppLanguage): Strings {
        val effective = AppLanguage.getEffectiveLanguage(lang)
        return when (effective) {
            AppLanguage.VALENCIAN -> ValencianStrings
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.FRENCH -> FrenchStrings
            AppLanguage.GERMAN -> GermanStrings
            AppLanguage.ITALIAN -> ItalianStrings
            AppLanguage.PORTUGUESE -> PortugueseStrings
            AppLanguage.SPANISH, AppLanguage.SYSTEM_DEFAULT -> SpanishStrings
        }
    }

    interface Strings {
        // TopBar
        val appTitle: String
        val appSubtitle: String
        val proBadge: String
        val settingsMenuCd: String

        // Hero Card
        val listeningActive: String
        val listeningPaused: String
        val tapToActivate: String
        val sayPhrase: (String) -> String
        val clapTwice: String
        val whistle: String
        val heroListeningDesc: String
        val heroPausedDesc: String
        val detectedVoice: (String) -> String
        val micStatusCd: String

        // System mic warning
        val micBlockedTitle: String
        val micBlockedDesc: String

        // Slots Card
        val slotsTitle: String
        val slotsProSubtitle: String
        val slotsFreeSubtitle: String
        val slotsOccupied: (Int, Int) -> String
        val slotsCurrentCapacity: (Int) -> String
        val slotsMax: (Int) -> String
        val exploreCatalogButton: String
        val watchAdToUnlockButton: (Int) -> String

        // Sounds List
        val soundsHeaderTitle: String
        val soundsHeaderSubtitle: String
        val defaultBeepsDesc: String
        val defaultVoiceDesc: String
        val customRecordingDesc: (Int) -> String
        val playSoundCd: String
        val pauseSoundCd: String
        val editNameCd: String
        val deleteSoundCd: String
        val newSoundFab: (Int, Int) -> String
        val soundSelectedSnackbar: (String) -> String

        // Floating & actions
        val maxSlotsReached: String
        val removeAdsTitle: String
        val removeAdsDesc: String
        val unlockWithAd: String
        val cancel: String
        val understood: String
        val grantPermission: String
        val micPermissionTitle: String
        val micPermissionDesc: String

        // Legal Consent First Run Dialog
        val legalTermsTitle: String
        val legalTermsWelcome: String
        val legalTermsDescription: String
        val legalCheckboxPrivacy: String
        val legalCheckboxTerms: String
        val legalPrivacyHighlight: String
        val legalAcceptAndContinue: String
        val legalViewPrivacyDoc: String
        val legalViewTermsDoc: String
        val legalMustAcceptToEnter: String
        val legalAppBlockedNotice: String

        // Legal viewer dialog
        val closeDoc: String

        // Settings Sheet Menus
        val settingsTitle: String
        val settingsSubtitle: String
        val settingsCloseCd: String
        val settingsBackCd: String
        val close: String
        val statusConnected: String
        val statusSignIn: String
        val statusSelected: String

        val settingsAccountTitle: String
        val settingsAccountSubtitle: String
        val settingsDetectionTitle: String
        val settingsDetectionSubtitle: String
        val settingsAlarmTitle: String
        val settingsAlarmSubtitle: String
        val settingsAppearanceTitle: String
        val settingsAppearanceSubtitle: String
        val settingsLanguageTitle: String
        val settingsLanguageSubtitle: String
        val settingsProTitle: String
        val settingsProSubtitle: String
        val settingsSupportTitle: String
        val settingsSupportSubtitle: String
        val settingsLegalTitle: String
        val settingsLegalSubtitle: String

        // Settings: Submenu 1 Detection
        val detectionTriggerMethodTitle: String
        val detectionTriggerMethodDesc: String
        val detectionModeVoice: String
        val detectionModeClap: String
        val detectionModeWhistle: String
        val detectionPhraseTitle: String
        val detectionPhraseDesc: String
        val detectionPhrasePlaceholder: String
        val detectionSavePhrase: String
        val detectionPhraseSaved: String
        val detectionSavePhraseCd: String
        val detectionMicPrivacyTitle: String
        val detectionMicPrivacyDesc: String

        // Settings: Submenu 2 Alarm
        val alarmTestButton: String
        val alarmFlashPatternTitle: String
        val alarmFlashFast: String
        val alarmFlashContinuous: String
        val alarmVibrationTitle: String
        val alarmVibrationLow: String
        val alarmVibrationMedium: String
        val alarmVibrationHigh: String
        val alarmVolumeInfo: String
        val alarmDndBypassTitle: String
        val alarmDndBypassDesc: String
        val alarmBluetoothAlertTitle: String
        val alarmBluetoothAlertDesc: String

        // Settings: Submenu 3 Appearance
        val appearanceThemeTitle: String
        val appearanceDarkMode: String
        val appearanceLightMode: String
        val appearanceLanguageQuick: String
        val appearanceResetSoundsTitle: String

        // Settings: Submenu 4 Language
        val languageAutoTitle: String
        val languageAutoDesc: (String) -> String
        val languageFixedDesc: (String, String) -> String
        val availableLanguages: String
        val systemDefaultTag: String
        val languageChangedToast: (String) -> String
        val languageAutoDevice: (String, String) -> String

        // Settings: Submenu 5 PRO
        val proActiveTitle: String
        val proFreeTitle: String
        val proActiveSubtitle: String
        val proFreeSubtitle: String
        val proManageBtn: String
        val proRemoveAdsBtn: String
        val proDiscordBtn: String

        // Settings: Submenu 6 Account & Cloud (no Supabase)
        val accountLoggedInTitle: String
        val accountLoggedOutTitle: String
        val accountConnectedCloud: String
        val accountLoggedOutSubtitle: String
        val accountSyncDesc: String
        val accountSyncStatusPrefix: String
        val accountSignInGoogleBtn: String
        val accountSyncActive: String
        val accountSyncing: String
        val accountLogoutBtn: String

        // Settings: Submenu 7 Legal
        val legalTransparencyTitle: String
        val legalTransparencySubtitle: String
        val legalPrivacyHighlightText: String
        val legalReadPrivacyBtn: String
        val legalReadTermsBtn: String
        val legalReadRefundBtn: String
        val legalDataControllerTitle: String
    }

    object SpanishStrings : Strings {
        override val appTitle = "Móvil Detector"
        override val appSubtitle = "Encuentra tu teléfono al instante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menú de ajustes"

        override val listeningActive = "ESCUCHA ACTIVA"
        override val listeningPaused = "DETECTOR EN PAUSA"
        override val tapToActivate = "Toca para activar"
        override val sayPhrase = { phrase: String -> "Di \"$phrase\"" }
        override val clapTwice = "Da 2 palmadas seguidas"
        override val whistle = "Emite un silbido"
        override val heroListeningDesc = "Responderá de inmediato con linterna, vibración y volumen inteligente (incluso con la pantalla bloqueada)."
        override val heroPausedDesc = "El servicio está en reposo. Pulsa el botón para ponerlo a escuchar en segundo plano."
        override val detectedVoice = { text: String -> "Detectado: \"$text\"" }
        override val micStatusCd = "Estado de micrófono"

        override val micBlockedTitle = "Micrófono bloqueado en Android"
        override val micBlockedDesc = "El acceso al micrófono está desactivado en la barra de ajustes rápidos del sistema. Actívalo para que la app pueda escuchar."

        override val slotsTitle = "Espacios de Sonidos"
        override val slotsProSubtitle = "Plan PRO • Todos desbloqueados"
        override val slotsFreeSubtitle = "3 iniciales • Ampliable hasta 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupados" }
        override val slotsCurrentCapacity = { count: Int -> "Capacidad actual: $count sonidos" }
        override val slotsMax = { max: Int -> "Máximo: $max" }
        override val exploreCatalogButton = "Explorar catálogo de efectos divertidos"
        override val watchAdToUnlockButton = { next: Int -> "Ver anuncio breve para desbloquear espacio #$next" }

        override val soundsHeaderTitle = "Sonidos de respuesta"
        override val soundsHeaderSubtitle = "Toca para elegir cómo contestará el móvil. Puedes editar el nombre o eliminarlos."
        override val defaultBeepsDesc = "Alerta aguda • Doble tono"
        override val defaultVoiceDesc = "Saludo alegre • \"¡Holaaaaa! ¡Aquí estoy, aquí estoy!\""
        override val customRecordingDesc = { sec: Int -> "Grabación propia • ${sec}s" }
        override val playSoundCd = "Escuchar sonido"
        override val pauseSoundCd = "Pausar sonido"
        override val editNameCd = "Editar nombre"
        override val deleteSoundCd = "Eliminar sonido"
        override val newSoundFab = { cur: Int, max: Int -> "Nuevo sonido ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Sonido seleccionado: $name" }

        override val maxSlotsReached = "Has alcanzado el límite máximo de 15 sonidos."
        override val removeAdsTitle = "Espacios de sonido llenos"
        override val removeAdsDesc = "Has ocupado todos tus espacios disponibles. Puedes desbloquear más viendo un anuncio o con la versión PRO."
        override val unlockWithAd = "Desbloquear con anuncio"
        override val cancel = "Cancelar"
        override val understood = "Entendido"
        override val grantPermission = "Conceder permiso"
        override val micPermissionTitle = "Permiso de micrófono requerido"
        override val micPermissionDesc = "Para detectar tu voz, palmadas o silbidos cuando tu móvil esté perdido, la aplicación necesita acceso al micrófono."

        override val legalTermsTitle = "Condiciones y Privacidad"
        override val legalTermsWelcome = "Bienvenido a Móvil Detector"
        override val legalTermsDescription = "Para poder utilizar la aplicación y activar la escucha en tu dispositivo, es obligatorio leer y aceptar nuestras condiciones de uso y política de privacidad."
        override val legalCheckboxPrivacy = "He leído y acepto la Política de Privacidad (procesamiento de audio 100% en el dispositivo)."
        override val legalCheckboxTerms = "Acepto los Términos y Condiciones de Uso de la aplicación."
        override val legalPrivacyHighlight = "🔒 Privacidad garantizada: El audio se procesa de forma efímera en la memoria de tu móvil. No se graba ni se envía ninguna conversación a servidores externos."
        override val legalAcceptAndContinue = "Aceptar y entrar a la app"
        override val legalViewPrivacyDoc = "Leer Política de Privacidad"
        override val legalViewTermsDoc = "Leer Términos y Condiciones"
        override val legalMustAcceptToEnter = "Debes marcar ambas casillas para poder acceder a la aplicación."
        override val legalAppBlockedNotice = "El acceso permanece bloqueado hasta aceptar los términos legales."

        override val closeDoc = "Cerrar"

        override val settingsTitle = "Ajustes"
        override val settingsSubtitle = "Selecciona una categoría"
        override val settingsCloseCd = "Cerrar ajustes"
        override val settingsBackCd = "Volver a Ajustes"
        override val close = "Cerrar"
        override val statusConnected = "Conectado"
        override val statusSignIn = "Iniciar sesión"
        override val statusSelected = "Seleccionado"

        override val settingsAccountTitle = "Cuenta y Sincronización en la Nube"
        override val settingsAccountSubtitle = "Copia en la nube de compras, sonidos y ajustes"
        override val settingsDetectionTitle = "Detección y Activación"
        override val settingsDetectionSubtitle = "Modo voz, palmadas, silbido y palabra clave"
        override val settingsAlarmTitle = "Alarma y Respuesta"
        override val settingsAlarmSubtitle = "Linterna, vibración, volumen y modo silencio"
        override val settingsAppearanceTitle = "Pantalla y Personalización"
        override val settingsAppearanceSubtitle = "Tema claro/oscuro y sonidos predeterminados"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automático, Español, Valencià, English..."
        override val settingsProTitle = "Plan PRO y Licencia"
        override val settingsProSubtitle = "Eliminar anuncios y funciones completas"
        override val settingsSupportTitle = "Soporte"
        override val settingsSupportSubtitle = "Servidor oficial de Discord para ayuda y sugerencias"
        override val settingsLegalTitle = "Información Legal y Privacidad"
        override val settingsLegalSubtitle = "Política de privacidad, términos y derechos"

        override val detectionTriggerMethodTitle = "Método de activación sonora"
        override val detectionTriggerMethodDesc = "¿Cómo quieres que el móvil te escuche y responda?"
        override val detectionModeVoice = "Modo voz"
        override val detectionModeClap = "2 Palmadas"
        override val detectionModeWhistle = "Silbido"
        override val detectionPhraseTitle = "Palabra o frase para el Modo voz"
        override val detectionPhraseDesc = "Escribe la palabra que quieras decir para que el móvil responda (ej: \"Hey Móvil\", \"Buscar\")."
        override val detectionPhrasePlaceholder = "Ej: Hey Móvil"
        override val detectionSavePhrase = "Guardar"
        override val detectionPhraseSaved = "Guardado"
        override val detectionSavePhraseCd = "Guardar palabra"
        override val detectionMicPrivacyTitle = "Aviso de micrófono bloqueado"
        override val detectionMicPrivacyDesc = "Comprueba si el acceso al micrófono de Android está apagado en los ajustes rápidos."

        override val alarmTestButton = "Comprobar alarma (Sonido, Linterna, Vibración)"
        override val alarmFlashPatternTitle = "Patrón de linterna"
        override val alarmFlashFast = "Rápido"
        override val alarmFlashContinuous = "Continuo"
        override val alarmVibrationTitle = "Vibración de alerta"
        override val alarmVibrationLow = "Baja"
        override val alarmVibrationMedium = "Media (Por defecto)"
        override val alarmVibrationHigh = "Alta"
        override val alarmVolumeInfo = "Volumen escalado: 1ª vez al 50%, si repites en <30s sube al 75% y luego al 100%."
        override val alarmDndBypassTitle = "Sonar en Silencio / No Molestar"
        override val alarmDndBypassDesc = "Garantiza que la alarma suene con volumen incluso si el teléfono está en silencio."
        override val alarmBluetoothAlertTitle = "Aviso por desconexión Bluetooth"
        override val alarmBluetoothAlertDesc = "Emite un pitido y vibra si los auriculares se desconectan con el detector activo."

        override val appearanceThemeTitle = "Tema de la aplicación"
        override val appearanceDarkMode = "Modo Oscuro activo"
        override val appearanceLightMode = "Modo Claro activo"
        override val appearanceLanguageQuick = "Idioma"
        override val appearanceResetSoundsTitle = "Restablecer sonidos originales (\"Dos pitidos\" y \"¡Hola! Aquí estoy\")"

        override val languageAutoTitle = "Detección automática activa"
        override val languageAutoDesc = { detected: String -> "El idioma se adapta al de tu móvil. Actualmente: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fijado en $native ($display)." }
        override val availableLanguages = "Idiomas disponibles"
        override val systemDefaultTag = "Predeterminado"
        override val languageChangedToast = { lang: String -> "Idioma seleccionado: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Detectado según dispositivo: $native ($display)" }

        override val proActiveTitle = "Plan PRO Activado"
        override val proFreeTitle = "Versión con anuncios"
        override val proActiveSubtitle = "Sin anuncios • 15 espacios • Audios hasta 60s"
        override val proFreeSubtitle = "Elimina anuncios y desbloquea funciones completas"
        override val proManageBtn = "Gestionar"
        override val proRemoveAdsBtn = "Quitar Ads"
        override val proDiscordBtn = "¿Dudas con tu compra? Servidor de Discord"

        override val accountLoggedInTitle = "Cuenta Vinculada"
        override val accountLoggedOutTitle = "Sincronización en la Nube"
        override val accountConnectedCloud = "Conectado a la nube"
        override val accountLoggedOutSubtitle = "Guarda compras, sonidos y ajustes"
        override val accountSyncDesc = "Tu cuenta de Google sincroniza automáticamente la licencia PRO (Sin Anuncios), los espacios de sonidos desbloqueados, el catálogo de sonidos grabados e importados, y todos tus ajustes de detección en la nube."
        override val accountSyncStatusPrefix = "Estado:"
        override val accountSignInGoogleBtn = "Iniciar sesión con Google"
        override val accountSyncActive = "Sincronización automática en la nube activa"
        override val accountSyncing = "Sincronizando con la nube..."
        override val accountLogoutBtn = "Cerrar Sesión"

        override val legalTransparencyTitle = "Transparencia y Normativa"
        override val legalTransparencySubtitle = "Cumplimiento con RGPD, LOPDGDD y Google Play"
        override val legalPrivacyHighlightText = "Tu privacidad es nuestra prioridad: el micrófono procesa el sonido exclusivamente en la memoria local de tu dispositivo. No grabamos conversaciones ni transmitimos datos de audio a ningún servidor externo."
        override val legalReadPrivacyBtn = "Leer Política de Privacidad"
        override val legalReadTermsBtn = "Leer Términos y Condiciones"
        override val legalReadRefundBtn = "Política de Reembolsos"
        override val legalDataControllerTitle = "Responsable del tratamiento de datos:"
    }

    object ValencianStrings : Strings {
        override val appTitle = "Mòbil Detector"
        override val appSubtitle = "Troba el teu telèfon a l'instant"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menú d'ajustos"

        override val listeningActive = "ESCOLTA ACTIVA"
        override val listeningPaused = "DETECTOR EN PAUSA"
        override val tapToActivate = "Toca per a activar"
        override val sayPhrase = { phrase: String -> "Diu \"$phrase\"" }
        override val clapTwice = "Dóna 2 palmades seguides"
        override val whistle = "Fes un xiulit"
        override val heroListeningDesc = "Respondrà de seguida amb llanterna, vibració i volum intel·ligent (fins i tot amb la pantalla bloquejada)."
        override val heroPausedDesc = "El servei està en repòs. Prem el botó per a posar-lo a escoltar en segon pla."
        override val detectedVoice = { text: String -> "Detectat: \"$text\"" }
        override val micStatusCd = "Estat del micròfon"

        override val micBlockedTitle = "Micròfon bloquejat en Android"
        override val micBlockedDesc = "L'accés al micròfon està desactivat en la barra d'ajustos ràpids. Activa'l perquè l'app puga escoltar."

        override val slotsTitle = "Espais de Sons"
        override val slotsProSubtitle = "Pla PRO • Tots desbloquejats"
        override val slotsFreeSubtitle = "3 inicials • Ampliable fins a 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupats" }
        override val slotsCurrentCapacity = { count: Int -> "Capacitat actual: $count sons" }
        override val slotsMax = { max: Int -> "Màxim: $max" }
        override val exploreCatalogButton = "Explorar catàleg d'efectes divertits"
        override val watchAdToUnlockButton = { next: Int -> "Veure anunci breu per a desbloquejar espai #$next" }

        override val soundsHeaderTitle = "Sons de resposta"
        override val soundsHeaderSubtitle = "Toca per a triar com contestarà el mòbil. Pots editar el nom o esborrar-los."
        override val defaultBeepsDesc = "Alerta aguda • Doble to"
        override val defaultVoiceDesc = "Salutació alegre • \"Holaaaa! Sóc ací, sóc ací!\""
        override val customRecordingDesc = { sec: Int -> "Gravació pròpia • ${sec}s" }
        override val playSoundCd = "Escoltar so"
        override val pauseSoundCd = "Pausar so"
        override val editNameCd = "Editar nom"
        override val deleteSoundCd = "Esborrar so"
        override val newSoundFab = { cur: Int, max: Int -> "Nou so ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "So seleccionat: $name" }

        override val maxSlotsReached = "Has aconseguit el límit màxim de 15 sons."
        override val removeAdsTitle = "Espais de so plens"
        override val removeAdsDesc = "Has ocupat tots els espais disponibles. Pots desbloquejar-ne més veient un anunci o amb el Pla PRO."
        override val unlockWithAd = "Desbloquejar amb anunci"
        override val cancel = "Cancel·lar"
        override val understood = "Entés"
        override val grantPermission = "Concedir permís"
        override val micPermissionTitle = "Permís de micròfon necessari"
        override val micPermissionDesc = "Per a detectar la teua veu, palmades o xiulits quan el mòbil estiga perdut, l'aplicació necessita accés al micròfon."

        override val legalTermsTitle = "Condicions i Privacitat"
        override val legalTermsWelcome = "Benvingut a Mòbil Detector"
        override val legalTermsDescription = "Per a poder utilitzar l'aplicació i activar l'escolta en el teu dispositiu, cal llegir i acceptar les condicions d'ús i la política de privacitat."
        override val legalCheckboxPrivacy = "He llegit i accepte la Política de Privacitat (processament d'àudio 100% en el dispositiu)."
        override val legalCheckboxTerms = "Accepte els Termes i Condicions d'Ús de l'aplicació."
        override val legalPrivacyHighlight = "🔒 Privacitat garantida: L'àudio es processa de manera efímera en la memòria del teu mòbil. No es grava ni s'envia cap conversa a servidors externs."
        override val legalAcceptAndContinue = "Acceptar i entrar a l'app"
        override val legalViewPrivacyDoc = "Llegir Política de Privacitat"
        override val legalViewTermsDoc = "Llegir Termes i Condicions"
        override val legalMustAcceptToEnter = "Has de marcar ambdues caselles per a poder accedir a l'aplicació."
        override val legalAppBlockedNotice = "L'accés roman bloquejat fins que s'accepten els termes legals."

        override val closeDoc = "Tancar"

        override val settingsTitle = "Ajustos de l'aplicació"
        override val settingsSubtitle = "Selecciona una categoria"
        override val settingsCloseCd = "Tancar ajustos"
        override val settingsBackCd = "Tornar a Ajustos"
        override val close = "Tancar"
        override val statusConnected = "Connectat"
        override val statusSignIn = "Iniciar sessió"
        override val statusSelected = "Seleccionat"

        override val settingsAccountTitle = "Compte i Sincronització al Núvol"
        override val settingsAccountSubtitle = "Còpia al núvol de compres, sons i ajustos"
        override val settingsDetectionTitle = "Detecció i Activació"
        override val settingsDetectionSubtitle = "Mode veu, palmades, xiulit i paraula clau"
        override val settingsAlarmTitle = "Alarma i Resposta"
        override val settingsAlarmSubtitle = "Llanterna, vibració, volum i mode silenci"
        override val settingsAppearanceTitle = "Pantalla i Personalització"
        override val settingsAppearanceSubtitle = "Tema clar/fosc i sons predeterminats"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automàtic, Valencià, Castellà, English..."
        override val settingsProTitle = "Pla PRO i Llicència"
        override val settingsProSubtitle = "Eliminar anuncis i funcions completes"
        override val settingsSupportTitle = "Suport"
        override val settingsSupportSubtitle = "Servidor oficial de Discord per a ajuda i suggeriments"
        override val settingsLegalTitle = "Informació Legal i Privacitat"
        override val settingsLegalSubtitle = "Política de privacitat, termes i drets"

        override val detectionTriggerMethodTitle = "Mètode d'activació sonora"
        override val detectionTriggerMethodDesc = "Com vols que el mòbil t'escolte i responga?"
        override val detectionModeVoice = "Mode veu"
        override val detectionModeClap = "2 Palmades"
        override val detectionModeWhistle = "Xiulit"
        override val detectionPhraseTitle = "Paraula o frase per al Mode veu"
        override val detectionPhraseDesc = "Escriu la paraula que vulgues dir perquè el mòbil responga (ex: \"Ei Mòbil\", \"Buscar\")."
        override val detectionPhrasePlaceholder = "Ex: Ei Mòbil"
        override val detectionSavePhrase = "Guardar"
        override val detectionPhraseSaved = "Guardat"
        override val detectionSavePhraseCd = "Guardar paraula"
        override val detectionMicPrivacyTitle = "Avís de micròfon bloquejat"
        override val detectionMicPrivacyDesc = "Comprova si l'accés al micròfon d'Android està apagat en els ajustos ràpids."

        override val alarmTestButton = "Comprovar alarma (So, Llanterna, Vibració)"
        override val alarmFlashPatternTitle = "Patró de llanterna"
        override val alarmFlashFast = "Ràpid"
        override val alarmFlashContinuous = "Continu"
        override val alarmVibrationTitle = "Vibració d'alerta"
        override val alarmVibrationLow = "Baixa"
        override val alarmVibrationMedium = "Mitjana (Per defecte)"
        override val alarmVibrationHigh = "Alta"
        override val alarmVolumeInfo = "Volum escalat: 1a vegada al 50%, si repeteixes en <30s puja al 75% i després al 100%."
        override val alarmDndBypassTitle = "Sonar en Silenci / No Molestar"
        override val alarmDndBypassDesc = "Garanteix que l'alarma sone amb volum fins i tot si el telèfon està en silenci."
        override val alarmBluetoothAlertTitle = "Avís per desconnexió Bluetooth"
        override val alarmBluetoothAlertDesc = "Emet un xiulet i vibra si els auriculars es desconnecten amb el detector actiu."

        override val appearanceThemeTitle = "Tema de l'aplicació"
        override val appearanceDarkMode = "Mode Fosc actiu"
        override val appearanceLightMode = "Mode Clar actiu"
        override val appearanceLanguageQuick = "Idioma"
        override val appearanceResetSoundsTitle = "Restablir sons originals (\"Dos xiulets\" i \"Hola! Ací estic\")"

        override val languageAutoTitle = "Detecció automàtica activa"
        override val languageAutoDesc = { detected: String -> "L'idioma s'adapta al del teu mòbil. Actualment: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fixat en $native ($display)." }
        override val availableLanguages = "Idiomes disponibles"
        override val systemDefaultTag = "Predeterminat"
        override val languageChangedToast = { lang: String -> "Idioma seleccionat: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Detectat segons dispositiu: $native ($display)" }

        override val proActiveTitle = "Pla PRO Activat"
        override val proFreeTitle = "Versió amb anuncis"
        override val proActiveSubtitle = "Sense anuncis • 15 espais • Àudios fins a 60s"
        override val proFreeSubtitle = "Elimina anuncis i desbloqueja funcions completes"
        override val proManageBtn = "Gestionar"
        override val proRemoveAdsBtn = "Treure Ads"
        override val proDiscordBtn = "Dubtes amb la teua compra? Servidor de Discord"

        override val accountLoggedInTitle = "Compte Vinculat"
        override val accountLoggedOutTitle = "Sincronització al Núvol"
        override val accountConnectedCloud = "Connectat al núvol"
        override val accountLoggedOutSubtitle = "Guarda compres, sons i ajustos"
        override val accountSyncDesc = "El teu compte de Google sincronitza automàticament la llicència PRO (Sense Anuncis), els espais de sons desbloquejats, el catàleg de sons enregistrats i importats, i tots els teus ajustos de detecció al núvol."
        override val accountSyncStatusPrefix = "Estat:"
        override val accountSignInGoogleBtn = "Iniciar sessió amb Google"
        override val accountSyncActive = "Sincronització automàtica al núvol activa"
        override val accountSyncing = "Sincronitzant amb el núvol..."
        override val accountLogoutBtn = "Tancar Sessió"

        override val legalTransparencyTitle = "Transparència i Normativa"
        override val legalTransparencySubtitle = "Compliment amb RGPD, LOPDGDD i Google Play"
        override val legalPrivacyHighlightText = "La teua privacitat és la nostra prioritat: el micròfon processa el so exclusivament a la memòria local del dispositiu. No enregistrem converses ni transmetem àudio a servidors externs."
        override val legalReadPrivacyBtn = "Llegir Política de Privacitat"
        override val legalReadTermsBtn = "Llegir Termes i Condicions"
        override val legalReadRefundBtn = "Política de Reemborsaments"
        override val legalDataControllerTitle = "Responsable del tractament de dades:"
    }

    object EnglishStrings : Strings {
        override val appTitle = "Phone Finder Detector"
        override val appSubtitle = "Find your phone instantly"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Settings menu"

        override val listeningActive = "LISTENING ACTIVE"
        override val listeningPaused = "DETECTOR PAUSED"
        override val tapToActivate = "Tap to activate"
        override val sayPhrase = { phrase: String -> "Say \"$phrase\"" }
        override val clapTwice = "Clap twice"
        override val whistle = "Whistle"
        override val heroListeningDesc = "It will respond instantly with flashlight, vibration and progressive volume (even when locked)."
        override val heroPausedDesc = "Service is idle. Tap the button to enable background listening."
        override val detectedVoice = { text: String -> "Heard: \"$text\"" }
        override val micStatusCd = "Microphone status"

        override val micBlockedTitle = "Microphone blocked in Android"
        override val micBlockedDesc = "Microphone access is toggled off in system quick settings. Turn it on for the app to listen."

        override val slotsTitle = "Sound Slots"
        override val slotsProSubtitle = "PRO Plan • All unlocked"
        override val slotsFreeSubtitle = "3 initial • Expandable up to 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupied" }
        override val slotsCurrentCapacity = { count: Int -> "Current capacity: $count sounds" }
        override val slotsMax = { max: Int -> "Max: $max" }
        override val exploreCatalogButton = "Explore fun sound effects catalog"
        override val watchAdToUnlockButton = { next: Int -> "Watch quick ad to unlock slot #$next" }

        override val soundsHeaderTitle = "Response Sounds"
        override val soundsHeaderSubtitle = "Tap to choose how your phone responds. You can rename or delete them."
        override val defaultBeepsDesc = "High alert • Double beep"
        override val defaultVoiceDesc = "Cheerful greeting • \"Helloooo! Here I am, here I am!\""
        override val customRecordingDesc = { sec: Int -> "Custom recording • ${sec}s" }
        override val playSoundCd = "Play sound"
        override val pauseSoundCd = "Pause sound"
        override val editNameCd = "Edit name"
        override val deleteSoundCd = "Delete sound"
        override val newSoundFab = { cur: Int, max: Int -> "New sound ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Selected sound: $name" }

        override val maxSlotsReached = "You have reached the maximum capacity of 15 sounds."
        override val removeAdsTitle = "Sound slots full"
        override val removeAdsDesc = "You have filled all available slots. Unlock more by watching an ad or upgrading to PRO."
        override val unlockWithAd = "Unlock with ad"
        override val cancel = "Cancel"
        override val understood = "Understood"
        override val grantPermission = "Grant permission"
        override val micPermissionTitle = "Microphone permission required"
        override val micPermissionDesc = "To detect your trigger phrase, claps or whistles when lost, the app requires microphone access."

        override val legalTermsTitle = "Terms & Privacy"
        override val legalTermsWelcome = "Welcome to Phone Finder Detector"
        override val legalTermsDescription = "To use the app and enable listening on your device, you must review and accept our terms of service and privacy policy."
        override val legalCheckboxPrivacy = "I have read and accept the Privacy Policy (100% on-device audio processing)."
        override val legalCheckboxTerms = "I accept the Terms and Conditions of Use."
        override val legalPrivacyHighlight = "🔒 Guaranteed Privacy: Audio is processed ephemerally in device RAM. No voice or recording is ever saved or sent to any server."
        override val legalAcceptAndContinue = "Accept & enter app"
        override val legalViewPrivacyDoc = "View Privacy Policy"
        override val legalViewTermsDoc = "View Terms & Conditions"
        override val legalMustAcceptToEnter = "You must check both boxes to access the application."
        override val legalAppBlockedNotice = "Access remains locked until legal terms are accepted."

        override val closeDoc = "Close"

        override val settingsTitle = "App Settings"
        override val settingsSubtitle = "Select a category"
        override val settingsCloseCd = "Close settings"
        override val settingsBackCd = "Back to Settings"
        override val close = "Close"
        override val statusConnected = "Connected"
        override val statusSignIn = "Sign in"
        override val statusSelected = "Selected"

        override val settingsAccountTitle = "Cloud & Account Sync"
        override val settingsAccountSubtitle = "Cloud backup of purchases, sounds and settings"
        override val settingsDetectionTitle = "Detection & Triggers"
        override val settingsDetectionSubtitle = "Voice phrase, clapping, whistling and keyword"
        override val settingsAlarmTitle = "Alarm & Response"
        override val settingsAlarmSubtitle = "Flashlight, vibration, volume and silent bypass"
        override val settingsAppearanceTitle = "Appearance & Display"
        override val settingsAppearanceSubtitle = "Dark/light theme and reset defaults"
        override val settingsLanguageTitle = "Language"
        override val settingsLanguageSubtitle = "Automatic, English, Spanish, French..."
        override val settingsProTitle = "PRO Plan & License"
        override val settingsProSubtitle = "Remove ads and unlock all features"
        override val settingsSupportTitle = "Support"
        override val settingsSupportSubtitle = "Official Discord server for help and suggestions"
        override val settingsLegalTitle = "Legal & Privacy"
        override val settingsLegalSubtitle = "View accepted terms and data privacy policy"

        override val detectionTriggerMethodTitle = "Sound trigger method"
        override val detectionTriggerMethodDesc = "How do you want the phone to listen and respond?"
        override val detectionModeVoice = "Voice mode"
        override val detectionModeClap = "2 Claps"
        override val detectionModeWhistle = "Whistle"
        override val detectionPhraseTitle = "Word or phrase for Voice Mode"
        override val detectionPhraseDesc = "Type the word you want to say for your phone to respond (e.g. \"Hey Phone\", \"Find\")."
        override val detectionPhrasePlaceholder = "e.g. Hey Phone"
        override val detectionSavePhrase = "Save"
        override val detectionPhraseSaved = "Saved"
        override val detectionSavePhraseCd = "Save word"
        override val detectionMicPrivacyTitle = "Microphone blocked warning"
        override val detectionMicPrivacyDesc = "Checks if Android microphone toggle is disabled in system quick settings."

        override val alarmTestButton = "Test alarm (Sound, Flashlight, Vibration)"
        override val alarmFlashPatternTitle = "Flashlight pattern"
        override val alarmFlashFast = "Fast"
        override val alarmFlashContinuous = "Continuous"
        override val alarmVibrationTitle = "Alert vibration"
        override val alarmVibrationLow = "Low"
        override val alarmVibrationMedium = "Medium (Default)"
        override val alarmVibrationHigh = "High"
        override val alarmVolumeInfo = "Scaled volume: 1st time at 50%, repeats within 30s scale to 75% and 100%."
        override val alarmDndBypassTitle = "Ring in Silent / Do Not Disturb"
        override val alarmDndBypassDesc = "Ensures the alarm sounds with volume even if phone is on silent."
        override val alarmBluetoothAlertTitle = "Bluetooth disconnection alert"
        override val alarmBluetoothAlertDesc = "Beeps and vibrates if earphones disconnect while detector is active."

        override val appearanceThemeTitle = "App theme"
        override val appearanceDarkMode = "Dark Mode active"
        override val appearanceLightMode = "Light Mode active"
        override val appearanceLanguageQuick = "Language"
        override val appearanceResetSoundsTitle = "Reset original sounds (\"Two beeps\" and \"Hello! Here I am\")"

        override val languageAutoTitle = "Automatic detection active"
        override val languageAutoDesc = { detected: String -> "App language matches your phone language. Current: $detected." }
        override val languageFixedDesc = { native: String, display: String -> "Fixed to $native ($display)." }
        override val availableLanguages = "Available Languages"
        override val systemDefaultTag = "Default"
        override val languageChangedToast = { lang: String -> "Language selected: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Detected from device: $native ($display)" }

        override val proActiveTitle = "PRO Plan Active"
        override val proFreeTitle = "Ad-supported version"
        override val proActiveSubtitle = "No ads • 15 sound slots • Audio up to 60s"
        override val proFreeSubtitle = "Remove ads and unlock all features"
        override val proManageBtn = "Manage"
        override val proRemoveAdsBtn = "Remove Ads"
        override val proDiscordBtn = "Questions about your purchase? Discord server"

        override val accountLoggedInTitle = "Linked Account"
        override val accountLoggedOutTitle = "Cloud Synchronization"
        override val accountConnectedCloud = "Connected to Cloud"
        override val accountLoggedOutSubtitle = "Saves purchases, sounds and settings"
        override val accountSyncDesc = "Your Google account automatically syncs your PRO license (No Ads), unlocked sound slots, catalog of sounds, and all detection settings in the cloud."
        override val accountSyncStatusPrefix = "Status:"
        override val accountSignInGoogleBtn = "Sign in with Google"
        override val accountSyncActive = "Automatic cloud sync active"
        override val accountSyncing = "Syncing with cloud..."
        override val accountLogoutBtn = "Sign Out"

        override val legalTransparencyTitle = "Transparency & Regulations"
        override val legalTransparencySubtitle = "GDPR, LOPDGDD and Google Play compliance"
        override val legalPrivacyHighlightText = "Your privacy is our top priority: the microphone processes audio strictly in local device memory. We never record conversations or transmit audio data to any remote server."
        override val legalReadPrivacyBtn = "Read Privacy Policy"
        override val legalReadTermsBtn = "Read Terms and Conditions"
        override val legalReadRefundBtn = "Refund Policy"
        override val legalDataControllerTitle = "Data Controller:"
    }

    object FrenchStrings : Strings {
        override val appTitle = "Détecteur Téléphone"
        override val appSubtitle = "Retrouvez votre téléphone instantanément"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu paramètres"

        override val listeningActive = "ÉCOUTE ACTIVE"
        override val listeningPaused = "DÉTECTEUR EN PAUSE"
        override val tapToActivate = "Appuyer pour activer"
        override val sayPhrase = { phrase: String -> "Dites \"$phrase\"" }
        override val clapTwice = "Tapez 2 fois dans les mains"
        override val whistle = "Sifflez"
        override val heroListeningDesc = "Répondra immédiatement par lampe torche, vibration et volume progressif."
        override val heroPausedDesc = "Service en pause. Appuyez sur le bouton pour activer l'écoute."
        override val detectedVoice = { text: String -> "Détecté : \"$text\"" }
        override val micStatusCd = "État du microphone"

        override val micBlockedTitle = "Microphone bloqué sur Android"
        override val micBlockedDesc = "L'accès au micro est désactivé dans les paramètres rapides. Activez-le pour permettre l'écoute."

        override val slotsTitle = "Emplacements de Sons"
        override val slotsProSubtitle = "Plan PRO • Tout débloqué"
        override val slotsFreeSubtitle = "3 initiaux • Extensible jusqu'à 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupés" }
        override val slotsCurrentCapacity = { count: Int -> "Capacité actuelle : $count sons" }
        override val slotsMax = { max: Int -> "Maximum : $max" }
        override val exploreCatalogButton = "Explorer le catalogue d'effets sonores"
        override val watchAdToUnlockButton = { next: Int -> "Voir pub pour débloquer l'emplacement #$next" }

        override val soundsHeaderTitle = "Sons de réponse"
        override val soundsHeaderSubtitle = "Touchez pour choisir comment le téléphone répondra."
        override val defaultBeepsDesc = "Alerte aiguë • Double bip"
        override val defaultVoiceDesc = "Salut amical • \"Coucouuuu ! Je suis là, je suis là !\""
        override val customRecordingDesc = { sec: Int -> "Enregistrement personnel • ${sec}s" }
        override val playSoundCd = "Écouter"
        override val pauseSoundCd = "Pause"
        override val editNameCd = "Modifier le nom"
        override val deleteSoundCd = "Supprimer le son"
        override val newSoundFab = { cur: Int, max: Int -> "Nouveau son ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Son sélectionné : $name" }

        override val maxSlotsReached = "Limite maximale de 15 sons atteinte."
        override val removeAdsTitle = "Emplacements pleins"
        override val removeAdsDesc = "Tous les emplacements sont occupés. Débloquez-en plus avec une pub ou en version PRO."
        override val unlockWithAd = "Débloquer avec publicité"
        override val cancel = "Annuler"
        override val understood = "Compris"
        override val grantPermission = "Accorder l'autorisation"
        override val micPermissionTitle = "Autorisation micro requise"
        override val micPermissionDesc = "Pour détecter vos mains ou votre voix, l'application a besoin du micro."

        override val legalTermsTitle = "Conditions et Confidentialité"
        override val legalTermsWelcome = "Bienvenue sur Détecteur Téléphone"
        override val legalTermsDescription = "Pour utiliser l'application et activer l'écoute, vous devez lire et accepter nos conditions et politique de confidentialité."
        override val legalCheckboxPrivacy = "J'ai lu et j'accepte la Politique de Confidentialité (traitement 100% local)."
        override val legalCheckboxTerms = "J'accepte les Conditions Générales d'Utilisation."
        override val legalPrivacyHighlight = "🔒 Confidentialité garantie : Le son est traité uniquement dans la mémoire RAM. Aucun enregistrement n'est envoyé à des serveurs."
        override val legalAcceptAndContinue = "Accepter et accéder à l'app"
        override val legalViewPrivacyDoc = "Lire Politique de Confidentialité"
        override val legalViewTermsDoc = "Lire Conditions d'Utilisation"
        override val legalMustAcceptToEnter = "Vous devez cocher les deux cases pour entrer dans l'application."
        override val legalAppBlockedNotice = "L'accès reste bloqué tant que les conditions ne sont pas acceptées."

        override val closeDoc = "Fermer"

        override val settingsTitle = "Paramètres de l'application"
        override val settingsSubtitle = "Sélectionnez une catégorie"
        override val settingsCloseCd = "Fermer les paramètres"
        override val settingsBackCd = "Retour aux paramètres"
        override val close = "Fermer"
        override val statusConnected = "Connecté"
        override val statusSignIn = "Se connecter"
        override val statusSelected = "Sélectionné"

        override val settingsAccountTitle = "Compte et Synchronisation Cloud"
        override val settingsAccountSubtitle = "Sauvegarde cloud des achats, sons et paramètres"
        override val settingsDetectionTitle = "Détection et Déclencheurs"
        override val settingsDetectionSubtitle = "Mode voix, claquements, sifflement et mot-clé"
        override val settingsAlarmTitle = "Alarme et Réponse"
        override val settingsAlarmSubtitle = "Lampe torche, vibration et volume"
        override val settingsAppearanceTitle = "Apparence et Thème"
        override val settingsAppearanceSubtitle = "Thème sombre/clair et réinitialisation"
        override val settingsLanguageTitle = "Langue"
        override val settingsLanguageSubtitle = "Automatique, Français, Anglais, Espagnol..."
        override val settingsProTitle = "Plan PRO et Licence"
        override val settingsProSubtitle = "Supprimer les publicités et tout débloquer"
        override val settingsSupportTitle = "Support"
        override val settingsSupportSubtitle = "Serveur Discord officiel pour aide et retours"
        override val settingsLegalTitle = "Légal et Confidentialité"
        override val settingsLegalSubtitle = "Consulter les termes acceptés"

        override val detectionTriggerMethodTitle = "Méthode de déclenchement sonore"
        override val detectionTriggerMethodDesc = "Comment voulez-vous que le téléphone écoute et réponde ?"
        override val detectionModeVoice = "Mode voix"
        override val detectionModeClap = "2 Claquements"
        override val detectionModeWhistle = "Sifflement"
        override val detectionPhraseTitle = "Mot ou phrase pour le Mode voix"
        override val detectionPhraseDesc = "Tapez le mot à prononcer pour que le téléphone réponde (ex : \"Téléphone\", \"Où es-tu\")."
        override val detectionPhrasePlaceholder = "Ex : Téléphone"
        override val detectionSavePhrase = "Enregistrer"
        override val detectionPhraseSaved = "Enregistré"
        override val detectionSavePhraseCd = "Enregistrer le mot"
        override val detectionMicPrivacyTitle = "Alerte micro bloqué"
        override val detectionMicPrivacyDesc = "Vérifie si l'accès au micro Android est désactivé dans les réglages rapides."

        override val alarmTestButton = "Tester l'alarme (Son, Flash, Vibration)"
        override val alarmFlashPatternTitle = "Motif de lampe torche"
        override val alarmFlashFast = "Rapide"
        override val alarmFlashContinuous = "Continu"
        override val alarmVibrationTitle = "Vibration d'alerte"
        override val alarmVibrationLow = "Basse"
        override val alarmVibrationMedium = "Moyenne (Par défaut)"
        override val alarmVibrationHigh = "Forte"
        override val alarmVolumeInfo = "Volume progressif : 1ère fois à 50%, si répété dans les 30s monte à 75% puis 100%."
        override val alarmDndBypassTitle = "Sonner en Silencieux / Ne pas déranger"
        override val alarmDndBypassDesc = "Garantit que l'alarme sonne avec volume même si le téléphone est en silencieux."
        override val alarmBluetoothAlertTitle = "Alerte de déconnexion Bluetooth"
        override val alarmBluetoothAlertDesc = "Émet un bip et vibre si les écouteurs se déconnectent pendant la détection."

        override val appearanceThemeTitle = "Thème de l'application"
        override val appearanceDarkMode = "Mode Sombre actif"
        override val appearanceLightMode = "Mode Clair actif"
        override val appearanceLanguageQuick = "Langue"
        override val appearanceResetSoundsTitle = "Rétablir les sons originaux (\"Deux bips\" et \"Coucou ! Je suis là\")"

        override val languageAutoTitle = "Détection automatique active"
        override val languageAutoDesc = { detected: String -> "La langue s'adapte à celle de votre téléphone ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Fixé sur $native ($display)." }
        override val availableLanguages = "Langues disponibles"
        override val systemDefaultTag = "Par défaut"
        override val languageChangedToast = { lang: String -> "Langue sélectionnée : $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Détecté selon l'appareil : $native ($display)" }

        override val proActiveTitle = "Plan PRO Activé"
        override val proFreeTitle = "Version avec publicités"
        override val proActiveSubtitle = "Sans publicité • 15 emplacements • Audio jusqu'à 60s"
        override val proFreeSubtitle = "Supprimez les pubs et débloquez toutes les fonctions"
        override val proManageBtn = "Gérer"
        override val proRemoveAdsBtn = "Supprimer les pubs"
        override val proDiscordBtn = "Des questions sur votre achat ? Serveur Discord"

        override val accountLoggedInTitle = "Compte Lié"
        override val accountLoggedOutTitle = "Synchronisation Cloud"
        override val accountConnectedCloud = "Connecté au cloud"
        override val accountLoggedOutSubtitle = "Sauvegardez achats, sons et réglages"
        override val accountSyncDesc = "Votre compte Google synchronise automatiquement la licence PRO (Sans Pub), les emplacements débloqués, le catalogue de sons et vos réglages dans le cloud."
        override val accountSyncStatusPrefix = "État :"
        override val accountSignInGoogleBtn = "Se connecter avec Google"
        override val accountSyncActive = "Synchronisation automatique dans le cloud active"
        override val accountSyncing = "Synchronisation avec le cloud..."
        override val accountLogoutBtn = "Se Déconnecter"

        override val legalTransparencyTitle = "Transparence et Réglementation"
        override val legalTransparencySubtitle = "Conformité RGPD et Google Play"
        override val legalPrivacyHighlightText = "Votre vie privée est notre priorité : le microphone traite le son uniquement en mémoire locale. Aucune conversation n'est enregistrée ni envoyée à un serveur externe."
        override val legalReadPrivacyBtn = "Lire la Politique de Confidentialité"
        override val legalReadTermsBtn = "Lire les Conditions Générales"
        override val legalReadRefundBtn = "Politique de Remboursement"
        override val legalDataControllerTitle = "Responsable du traitement des données :"
    }

    object GermanStrings : Strings {
        override val appTitle = "Handy Finder Detektor"
        override val appSubtitle = "Finde dein Smartphone sofort wieder"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Einstellungsmenü"

        override val listeningActive = "ERKENNUNG AKTIV"
        override val listeningPaused = "DETEKTOR PAUSIERT"
        override val tapToActivate = "Tippen zum Aktivieren"
        override val sayPhrase = { phrase: String -> "Sage \"$phrase\"" }
        override val clapTwice = "2 Mal klatschen"
        override val whistle = "Pfeifen"
        override val heroListeningDesc = "Reagiert sofort mit Taschenlampe, Vibration und Lautstärke."
        override val heroPausedDesc = "Detektor im Ruhezustand. Tippen zum Starten."
        override val detectedVoice = { text: String -> "Erkannt: \"$text\"" }
        override val micStatusCd = "Mikrofonstatus"

        override val micBlockedTitle = "Mikrofon in Android blockiert"
        override val micBlockedDesc = "Der Mikrofonzugriff ist in den Schnelleinstellungen deaktiviert."

        override val slotsTitle = "Sound-Plätze"
        override val slotsProSubtitle = "PRO-Plan • Alle freigeschaltet"
        override val slotsFreeSubtitle = "3 Plätze • Erweiterbar bis 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max belegt" }
        override val slotsCurrentCapacity = { count: Int -> "Aktuelle Kapazität: $count Sounds" }
        override val slotsMax = { max: Int -> "Maximal: $max" }
        override val exploreCatalogButton = "Soundeffekte-Katalog durchsuchen"
        override val watchAdToUnlockButton = { next: Int -> "Kurzes Video ansehen für Platz #$next" }

        override val soundsHeaderTitle = "Antwort-Töne"
        override val soundsHeaderSubtitle = "Wähle aus, wie das Telefon antworten soll."
        override val defaultBeepsDesc = "Hoher Warnton • Doppelsignal"
        override val defaultVoiceDesc = "Fröhlicher Gruß • \"Halloooo! Hier bin ich, hier bin ich!\""
        override val customRecordingDesc = { sec: Int -> "Eigene Aufnahme • ${sec}s" }
        override val playSoundCd = "Abspielen"
        override val pauseSoundCd = "Pause"
        override val editNameCd = "Namen bearbeiten"
        override val deleteSoundCd = "Sound löschen"
        override val newSoundFab = { cur: Int, max: Int -> "Neuer Ton ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Ausgewählter Ton: $name" }

        override val maxSlotsReached = "Maximales Limit von 15 Tönen erreicht."
        override val removeAdsTitle = "Sound-Plätze voll"
        override val removeAdsDesc = "Schalte weitere Plätze durch kurze Werbung oder mit PRO frei."
        override val unlockWithAd = "Mit Video freischalten"
        override val cancel = "Abbrechen"
        override val understood = "Verstanden"
        override val grantPermission = "Berechtigung erteilen"
        override val micPermissionTitle = "Mikrofon-Berechtigung erforderlich"
        override val micPermissionDesc = "Um Klatschen oder Rufen zu erkennen, wird Mikrofonzugriff benötigt."

        override val legalTermsTitle = "Bedingungen & Datenschutz"
        override val legalTermsWelcome = "Willkommen bei Handy Finder Detektor"
        override val legalTermsDescription = "Um die App zu nutzen, müssen Sie die Nutzungsbedingungen und die Datenschutzerklärung akzeptieren."
        override val legalCheckboxPrivacy = "Ich akzeptiere die Datenschutzerklärung (100% lokale Audioverarbeitung)."
        override val legalCheckboxTerms = "Ich akzeptiere die Allgemeinen Geschäftsbedingungen."
        override val legalPrivacyHighlight = "🔒 Garantierter Datenschutz: Audio wird nur lokal im RAM verarbeitet. Es werden keine Daten übertragen."
        override val legalAcceptAndContinue = "Akzeptieren und fortfahren"
        override val legalViewPrivacyDoc = "Datenschutzerklärung lesen"
        override val legalViewTermsDoc = "Nutzungsbedingungen lesen"
        override val legalMustAcceptToEnter = "Sie müssen beide Optionen ankreuzen, um fortzufahren."
        override val legalAppBlockedNotice = "Der Zugriff bleibt gesperrt, bis die Bedingungen akzeptiert wurden."

        override val closeDoc = "Schließen"

        override val settingsTitle = "App-Einstellungen"
        override val settingsSubtitle = "Kategorie auswählen"
        override val settingsCloseCd = "Einstellungen schließen"
        override val settingsBackCd = "Zurück zu Einstellungen"
        override val close = "Schließen"
        override val statusConnected = "Verbunden"
        override val statusSignIn = "Anmelden"
        override val statusSelected = "Ausgewählt"

        override val settingsAccountTitle = "Konto & Cloud-Synchronisierung"
        override val settingsAccountSubtitle = "Cloud-Backup von Käufen, Tönen und Einstellungen"
        override val settingsDetectionTitle = "Erkennung & Auslöser"
        override val settingsDetectionSubtitle = "Sprachmodus, Klatschen, Pfeifen"
        override val settingsAlarmTitle = "Alarm & Reaktion"
        override val settingsAlarmSubtitle = "Taschenlampe, Vibration und Lautstärke"
        override val settingsAppearanceTitle = "Darstellung"
        override val settingsAppearanceSubtitle = "Dunkelmodus und Standardtöne"
        override val settingsLanguageTitle = "Sprache"
        override val settingsLanguageSubtitle = "Automatisch, Deutsch, Englisch..."
        override val settingsProTitle = "PRO-Plan & Lizenz"
        override val settingsProSubtitle = "Werbung entfernen und Vollversion"
        override val settingsSupportTitle = "Hilfe & Support"
        override val settingsSupportSubtitle = "Offizieller Discord-Server"
        override val settingsLegalTitle = "Rechtliches"
        override val settingsLegalSubtitle = "Bedingungen und Datenschutz einsehen"

        override val detectionTriggerMethodTitle = "Akustische Auslösemethode"
        override val detectionTriggerMethodDesc = "Wie soll das Handy auf Sie hören und antworten?"
        override val detectionModeVoice = "Sprachmodus"
        override val detectionModeClap = "2 Mal klatschen"
        override val detectionModeWhistle = "Pfeifen"
        override val detectionPhraseTitle = "Schlüsselwort für Sprachmodus"
        override val detectionPhraseDesc = "Geben Sie das Wort ein, auf das das Handy reagieren soll (z. B. \"Handy\", \"Such mich\")."
        override val detectionPhrasePlaceholder = "Z. B. Handy"
        override val detectionSavePhrase = "Speichern"
        override val detectionPhraseSaved = "Gespeichert"
        override val detectionSavePhraseCd = "Wort speichern"
        override val detectionMicPrivacyTitle = "Warnung: Mikrofon blockiert"
        override val detectionMicPrivacyDesc = "Prüft, ob der Mikrofonzugriff in den Android-Schnelleinstellungen deaktiviert ist."

        override val alarmTestButton = "Alarm testen (Ton, Taschenlampe, Vibration)"
        override val alarmFlashPatternTitle = "Taschenlampenmuster"
        override val alarmFlashFast = "Schnell"
        override val alarmFlashContinuous = "Dauerhaft"
        override val alarmVibrationTitle = "Alarm-Vibration"
        override val alarmVibrationLow = "Leicht"
        override val alarmVibrationMedium = "Mittel (Standard)"
        override val alarmVibrationHigh = "Stark"
        override val alarmVolumeInfo = "Skalierte Lautstärke: 1. Mal 50%, Wiederholung innerhalb von 30s steigt auf 75% und 100%."
        override val alarmDndBypassTitle = "Im Lautlosmodus / Nicht stören klingeln"
        override val alarmDndBypassDesc = "Garantiert lauten Alarm, auch wenn das Smartphone stummgeschaltet ist."
        override val alarmBluetoothAlertTitle = "Bluetooth-Trennungsalarm"
        override val alarmBluetoothAlertDesc = "Piept und vibriert, falls Kopfhörer bei aktiver Erkennung getrennt werden."

        override val appearanceThemeTitle = "App-Erscheinungsbild"
        override val appearanceDarkMode = "Dunkelmodus aktiv"
        override val appearanceLightMode = "Hellmodus aktiv"
        override val appearanceLanguageQuick = "Sprache"
        override val appearanceResetSoundsTitle = "Originaltöne wiederherstellen (\"Zwei Signaltöne\" und \"Hallo! Hier bin ich\")"

        override val languageAutoTitle = "Automatische Erkennung aktiv"
        override val languageAutoDesc = { detected: String -> "Passt sich der Gerätesprache an ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Festgelegt auf $native ($display)." }
        override val availableLanguages = "Verfügbare Sprachen"
        override val systemDefaultTag = "Standard"
        override val languageChangedToast = { lang: String -> "Sprache ausgewählt: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Vom Gerät erkannt: $native ($display)" }

        override val proActiveTitle = "PRO-Plan aktiviert"
        override val proFreeTitle = "Kostenlose Version (mit Werbung)"
        override val proActiveSubtitle = "Keine Werbung • 15 Sound-Plätze • Bis zu 60s Audio"
        override val proFreeSubtitle = "Werbung entfernen und alle Funktionen freischalten"
        override val proManageBtn = "Verwalten"
        override val proRemoveAdsBtn = "Werbung weg"
        override val proDiscordBtn = "Fragen zum Kauf? Discord-Server"

        override val accountLoggedInTitle = "Verknüpftes Konto"
        override val accountLoggedOutTitle = "Cloud-Synchronisierung"
        override val accountConnectedCloud = "Mit der Cloud verbunden"
        override val accountLoggedOutSubtitle = "Käufe, Töne und Einstellungen sichern"
        override val accountSyncDesc = "Ihr Google-Konto sichert automatisch die PRO-Lizenz, freigeschaltete Plätze, Töne und alle Einstellungen in der Cloud."
        override val accountSyncStatusPrefix = "Status:"
        override val accountSignInGoogleBtn = "Mit Google anmelden"
        override val accountSyncActive = "Automatische Cloud-Synchronisierung aktiv"
        override val accountSyncing = "Synchronisiere mit der Cloud..."
        override val accountLogoutBtn = "Abmelden"

        override val legalTransparencyTitle = "Transparenz und Rechtliches"
        override val legalTransparencySubtitle = "DSGVO- und Google Play-Konformität"
        override val legalPrivacyHighlightText = "Ihre Privatsphäre hat Priorität: Das Mikrofon verarbeitet Audio ausschließlich im lokalen Speicher. Es werden keine Gespräche aufgezeichnet oder an Server gesendet."
        override val legalReadPrivacyBtn = "Datenschutzerklärung lesen"
        override val legalReadTermsBtn = "Nutzungsbedingungen lesen"
        override val legalReadRefundBtn = "Erstattungsrichtlinien"
        override val legalDataControllerTitle = "Verantwortlicher für die Datenverarbeitung:"
    }

    object ItalianStrings : Strings {
        override val appTitle = "Trova Telefono"
        override val appSubtitle = "Trova il tuo telefono all'istante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu impostazioni"

        override val listeningActive = "ASCOLTO ATTIVO"
        override val listeningPaused = "RILEVATORE IN PAUSA"
        override val tapToActivate = "Tocca per attivare"
        override val sayPhrase = { phrase: String -> "Dì \"$phrase\"" }
        override val clapTwice = "Batti le mani 2 volte"
        override val whistle = "Fischia"
        override val heroListeningDesc = "Risponderà subito con torcia, vibrazione e volume intelligente."
        override val heroPausedDesc = "Servizio in pausa. Tocca per iniziare ad ascoltare."
        override val detectedVoice = { text: String -> "Rilevato: \"$text\"" }
        override val micStatusCd = "Stato microfono"

        override val micBlockedTitle = "Microfono disattivato su Android"
        override val micBlockedDesc = "L'accesso al microfono è disattivato nelle impostazioni rapide di sistema."

        override val slotsTitle = "Slot Suoni"
        override val slotsProSubtitle = "Piano PRO • Tutti sbloccati"
        override val slotsFreeSubtitle = "3 iniziali • Espandibile fino a 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max occupati" }
        override val slotsCurrentCapacity = { count: Int -> "Capacità attuale: $count suoni" }
        override val slotsMax = { max: Int -> "Massimo: $max" }
        override val exploreCatalogButton = "Esplora catalogo effetti sonori"
        override val watchAdToUnlockButton = { next: Int -> "Guarda breve annuncio per sbloccare slot #$next" }

        override val soundsHeaderTitle = "Suoni di risposta"
        override val soundsHeaderSubtitle = "Tocca per scegliere come risponderà il cellulare."
        override val defaultBeepsDesc = "Allarme acuto • Doppio beep"
        override val defaultVoiceDesc = "Saluto allegro • \"Ciaooo! Sono qui, sono qui!\""
        override val customRecordingDesc = { sec: Int -> "Registrazione propria • ${sec}s" }
        override val playSoundCd = "Ascolta"
        override val pauseSoundCd = "Pausa"
        override val editNameCd = "Modifica nome"
        override val deleteSoundCd = "Elimina suono"
        override val newSoundFab = { cur: Int, max: Int -> "Nuovo suono ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Suono selezionato: $name" }

        override val maxSlotsReached = "Raggiunto il limite massimo di 15 suoni."
        override val removeAdsTitle = "Slot pieni"
        override val removeAdsDesc = "Sblocca altri slot guardando una pubblicità o con il piano PRO."
        override val unlockWithAd = "Sblocca con annuncio"
        override val cancel = "Annulla"
        override val understood = "Ho capito"
        override val grantPermission = "Concedi permesso"
        override val micPermissionTitle = "Permesso microfono necessario"
        override val micPermissionDesc = "Per rilevare la tua voce, battiti o fischi, l'app ha bisogno del microfono."

        override val legalTermsTitle = "Termini e Privacy"
        override val legalTermsWelcome = "Benvenuto in Trova Telefono"
        override val legalTermsDescription = "Per usare l'applicazione è obbligatorio leggere e accettare i termini d'uso e l'informativa sulla privacy."
        override val legalCheckboxPrivacy = "Ho letto e accetto l'Informativa sulla Privacy (elaborazione audio 100% sul dispositivo)."
        override val legalCheckboxTerms = "Accetto i Termini e le Condizioni d'Uso."
        override val legalPrivacyHighlight = "🔒 Privacy garantita: L'audio viene elaborato esclusivamente nella RAM del dispositivo. Nessuna voce viene salvata o inviata a server."
        override val legalAcceptAndContinue = "Accetta ed entra nell'app"
        override val legalViewPrivacyDoc = "Leggi Informativa Privacy"
        override val legalViewTermsDoc = "Leggi Termini d'Uso"
        override val legalMustAcceptToEnter = "Devi selezionare entrambe le caselle per entrare nell'app."
        override val legalAppBlockedNotice = "L'accesso è bloccato finché non si accettano i termini legali."

        override val closeDoc = "Chiudi"

        override val settingsTitle = "Impostazioni applicazione"
        override val settingsSubtitle = "Seleziona una categoria"
        override val settingsCloseCd = "Chiudi impostazioni"
        override val settingsBackCd = "Torna a Impostazioni"
        override val close = "Chiudi"
        override val statusConnected = "Connesso"
        override val statusSignIn = "Accedi"
        override val statusSelected = "Selezionato"

        override val settingsAccountTitle = "Account e Sincronizzazione Cloud"
        override val settingsAccountSubtitle = "Backup sul cloud di acquisti, suoni e impostazioni"
        override val settingsDetectionTitle = "Rilevamento e Attivazione"
        override val settingsDetectionSubtitle = "Modalità voce, battito, fischio"
        override val settingsAlarmTitle = "Allarme e Risposta"
        override val settingsAlarmSubtitle = "Torcia, vibrazione e volume"
        override val settingsAppearanceTitle = "Aspetto e Tema"
        override val settingsAppearanceSubtitle = "Tema chiaro/scuro"
        override val settingsLanguageTitle = "Lingua"
        override val settingsLanguageSubtitle = "Automatico, Italiano, Spagnolo, Inglese..."
        override val settingsProTitle = "Piano PRO e Licenza"
        override val settingsProSubtitle = "Rimuovi annunci e sblocca tutto"
        override val settingsSupportTitle = "Supporto"
        override val settingsSupportSubtitle = "Server Discord ufficiale per aiuto"
        override val settingsLegalTitle = "Legale e Privacy"
        override val settingsLegalSubtitle = "Visualizza termini e condizioni"

        override val detectionTriggerMethodTitle = "Metodo di attivazione sonora"
        override val detectionTriggerMethodDesc = "Come vuoi che il telefono ascolti e risponda?"
        override val detectionModeVoice = "Modalità voce"
        override val detectionModeClap = "2 Battiti"
        override val detectionModeWhistle = "Fischio"
        override val detectionPhraseTitle = "Parola o frase per la Modalità voce"
        override val detectionPhraseDesc = "Scrivi la parola da pronunciare per far rispondere il telefono (es: \"Telefono\", \"Dove sei\")."
        override val detectionPhrasePlaceholder = "Es: Telefono"
        override val detectionSavePhrase = "Salva"
        override val detectionPhraseSaved = "Salvato"
        override val detectionSavePhraseCd = "Salva parola"
        override val detectionMicPrivacyTitle = "Avviso microfono bloccato"
        override val detectionMicPrivacyDesc = "Controlla se l'accesso al microfono Android è disattivato nelle impostazioni rapide."

        override val alarmTestButton = "Prova allarme (Suono, Torcia, Vibrazione)"
        override val alarmFlashPatternTitle = "Pattern torcia"
        override val alarmFlashFast = "Veloce"
        override val alarmFlashContinuous = "Continuo"
        override val alarmVibrationTitle = "Vibrazione di avviso"
        override val alarmVibrationLow = "Bassa"
        override val alarmVibrationMedium = "Media (Predefinita)"
        override val alarmVibrationHigh = "Alta"
        override val alarmVolumeInfo = "Volume scalare: 1ª volta al 50%, se ripeti entro 30s sale al 75% e poi al 100%."
        override val alarmDndBypassTitle = "Suona in Silenzioso / Non disturbare"
        override val alarmDndBypassDesc = "Garantisce che l'allarme suoni con volume anche con il telefono in silenzioso."
        override val alarmBluetoothAlertTitle = "Avviso disconnessione Bluetooth"
        override val alarmBluetoothAlertDesc = "Emette un beep e vibra se gli auricolari si collegano/scollegano con il rilevatore attivo."

        override val appearanceThemeTitle = "Tema dell'applicazione"
        override val appearanceDarkMode = "Modalità Scura attiva"
        override val appearanceLightMode = "Modalità Chiara attiva"
        override val appearanceLanguageQuick = "Lingua"
        override val appearanceResetSoundsTitle = "Ripristina suoni originali (\"Due bip\" e \"Ciao! Sono qui\")"

        override val languageAutoTitle = "Rilevamento automatico attivo"
        override val languageAutoDesc = { detected: String -> "La lingua corrisponde a quella del dispositivo ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Impostato su $native ($display)." }
        override val availableLanguages = "Lingue disponibili"
        override val systemDefaultTag = "Predefinito"
        override val languageChangedToast = { lang: String -> "Lingua selezionata: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Rilevato dal dispositivo: $native ($display)" }

        override val proActiveTitle = "Piano PRO Attivo"
        override val proFreeTitle = "Versione con annunci"
        override val proActiveSubtitle = "Senza pubblicità • 15 slot sonori • Audio fino a 60s"
        override val proFreeSubtitle = "Rimuovi gli annunci e sblocca tutte le funzionalità"
        override val proManageBtn = "Gestisci"
        override val proRemoveAdsBtn = "Rimuovi Ads"
        override val proDiscordBtn = "Dubbi sul tuo acquisto? Server Discord"

        override val accountLoggedInTitle = "Account Collegato"
        override val accountLoggedOutTitle = "Sincronizzazione Cloud"
        override val accountConnectedCloud = "Connesso al cloud"
        override val accountLoggedOutSubtitle = "Salva acquisti, suoni e impostazioni"
        override val accountSyncDesc = "Il tuo account Google sincronizza automaticamente la licenza PRO (Senza Pubblicità), gli slot sbloccati, il catalogo suoni e le impostazioni nel cloud."
        override val accountSyncStatusPrefix = "Stato:"
        override val accountSignInGoogleBtn = "Accedi con Google"
        override val accountSyncActive = "Sincronizzazione automatica nel cloud attiva"
        override val accountSyncing = "Sincronizzazione con il cloud in corso..."
        override val accountLogoutBtn = "Disconnetti"

        override val legalTransparencyTitle = "Trasparenza e Normativa"
        override val legalTransparencySubtitle = "Conformità GDPR e Google Play"
        override val legalPrivacyHighlightText = "La tua privacy è fondamentale: il microfono elabora il suono esclusivamente nella memoria locale. Nessuna conversazione viene registrata o inviata a server esterni."
        override val legalReadPrivacyBtn = "Leggi Informativa sulla Privacy"
        override val legalReadTermsBtn = "Leggi Termini e Condizioni"
        override val legalReadRefundBtn = "Politica di Rimborso"
        override val legalDataControllerTitle = "Titolare del trattamento dei dati:"
    }

    object PortugueseStrings : Strings {
        override val appTitle = "Localizador de Telemóvel"
        override val appSubtitle = "Encontra o teu telemóvel num instante"
        override val proBadge = "PRO"
        override val settingsMenuCd = "Menu de definições"

        override val listeningActive = "ESCUTA ATIVA"
        override val listeningPaused = "DETETOR EM PAUSA"
        override val tapToActivate = "Toca para ativar"
        override val sayPhrase = { phrase: String -> "Diz \"$phrase\"" }
        override val clapTwice = "Bate 2 palmas seguidas"
        override val whistle = "Assobia"
        override val heroListeningDesc = "Responderá de imediato com lanterna, vibração e volume progressivo."
        override val heroPausedDesc = "Serviço em pausa. Toca para ativar a escuta em segundo plano."
        override val detectedVoice = { text: String -> "Detetado: \"$text\"" }
        override val micStatusCd = "Estado do microfone"

        override val micBlockedTitle = "Microfone bloqueado no Android"
        override val micBlockedDesc = "O microfone está desativado nas definições rápidas do sistema."

        override val slotsTitle = "Espaços de Sons"
        override val slotsProSubtitle = "Plano PRO • Todos desbloqueados"
        override val slotsFreeSubtitle = "3 iniciais • Expansível até 15"
        override val slotsOccupied = { cur: Int, max: Int -> "$cur / $max ocupados" }
        override val slotsCurrentCapacity = { count: Int -> "Capacidade atual: $count sons" }
        override val slotsMax = { max: Int -> "Máximo: $max" }
        override val exploreCatalogButton = "Explorar catálogo de efeitos sonoros"
        override val watchAdToUnlockButton = { next: Int -> "Ver anúncio para desbloquear espaço #$next" }

        override val soundsHeaderTitle = "Sons de resposta"
        override val soundsHeaderSubtitle = "Toca para escolher como o telemóvel irá responder."
        override val defaultBeepsDesc = "Alerta agudo • Duplo bip"
        override val defaultVoiceDesc = "Saudação alegre • \"Oláaaa! Estou aqui, estou aqui!\""
        override val customRecordingDesc = { sec: Int -> "Gravação própria • ${sec}s" }
        override val playSoundCd = "Ouvir som"
        override val pauseSoundCd = "Pausar som"
        override val editNameCd = "Editar nome"
        override val deleteSoundCd = "Eliminar som"
        override val newSoundFab = { cur: Int, max: Int -> "Novo som ($cur/$max)" }
        override val soundSelectedSnackbar = { name: String -> "Som selecionado: $name" }

        override val maxSlotsReached = "Atingiste o limite máximo de 15 sons."
        override val removeAdsTitle = "Espaços cheios"
        override val removeAdsDesc = "Desbloqueia mais espaços vendo um anúncio ou atualizando para PRO."
        override val unlockWithAd = "Desbloquear com anúncio"
        override val cancel = "Cancelar"
        override val understood = "Entendido"
        override val grantPermission = "Conceder permissão"
        override val micPermissionTitle = "Permissão de microfone necessária"
        override val micPermissionDesc = "Para detetar a tua voz, palmas ou assobios, a app precisa do microfone."

        override val legalTermsTitle = "Termos e Privacidade"
        override val legalTermsWelcome = "Bem-vindo ao Localizador de Telemóvel"
        override val legalTermsDescription = "Para utilizar a aplicação, é obrigatório ler e aceitar as condições de utilização e a política de privacidade."
        override val legalCheckboxPrivacy = "Li e aceito a Política de Privacidade (processamento de áudio 100% no dispositivo)."
        override val legalCheckboxTerms = "Aceito os Termos e Condições de Utilização."
        override val legalPrivacyHighlight = "🔒 Privacidade garantida: O áudio é processado de forma efémera na memória do telemóvel. Nenhuma conversa é enviada para servidores."
        override val legalAcceptAndContinue = "Aceitar e entrar na app"
        override val legalViewPrivacyDoc = "Ler Política de Privacidade"
        override val legalViewTermsDoc = "Ler Termos e Condições"
        override val legalMustAcceptToEnter = "Deves marcar ambas as caixas para aceder à aplicação."
        override val legalAppBlockedNotice = "O acesso permanece bloqueado até aceitares os termos legais."

        override val closeDoc = "Fechar"

        override val settingsTitle = "Definições da aplicação"
        override val settingsSubtitle = "Seleciona uma categoria"
        override val settingsCloseCd = "Fechar definições"
        override val settingsBackCd = "Voltar às Definições"
        override val close = "Fechar"
        override val statusConnected = "Ligado"
        override val statusSignIn = "Iniciar sessão"
        override val statusSelected = "Selecionado"

        override val settingsAccountTitle = "Conta e Sincronização na Nuvem"
        override val settingsAccountSubtitle = "Cópia na nuvem de compras, sons e definições"
        override val settingsDetectionTitle = "Deteção e Ativação"
        override val settingsDetectionSubtitle = "Modo voz, palmas, assobio e palavra-chave"
        override val settingsAlarmTitle = "Alarme e Resposta"
        override val settingsAlarmSubtitle = "Lanterna, vibração e volume"
        override val settingsAppearanceTitle = "Aparência e Ecrã"
        override val settingsAppearanceSubtitle = "Tema claro/escuro"
        override val settingsLanguageTitle = "Idioma"
        override val settingsLanguageSubtitle = "Automático, Português, Espanhol, Inglês..."
        override val settingsProTitle = "Plano PRO e Licença"
        override val settingsProSubtitle = "Remover anúncios e funcionalidades totais"
        override val settingsSupportTitle = "Suporte"
        override val settingsSupportSubtitle = "Servidor oficial do Discord para ajuda"
        override val settingsLegalTitle = "Legal e Privacidade"
        override val settingsLegalSubtitle = "Consultar termos aceites"

        override val detectionTriggerMethodTitle = "Método de ativação sonora"
        override val detectionTriggerMethodDesc = "Como queres que o telemóvel te oiça e responda?"
        override val detectionModeVoice = "Modo voz"
        override val detectionModeClap = "2 Palmas"
        override val detectionModeWhistle = "Assobio"
        override val detectionPhraseTitle = "Palavra ou frase para o Modo voz"
        override val detectionPhraseDesc = "Escreve a palavra que queres dizer para o telemóvel responder (ex: \"Telemóvel\", \"Procurar\")."
        override val detectionPhrasePlaceholder = "Ex: Telemóvel"
        override val detectionSavePhrase = "Guardar"
        override val detectionPhraseSaved = "Guardado"
        override val detectionSavePhraseCd = "Guardar palavra"
        override val detectionMicPrivacyTitle = "Aviso de microfone bloqueado"
        override val detectionMicPrivacyDesc = "Verifica se o acesso ao microfone do Android está desligado nas definições rápidas."

        override val alarmTestButton = "Testar alarme (Som, Lanterna, Vibração)"
        override val alarmFlashPatternTitle = "Padrão de lanterna"
        override val alarmFlashFast = "Rápido"
        override val alarmFlashContinuous = "Contínuo"
        override val alarmVibrationTitle = "Vibração de alerta"
        override val alarmVibrationLow = "Baixa"
        override val alarmVibrationMedium = "Média (Predefinida)"
        override val alarmVibrationHigh = "Alta"
        override val alarmVolumeInfo = "Volume progressivo: 1ª vez a 50%, se repetires em <30s sobe para 75% e depois 100%."
        override val alarmDndBypassTitle = "Tocar em Silêncio / Não Incomodar"
        override val alarmDndBypassDesc = "Garante que o alarme toca com volume mesmo que o telemóvel esteja em silêncio."
        override val alarmBluetoothAlertTitle = "Aviso por desconexão Bluetooth"
        override val alarmBluetoothAlertDesc = "Emite um aviso sonoro e vibra se os auriculares se desconectarem com o detetor ativo."

        override val appearanceThemeTitle = "Tema da aplicação"
        override val appearanceDarkMode = "Modo Escuro ativo"
        override val appearanceLightMode = "Modo Claro ativo"
        override val appearanceLanguageQuick = "Idioma"
        override val appearanceResetSoundsTitle = "Restaurar sons originais (\"Dois bipes\" e \"Olá! Estou aqui\")"

        override val languageAutoTitle = "Deteção automática ativa"
        override val languageAutoDesc = { detected: String -> "O idioma adapta-se ao do teu telemóvel ($detected)." }
        override val languageFixedDesc = { native: String, display: String -> "Definido para $native ($display)." }
        override val availableLanguages = "Idiomas disponíveis"
        override val systemDefaultTag = "Predefinido"
        override val languageChangedToast = { lang: String -> "Idioma selecionado: $lang" }
        override val languageAutoDevice = { native: String, display: String -> "Detetado a partir do dispositivo: $native ($display)" }

        override val proActiveTitle = "Plano PRO Ativado"
        override val proFreeTitle = "Versão com anúncios"
        override val proActiveSubtitle = "Sem anúncios • 15 espaços sonoros • Áudio até 60s"
        override val proFreeSubtitle = "Remove anúncios e desbloqueia todas as funcionalidades"
        override val proManageBtn = "Gerir"
        override val proRemoveAdsBtn = "Remover Ads"
        override val proDiscordBtn = "Dúvidas sobre a tua compra? Servidor do Discord"

        override val accountLoggedInTitle = "Conta Vinculada"
        override val accountLoggedOutTitle = "Sincronização na Nuvem"
        override val accountConnectedCloud = "Ligado à nuvem"
        override val accountLoggedOutSubtitle = "Guarda compras, sons e definições"
        override val accountSyncDesc = "A tua conta Google sincroniza automaticamente a licença PRO (Sem Anúncios), os espaços desbloqueados, o catálogo de sons e as tuas definições na nuvem."
        override val accountSyncStatusPrefix = "Estado:"
        override val accountSignInGoogleBtn = "Iniciar sessão com o Google"
        override val accountSyncActive = "Sincronização automática na nuvem ativa"
        override val accountSyncing = "A sincronizar com a nuvem..."
        override val accountLogoutBtn = "Terminar Sessão"

        override val legalTransparencyTitle = "Transparência e Normas"
        override val legalTransparencySubtitle = "Conformidade com RGPD e Google Play"
        override val legalPrivacyHighlightText = "A tua privacidade é prioridade: o microfone processa o som exclusivamente na memória local do telemóvel. Não gravamos conversas nem transmitimos dados para servidores externos."
        override val legalReadPrivacyBtn = "Ler Política de Privacidade"
        override val legalReadTermsBtn = "Ler Termos e Condições"
        override val legalReadRefundBtn = "Política de Reembolsos"
        override val legalDataControllerTitle = "Responsável pelo tratamento de dados:"
    }
}

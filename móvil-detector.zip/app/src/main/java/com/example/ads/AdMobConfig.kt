package com.example.ads

/**
 * Identificadores oficiales de Google AdMob configurados para Móvil Detector.
 */
object AdMobConfig {
    /** App ID de la aplicación en Google AdMob */
    const val APP_ID = "ca-app-pub-8632805534978950~8754325043"

    /** Bloques de Anuncio Reales de tu cuenta de AdMob */
    const val REAL_BANNER_AD_UNIT_ID = "ca-app-pub-8632805534978950/6967279270"
    const val REAL_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-8632805534978950/8031385838"
    const val REAL_REWARDED_AD_UNIT_ID = "ca-app-pub-8632805534978950/8030903332"

    /**
     * IDs oficiales de prueba de Google AdMob.
     * Google los utiliza mientras las cuentas/bloques nuevos se propagan en sus servidores
     * (los bloques nuevos pueden tardar hasta 24h en recibir inventario comercial real).
     */
    const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
}

package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Gestor centralizado para la carga y visualización de anuncios Intersticiales y Bonificados de AdMob.
 * Incluye tolerancia a fallos: utiliza prioritariamente los bloques de anuncios reales del usuario
 * (de su cuenta AdMob), y si Google aún no tiene inventario activo (código 3 No Fill en bloques nuevos),
 * recurre al bloque de pruebas oficial de AdMob para que los anuncios siempre funcionen en pruebas/emulador.
 */
object AdMobManager {
    private const val TAG = "AdMobManager"

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    fun isInterstitialReady(): Boolean = interstitialAd != null

    fun isRewardedReady(): Boolean = rewardedAd != null

    /**
     * Precarga un anuncio intersticial (cada 5 minutos).
     */
    fun loadInterstitial(context: Context, onLoaded: (() -> Unit)? = null) {
        if (interstitialAd != null) {
            onLoaded?.invoke()
            return
        }
        if (isInterstitialLoading) return
        isInterstitialLoading = true

        val appContext = context.applicationContext
        val adUnitId = AdMobConfig.REAL_INTERSTITIAL_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            appContext,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Anuncio Intersticial real cargado con éxito ($adUnitId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isInterstitialLoading = false
                    Log.w(TAG, "Intersticial real no listo aún ($adUnitId): ${error.message} (Código ${error.code}). Conmutando al bloque de prueba oficial...")
                    // Fallback automático al ID de prueba oficial de AdMob
                    loadInterstitialFallback(appContext, onLoaded)
                }
            }
        )
    }

    private fun loadInterstitialFallback(context: Context, onLoaded: (() -> Unit)? = null) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        val appContext = context.applicationContext
        val fallbackId = AdMobConfig.TEST_INTERSTITIAL_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            appContext,
            fallbackId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Anuncio Intersticial de respaldo AdMob cargado con éxito ($fallbackId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.e(TAG, "Fallo al cargar Intersticial de respaldo: ${error.message} (Código ${error.code})")
                }
            }
        )
    }

    /**
     * Muestra el anuncio intersticial si está listo.
     */
    fun showInterstitial(activity: Activity, onAdFinished: () -> Unit): Boolean {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdFinished()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onAdFinished()
                }
            }
            ad.show(activity)
            return true
        } else {
            loadInterstitial(activity)
            onAdFinished()
            return false
        }
    }

    /**
     * Precarga un anuncio bonificado (para desbloquear slots de sonido).
     */
    fun loadRewarded(context: Context, onLoaded: (() -> Unit)? = null) {
        if (rewardedAd != null) {
            onLoaded?.invoke()
            return
        }
        if (isRewardedLoading) return
        isRewardedLoading = true

        val appContext = context.applicationContext
        val adUnitId = AdMobConfig.REAL_REWARDED_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            appContext,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Anuncio Bonificado real cargado con éxito ($adUnitId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isRewardedLoading = false
                    Log.w(TAG, "Bonificado real no listo aún ($adUnitId): ${error.message} (Código ${error.code}). Conmutando al bloque de prueba oficial...")
                    // Fallback automático al ID de prueba oficial de AdMob
                    loadRewardedFallback(appContext, onLoaded)
                }
            }
        )
    }

    private fun loadRewardedFallback(context: Context, onLoaded: (() -> Unit)? = null) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        val appContext = context.applicationContext
        val fallbackId = AdMobConfig.TEST_REWARDED_AD_UNIT_ID
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            appContext,
            fallbackId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Anuncio Bonificado de respaldo AdMob cargado con éxito ($fallbackId)")
                    onLoaded?.invoke()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.e(TAG, "Fallo al cargar Bonificado de respaldo: ${error.message} (Código ${error.code})")
                }
            }
        )
    }

    /**
     * Muestra el anuncio bonificado si está listo.
     */
    fun showRewarded(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdDismissed: () -> Unit
    ): Boolean {
        val ad = rewardedAd
        if (ad != null) {
            var rewardGranted = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    if (rewardGranted) {
                        onRewardEarned()
                    }
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onAdDismissed()
                }
            }

            ad.show(activity) { _ ->
                rewardGranted = true
            }
            return true
        } else {
            loadRewarded(activity)
            return false
        }
    }

    /**
     * Muestra el anuncio bonificado si ya está cargado, o lo solicita de inmediato
     * y lo muestra tan pronto termine de cargar.
     */
    fun showRewardedWithAutoLoad(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdDismissed: () -> Unit,
        onAdUnavailable: () -> Unit
    ) {
        if (rewardedAd != null) {
            showRewarded(activity, onRewardEarned, onAdDismissed)
        } else {
            loadRewarded(activity) {
                if (rewardedAd != null) {
                    showRewarded(activity, onRewardEarned, onAdDismissed)
                } else {
                    onAdUnavailable()
                }
            }
        }
    }
}

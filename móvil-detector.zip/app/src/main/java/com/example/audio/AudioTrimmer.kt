package com.example.audio

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

/**
 * Utilidad para recortar silencios del principio y del final de audios grabados o importados.
 * Permite reproducir fragmentos específicos durante la edición visual y guardar el resultado
 * recortado de forma eficiente.
 */
object AudioTrimmer {
    private const val TAG = "AudioTrimmer"

    /**
     * Recorta un archivo multimedia desde [startSec] hasta [endSec] usando MediaExtractor y MediaMuxer.
     * Retorna la ruta absoluta del nuevo archivo recortado o null si ocurre algún error.
     */
    fun trimAudio(
        context: Context,
        inputFilePath: String,
        startSec: Float,
        endSec: Float
    ): String? {
        val inputFile = File(inputFilePath)
        if (!inputFile.exists() || inputFile.length() == 0L) {
            Log.e(TAG, "Input file does not exist: $inputFilePath")
            return null
        }

        val soundsDir = File(context.filesDir, "trimmed_sounds")
        if (!soundsDir.exists()) soundsDir.mkdirs()

        val extension = inputFile.extension.ifBlank { "m4a" }
        val outputFile = File(soundsDir, "trimmed_${System.currentTimeMillis()}.$extension")

        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            extractor.setDataSource(inputFile.absolutePath)
            var audioTrackIndex = -1
            var format: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val trackFormat = extractor.getTrackFormat(i)
                val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    format = trackFormat
                    break
                }
            }

            if (audioTrackIndex == -1 || format == null) {
                Log.e(TAG, "No audio track found in file")
                extractor.release()
                return null
            }

            extractor.selectTrack(audioTrackIndex)

            val outputFormat = if (extension.equals("mp4", ignoreCase = true) || extension.equals("m4a", ignoreCase = true)) {
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            } else {
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            }

            muxer = MediaMuxer(outputFile.absolutePath, outputFormat)
            val muxerAudioTrack = muxer.addTrack(format)
            muxer.start()

            val startUs = (startSec * 1_000_000L).toLong()
            val endUs = (endSec * 1_000_000L).toLong()

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val maxBufferSize = try {
                format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } catch (_: Exception) {
                256 * 1024
            }.coerceAtLeast(64 * 1024)

            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = android.media.MediaCodec.BufferInfo()

            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                val sampleTime = extractor.sampleTime
                if (sampleTime > endUs) break

                if (sampleTime >= startUs) {
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = sampleTime - startUs
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                }

                extractor.advance()
            }

            return outputFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error trimming audio file, fallback to direct copy or original", e)
            return null
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {}
            try {
                muxer?.stop()
            } catch (_: Exception) {}
            try {
                muxer?.release()
            } catch (_: Exception) {}
        }
    }
}

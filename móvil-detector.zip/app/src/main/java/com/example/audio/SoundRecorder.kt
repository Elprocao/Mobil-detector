package com.example.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class SoundRecorder(private val context: Context) {
    private val TAG = "SoundRecorder"
    private var mediaRecorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var recordingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _elapsedSeconds = MutableStateFlow(0f)
    val elapsedSeconds: StateFlow<Float> = _elapsedSeconds.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    var onMaxDurationReached: (() -> Unit)? = null

    /**
     * Inicia la grabación con una duración máxima dada en segundos (25s por defecto, 60s con Premium).
     */
    fun startRecording(maxDurationSeconds: Int = 25): Boolean {
        if (_isRecording.value) return false

        try {
            val soundsDir = File(context.filesDir, "custom_sounds")
            if (!soundsDir.exists()) {
                soundsDir.mkdirs()
            }

            val fileName = "sound_${System.currentTimeMillis()}.m4a"
            currentFile = File(soundsDir, fileName)

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            val maxDurationMs = (maxDurationSeconds * 1000) + 500

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(currentFile?.absolutePath)
                setMaxDuration(maxDurationMs)
                setOnInfoListener { _, what, _ ->
                    if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                        onMaxDurationReached?.invoke()
                    }
                }
                prepare()
                start()
            }

            mediaRecorder = recorder
            _isRecording.value = true
            _elapsedSeconds.value = 0f

            recordingJob = scope.launch {
                val startTime = System.currentTimeMillis()
                val maxDurationFloat = maxDurationSeconds.toFloat()
                while (isActive && _isRecording.value) {
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000f
                    _elapsedSeconds.value = elapsed.coerceAtMost(maxDurationFloat)

                    try {
                        val maxAmp = mediaRecorder?.maxAmplitude ?: 0
                        // Normalize amplitude (0 to 32767)
                        val norm = (maxAmp / 32767f).coerceIn(0f, 1f)
                        _amplitude.value = norm
                    } catch (_: Exception) {}

                    if (elapsed >= maxDurationFloat) {
                        onMaxDurationReached?.invoke()
                        break
                    }
                    delay(100)
                }
            }

            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording", e)
            cleanup()
            return false
        }
    }

    fun stopRecording(): String? {
        if (!_isRecording.value) return null
        recordingJob?.cancel()
        recordingJob = null
        _isRecording.value = false

        try {
            mediaRecorder?.let {
                it.stop()
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recorder", e)
        }
        mediaRecorder = null

        val path = currentFile?.takeIf { it.exists() && it.length() > 0 }?.absolutePath
        _amplitude.value = 0f
        return path
    }

    fun cancelRecording() {
        recordingJob?.cancel()
        recordingJob = null
        _isRecording.value = false
        try {
            mediaRecorder?.let {
                it.stop()
                it.release()
            }
        } catch (_: Exception) {}
        mediaRecorder = null
        try {
            currentFile?.let {
                if (it.exists()) it.delete()
            }
        } catch (_: Exception) {}
        currentFile = null
        _elapsedSeconds.value = 0f
        _amplitude.value = 0f
    }

    private fun cleanup() {
        recordingJob?.cancel()
        recordingJob = null
        _isRecording.value = false
        try {
            mediaRecorder?.release()
        } catch (_: Exception) {}
        mediaRecorder = null
        _amplitude.value = 0f
    }
}

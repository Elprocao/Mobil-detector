package com.example.data.supabase

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.AppLanguage
import com.example.data.model.SoundEntity
import com.example.data.model.SoundType
import com.example.hardware.FlashPattern
import com.example.hardware.VibrationIntensity
import com.example.service.TriggerMode
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * Gestor oficial de sincronización con Supabase.
 * Conexión REST directa con la API de Supabase (PostgREST) usando la Publishable Key y OkHttp/Moshi.
 */
class SupabaseManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "SupabaseManager"
        const val SUPABASE_URL = "https://rqnsjxvvobvznlhyatdd.supabase.co"
        const val SUPABASE_KEY = "sb_publishable_aiVkVoqR6m7xulRpWR5RpQ_FuGAFwm9"

        private const val PREFS_NAME = "supabase_auth_prefs"
        private const val KEY_USER_ID = "sb_user_id"
        private const val KEY_USER_EMAIL = "sb_user_email"
        private const val KEY_USER_NAME = "sb_user_name"
        private const val KEY_USER_AVATAR = "sb_user_avatar"
        private const val KEY_LAST_SYNC_TIME = "sb_last_sync_time"

        @Volatile
        private var INSTANCE: SupabaseManager? = null

        fun getInstance(context: Context): SupabaseManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SupabaseManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val profileAdapter = moshi.adapter(UserProfileSync::class.java)
    private val profileListAdapter = moshi.adapter<List<UserProfileSync>>(
        Types.newParameterizedType(List::class.java, UserProfileSync::class.java)
    )
    private val soundListAdapter = moshi.adapter<List<SoundItemSync>>(
        Types.newParameterizedType(List::class.java, SoundItemSync::class.java)
    )

    private val _currentUserId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    private val _currentUserEmail = MutableStateFlow<String?>(prefs.getString(KEY_USER_EMAIL, null))
    val currentUserEmail: StateFlow<String?> = _currentUserEmail.asStateFlow()

    private val _currentUserName = MutableStateFlow<String?>(prefs.getString(KEY_USER_NAME, null))
    val currentUserName: StateFlow<String?> = _currentUserName.asStateFlow()

    private val _currentUserAvatar = MutableStateFlow<String?>(prefs.getString(KEY_USER_AVATAR, null))
    val currentUserAvatar: StateFlow<String?> = _currentUserAvatar.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncStatus = MutableStateFlow<String?>(null)
    val lastSyncStatus: StateFlow<String?> = _lastSyncStatus.asStateFlow()

    val isLoggedIn: Boolean
        get() = !_currentUserId.value.isNullOrBlank()

    /**
     * Guarda la sesión tras el login con Google
     */
    fun saveUserSession(userId: String, email: String, displayName: String?, avatarUrl: String?) {
        prefs.edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_USER_NAME, displayName)
            .putString(KEY_USER_AVATAR, avatarUrl)
            .apply()

        _currentUserId.value = userId
        _currentUserEmail.value = email
        _currentUserName.value = displayName
        _currentUserAvatar.value = avatarUrl
    }

    /**
     * Cierra la sesión
     */
    fun logout() {
        prefs.edit()
            .remove(KEY_USER_ID)
            .remove(KEY_USER_EMAIL)
            .remove(KEY_USER_NAME)
            .remove(KEY_USER_AVATAR)
            .remove(KEY_LAST_SYNC_TIME)
            .apply()

        _currentUserId.value = null
        _currentUserEmail.value = null
        _currentUserName.value = null
        _currentUserAvatar.value = null
        _lastSyncStatus.value = null
    }

    private fun getCurrentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    /**
     * Sube las compras, todos los ajustes y los sonidos a Supabase.
     */
    suspend fun uploadUserDataToSupabase(
        adsRemoved: Boolean,
        unlockedSlots: Int,
        triggerMode: TriggerMode,
        customTriggerPhrase: String,
        vibrationIntensity: VibrationIntensity,
        flashPattern: FlashPattern,
        dndBypass: Boolean,
        bluetoothAlert: Boolean,
        isDarkMode: Boolean,
        appLanguage: AppLanguage,
        selectedSoundName: String?,
        sounds: List<SoundEntity>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("No hay sesión activa"))
        val email = _currentUserEmail.value ?: "user@google.com"

        try {
            _isSyncing.value = true
            _lastSyncStatus.value = "Sincronizando con la nube..."

            val now = getCurrentIsoTimestamp()
            val profile = UserProfileSync(
                userId = userId,
                email = email,
                displayName = _currentUserName.value,
                avatarUrl = _currentUserAvatar.value,
                adsRemoved = adsRemoved,
                unlockedSlots = unlockedSlots,
                triggerMode = triggerMode.id,
                customTriggerPhrase = customTriggerPhrase,
                vibrationIntensity = vibrationIntensity.id,
                flashPattern = flashPattern.id,
                dndBypass = dndBypass,
                bluetoothAlert = bluetoothAlert,
                isDarkMode = isDarkMode,
                appLanguage = appLanguage.code,
                selectedSoundName = selectedSoundName,
                updatedAt = now
            )

            // 1. Guardar / actualizar perfil y configuraciones en la tabla 'user_profiles'
            val profileJson = profileAdapter.toJson(profile)
            val profileBody = profileJson.toRequestBody("application/json; charset=utf-8".toMediaType())

            val upsertProfileRequest = Request.Builder()
                .url("$SUPABASE_URL/rest/v1/user_profiles?on_conflict=user_id")
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer $SUPABASE_KEY")
                .header("Prefer", "resolution=merge-duplicates,return=representation")
                .header("Content-Type", "application/json")
                .post(profileBody)
                .build()

            client.newCall(upsertProfileRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string()
                    Log.w(TAG, "Error subiendo perfil a Supabase: ${response.code} $err")
                } else {
                    Log.d(TAG, "Perfil y configuraciones sincronizados en Supabase con éxito.")
                }
            }

            // 2. Guardar catálogo y metadatos de sonidos en la tabla 'user_sounds'
            val soundSyncList = sounds.map { sound ->
                SoundItemSync(
                    userId = userId,
                    name = sound.name,
                    type = sound.type.name,
                    durationSeconds = sound.durationSeconds,
                    isDefault = sound.isDefault,
                    createdAt = now
                )
            }

            val soundsJson = soundListAdapter.toJson(soundSyncList)
            val soundsBody = soundsJson.toRequestBody("application/json; charset=utf-8".toMediaType())

            // Eliminar sonidos previos del usuario para refrescar lista
            val deleteOldSoundsRequest = Request.Builder()
                .url("$SUPABASE_URL/rest/v1/user_sounds?user_id=eq.$userId")
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer $SUPABASE_KEY")
                .delete()
                .build()
            client.newCall(deleteOldSoundsRequest).execute().close()

            // Insertar lista actualizada de sonidos
            val insertSoundsRequest = Request.Builder()
                .url("$SUPABASE_URL/rest/v1/user_sounds")
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer $SUPABASE_KEY")
                .header("Content-Type", "application/json")
                .post(soundsBody)
                .build()

            client.newCall(insertSoundsRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w(TAG, "Error guardando sonidos en Supabase: ${response.code}")
                }
            }

            prefs.edit().putLong(KEY_LAST_SYNC_TIME, System.currentTimeMillis()).apply()
            _lastSyncStatus.value = "Sincronizado correctamente"
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Excepción durante sincronización con Supabase: ${e.message}", e)
            _lastSyncStatus.value = "Error al sincronizar: ${e.message}"
            Result.failure(e)
        } finally {
            _isSyncing.value = false
        }
    }

    /**
     * Descarga el perfil y ajustes remotos desde Supabase (si existen).
     */
    suspend fun fetchUserDataFromSupabase(): Result<UserProfileSync?> = withContext(Dispatchers.IO) {
        val userId = _currentUserId.value ?: return@withContext Result.failure(Exception("No hay sesión activa"))

        try {
            _isSyncing.value = true
            val request = Request.Builder()
                .url("$SUPABASE_URL/rest/v1/user_profiles?user_id=eq.$userId&select=*")
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer $SUPABASE_KEY")
                .header("Accept", "application/json")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
                }
                val body = response.body?.string() ?: return@withContext Result.success(null)
                val profiles = profileListAdapter.fromJson(body)
                val profile = profiles?.firstOrNull()
                Result.success(profile)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error descargando perfil de Supabase: ${e.message}", e)
            Result.failure(e)
        } finally {
            _isSyncing.value = false
        }
    }
}
